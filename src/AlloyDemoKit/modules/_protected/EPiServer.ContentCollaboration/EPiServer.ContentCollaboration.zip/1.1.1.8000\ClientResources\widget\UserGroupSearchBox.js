﻿define([
// Dojo
    "dojo/_base/array",
    "dojo/_base/connect",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/event",

    "dojo/aspect",
    "dojo/Evented",
    "dojo/keys",

    "dojo/dom-attr",
    "dojo/dom-style",

    "dojo/Stateful",
    "dojo/when",
    "dojo/store/Memory",

// epi
    "epi/dependency",

// CA AddOn
    "epi-contentcollaboration/widget/UserGroupSuggestionBox",
    "epi-contentcollaboration/widget/UserGroupSearchResult",

// Resources
    "epi/i18n!epi/cms/nls/episerver.cms.widget.contentlist"
],

function (
// Dojo
    array,
    connect,
    declare,
    lang,
    event,

    aspect,
    Evented,
    keys,

    domAttr,
    domStyle,

    Stateful,
    when,
    Memory,

// EPi Framework
    dependency,

// CA AddOn
    UserGroupSuggestionBox,
    UserGroupSearchResult,

// Resources
    resources
) {

    return declare([UserGroupSuggestionBox, Evented], {
        // summary:
        //    A Search box to search for content.
        //
        // tags:
        //    public

        // res: Object
        //      Resource object, for getting text.
        //  tags:
        //      Protected
        res: resources,

        // autoComplete: Boolean
        //      If user types in a partial string, and then tab out of the `<input>` box,
        //      automatically copy the first entry displayed in the drop down list to
        //      the `<input>` field
        autoComplete: false,

        // dropDownClass: [protected extension] Function String
        //      Dropdown widget class, which would be used to create a widget, to show the search result.
        //      Subclasses should specify this.
        dropDownClass: UserGroupSearchResult,

        // queryExpr: String
        //      This specifies what query ComboBox/FilteringSelect sends to the data store,
        //      based on what the user has typed.  Changing this expression will modify
        //      whether the drop down shows only exact matches, a "starting with" match,
        //      etc.  Use it in conjunction with highlightMatch.
        //      dojo.data query expression pattern.
        //      `${0}` will be substituted for the user text.
        //      `*` is used for wildcards.
        //      `${0}*` means "starts with", `*${0}*` means "contains", `${0}` means "is"
        queryExpr: "${0}*",

        // minimumNumberOfChar: Integer
        //      The minimum number of character that is valid for search.
        //  tags:
        //      Protected
        minimumNumberOfChar: 1,

        widgetContainer: null,

        postCreate: function () {
            // summary: Override to:
            //      - mixin additional query params into query before _startSearch
            //      - connect to onSelect event of dropDown, to forward it to ContentSearchBox after _startSearch
            // tags:
            //      protected
            this.inherited(arguments);

            var registry = dependency.resolve("epi.storeregistry");
            this.userStore = this.userStore || registry.get("epi.contentcollaboration.users");
            when(this.userStore.query({ query: "getusersandgroups", isOnline: false }), lang.hitch(this, function (users) {

                this.store = new Memory({
                    data: users
                });

                // Delay in milliseconds between when user types something and we start
                // searching based on that value.
                this.searchDelay = this.defaultDelay;

                this.own(
                    this.on("beforeSearch", lang.hitch(this, function () {
                        // display dropdown with standby
                        if (this.dropDown) {
                            this.dropDown.showStandby(true);
                        }
                    })),

                    this.on("searchComplete", lang.hitch(this, function () {
                        // hide dropdown's standby
                        if (this.dropDown) {
                            this.dropDown.showStandby(false);
                        }
                    })),

                    aspect.before(this, "_startSearch", function (method, args) {
                        // doing something before the original call
                        this.emit("beforeSearch", {});

                        return [method, args];
                    })
                );
            }));

            this.own(
                connect.connect(this.userGroupSelectorWidget, "onResize", lang.hitch(this, function () {
                    // Should resize grid after any child widgets has updated UI
                    //  eg: textarea, usergroups tagged
                    this.onResize();
                }))
            );
        },

        onResize: function () {
            // summary:
            //    Fired when UI is changed or updated.
            //
            // tags:
            //    public, callback
        },

        _openResultList: function (/*Object*/results, /*Object*/query, /*Object*/options) {
            // summary:
            //		Callback when a search completes.
            // description:
            //		Generates drop-down list and calls _showResultList() to display it

            this.emit("searchComplete", results);

            this._fetchHandle = null;
            this.dropDown.clearResultList();

            var dataAvailable = results.length > 0 || options.start !== 0;
            // display the empty text if data is not available
            this.dropDown.showErrorMessage(!dataAvailable, this.res.contentnotfound);
            this.dropDown.showGrid(dataAvailable);

            if (dataAvailable) {
                this.dropDown.createOptions(results, options, lang.hitch(this, "_getMenuLabelFromItem"));
            }

            // show our list
            this._showResultList();
        },

        _onDropDownMouseDown: function (/*Event*/e) {
            // summary:
            //		Callback when the user mousedown's on the arrow icon.
            //  tags:
            //      Private, override

            // Enable mouse clickable when pinnable pane in un-pinned state.
            e.stopPropagation();
        },

        _onKey: function (/*Event*/evt) {
            // summary:
            //		Listen for Enter key, to start search request.
            // tags:
            //      private, override

            switch (evt.keyCode) {
                case keys.ENTER:
                    if (this.dropDown && this.dropDown.selected) {
                        this.dropDown.handleKey(evt);
                        this.closeDropDown();
                        event.stop(evt);
                    } else if (!this._fetchHandle) {
                        this._startSearchFromInput();
                        // Ignore enter key if dropDown is openning
                        if (!!this._opened) {
                            event.stop(evt);
                        }
                    }
                    break;
                case keys.PAGE_DOWN:
                case keys.DOWN_ARROW:
                case keys.PAGE_UP:
                case keys.SPACE:
                case keys.UP_ARROW:
                    // let the dropdown handle these keystrokes for navigating between item
                    if (this.dropDown) {
                        this.dropDown.handleKey(evt);
                    }
                    // Ignore these keys if dropDown is openning
                    if (!!this._opened) {
                        event.stop(evt);
                    }
                    break;
                case keys.LEFT_ARROW:
                case keys.RIGHT_ARROW:
                case keys.HOME:
                case keys.END:
                    // Ignore these keys if dropDown is openning
                    if (!!this._opened) {
                        event.stop(evt);
                    }
                    break;
                case keys.BACKSPACE:
                    if (!this._opened && this.textbox && !this.textbox.value) {
                        var values = lang.clone(this.get("value"));
                        if (values && lang.isArray(values) && values.length > 0) {
                            this.set("value", values.slice(0, values.length - 1));
                            event.stop(evt);
                        }
                    }
                default:
                    this.inherited(arguments);
            }
        },

        _startSearchFromInput: function () {
            // summary:
            //      Start the search action
            // tags:
            //      private, override

            // start the search action only if input text length is more than minimum number
            // Ensure the search string have only one special character
            var searchString = this.textbox.value;

            if (!searchString || searchString.length < this.minimumNumberOfChar) {
                this.closeDropDown();
                return;
            }
            // Get key with trim string
            var key = lang.trim(searchString);

            if (!this.dropDown) {
                var popupId = this.id + "_popup",
                    dropDownConstructor = lang.isString(this.dropDownClass) ? lang.getObject(this.dropDownClass, false) : this.dropDownClass;

                this.dropDown = new dropDownConstructor({
                    id: popupId,
                    dir: this.dir,
                    textDir: this.textDir
                });

                var container = this.widgetContainer || this.textbox;
                domAttr.remove(container, "aria-activedescendant");
                domAttr.set(container, "area-owns", popupId); // associate popup with textbox

                this.dropDown.on("select", lang.hitch(this, function (value) {
                    this.closeDropDown();

                    if (this.userGroupSelectorWidget) {
                        // Update value for userGroupSelector 
                        var values = lang.clone(this.get("value"));
                        var existed = array.some(values, function (v) {
                            return v.isGroup === value.isGroup
                                && v.name === value.name;
                        });
                        if (!existed) {
                            values.push(value);
                        }
                        this.set("value", values);
                    }

                    // Clear and set focus to continue tagging alway ready
                    this.textbox.value = "";
                    this.focus();

                    this.emit("select", value);
                }));
            }

            this._showResultList();

            // We do not want to call the inherited method here since it will escape wild card characters (* and ?),
            // which will break any searches with wild card.
            this._startSearch(key);
        },

        _startSearchAll: function () {
            // disable search with empty string
        }
    });
});