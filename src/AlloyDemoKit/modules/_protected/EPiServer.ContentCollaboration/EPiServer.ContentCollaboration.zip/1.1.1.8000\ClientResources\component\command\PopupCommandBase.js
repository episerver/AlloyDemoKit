﻿define([
//Dojo base
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/promise/all",
    "dojo/when",

// Dijit
    "dijit/Menu",
    "dijit/popup",

// EPi
    "epi/shell/command/_Command",
    "epi/shell/command/ToggleCommand",
    "epi/shell/command/builder/MenuBuilder",
    "epi-cms/contentediting/ContentActionSupport",

//CA command
    "epi-contentcollaboration/ContentCollaborationSettings",

// Resources
    "epi/i18n!epi/cms/nls/episerver.components.contentcollaboration"

], function (
// Dojo base
    array,
    declare,
    lang,

    all,
    when,

// Dijit
    Menu,
    popupManager,

// EPi
    _Command,
    ToggleCommand,
    MenuBuilder,
    ContentActionSupport,

// CA command
    ContentCollaborationSettings,

// Resources
    resources

    ) {
    return declare([_Command], {

        popup: null,

        popupClass: Menu,

        selectedValue: null,

        postscript: function () {
            this.inherited(arguments);
            this._menuBuilder = new MenuBuilder();
        },

        _onModelChange: function () {
            // summary:
            //      Updates canExecute after the model has been updated.
            // tags:
            //      protected

            this.inherited(arguments);
            this._setupCommandModel(this.model);
        },

        _popupSetter: function (popup) {
            // summary:
            //      Create sub-menu items for popup.
            // tags:
            //      protected

            this.popup = popup;

            var commands = this.get("commands");
            if (!commands) {
                return;
            }

            // Create sub menu items
            array.forEach(commands, function (command) {
                this._menuBuilder.create(command, this.popup);
            }, this);

            this.model && this._setupCommandModel(this.model);
        },

        _setupCommandModel: function (model) {
            // summary:
            //		Setup model for array of commands.
            // tags:
            //		private

            var commands = this.get("commands");
            array.forEach(commands, function (command) {
                command.set("model", model);
            }, this);
        }
    });
});