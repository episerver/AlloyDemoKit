﻿define([
// Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/dom-attr",
    "dojo/dom-class",
    "dojo/keys",
    "dojo/on",
    "dojo/when",

// Dijit
    "dijit/_Widget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",

    "dijit/form/Button",
    "dijit/form/Textarea",
    "dijit/focus",

// EPi
    "epi/epi",
    "epi/dependency",
    "epi/username",
    "epi/shell/widget/ValidationTextarea",

// Resources
    "epi/i18n!epi/cms/nls/episerver.components.contentcollaboration",
    "dojo/text!./templates/CommentBase.html"
],
function (
// Dojo
    declare,
    lang,
    aspect,
    domAttr,
    domClass,
    keys,
    on,
    when,

// Dijit
    _Widget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,

    Button,
    Textarea,
    focusUtil,

// EPi
    epi,
    dependency,
    username,
    ValidationTextarea, // use in template

// Resources
    resources,
    template
) {
    // module:
    //      epi-contentcollaboration/widget/CommentBase
    // summary:
    //      A base widget to display status update or comment.

    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin], {

        // ellipsisPlaceHolderText: [public] Boolean
        //      The flag to indicate should or should not ellipsis place holder text of the input control
        ellipsisPlaceHolderText: false,

        // resetValue: String
        //      Initial value of widget.
        resetValue: null,

        // model: Object
        //      Include { name:<ContentName || CurrentNodeName>, id: <ContentLink || CurrentNodeId> }
        model: null,

        // resources: Object
        //      Json object represent for XML lang file.
        resources: resources,

        // placeholderFormat: String
        //      String format of placeholder text.
        placeholderFormat: null,

        // templateString: String
        //      String template of this widget.
        templateString: template,

        // feedHub: Object
        //      Singleton instance of FeedEchoService.
        feedHub: null,

        // required: Boolean
        //      Flags indicates the value is required or not
        required: true,

        // intermediateChanges: Boolean
        //      Flags indicates the value change will be raised intermediately.
        intermediateChanges: true,

        onResize: function () {
            // summary:
            //    Triggered when the textarea focus
            //
            // tags:
            //    public callback
        },

        onChange: function (/*String*/value) {
            // summary:
            //      Callback event when user save changes that used to manual save when edit comment.
            // tags:
            //      public
        },

        postCreate: function () {
            this.inherited(arguments);

            this.feedHub = this.feedHub || dependency.resolve("epi.contentcollaboration.signalr.feedservice");

            this.own(
                // Raise onResize event after text input has resize
                aspect.after(this.inputTextarea, "resize", lang.hitch(this, this.onResize)),

                // Listen on inputTextarea text change.
                aspect.after(this.inputTextarea, "onChange", this.inputTextarea.validate)
            );
        },

        focus: function () {
            // summary:
            //      Focus to textarea
            // tags:
            //      public

            focusUtil.focus(this.inputTextarea.domNode);
        },

        _getPlaceHolderFormat: function () {
            // summary:
            //      Get place holder.
            // tags:
            //      protected

            return this.resources.writecomment;
        },

        _onClick: function () {
            // summary:
            //      Override the click event of placehoder span to focus on right place.
            // tags:
            //      protected

            this.inherited(arguments);
            this.focus();
        },

        _onKeyPress: function (evt) {
            // summary:
            //      Post data when user typed comment and presses Enter button.
            // tags:
            //      private

            if (evt.charOrCode === keys.ENTER && !evt.shiftKey) {
                this._onChange(evt);
            }
            else {
                this.focus();
            }
        },

        _setValueAttr: function (/*String*/value) {
            // summary:
            //      Used to edit comment.
            // tags:
            //      public

            this.inputTextarea.focusNode.value = value;
            this.resetValue = value;
            this.inputTextarea.resize();
        },

        _getValueAttr: function () {
            // summary:
            //      Used to edit comment.
            // tags:
            //      public

            return lang.trim(this.inputTextarea.focusNode.value);
        },

        _setModelAttr: function (/*Object*/model) {
            // summary:
            //      Called when the currently loaded content updated.
            // tags:
            //      protected

            this._set("model", model);

            this.placeholderFormat = this.placeholderFormat || this._getPlaceHolderFormat();

            this._setupUI();
        },

        _setupUI: function () {
            // summary:
            //      Initialize UX and value, display place holder for input control
            // tags:
            //      protected

            this._clearData();
            this._setupPlaceHolder();

            on(this.inputTextarea._phspan, "click", lang.hitch(this, this._onClick));
        },

        _setupPlaceHolder: function () {
            // summary:
            //      Setup place holder text for the input control
            // tags:
            //      private

            var placeHolderText = lang.replace(this.placeholderFormat, [this.model.name]);
            this.inputTextarea.set("placeHolder", placeHolderText);

            // Incase the given content name is too long, ellipsis it
            // In additional, to support to view the full length of the given content name, set the value to the 'title' attribute
            if (this.ellipsisPlaceHolderText) {
                domClass.add(this.inputTextarea._phspan, 'dojoxEllipsis');
                domAttr.set(this.inputTextarea._phspan, 'title', placeHolderText);
            }
        },

        _buildPostData: function () {
            // summary:
            //      Virtual method to get post data.
            // tags:
            //      protected virtual

            return {
                message: this.get("value"),
                parentFeedId: this.model.id
            };
        },

        _save: function () {
            // summary:
            //      Default save method.
            // tags:
            //      protected

            var postData = this._buildPostData();
            when(this.feedHub.postItem(postData), lang.hitch(this, this._clearData));
        },

        _isValid: function () {
            // summary:
            //    Check if widget's value is valid.
            // tags:
            //    protected, override

            return !this.required || this.get("value");
        },

        _onChange: function (evt) {
            // summary:
            //      Post new comment of current editor.
            //      This comment can be status of current content or comment on feed.
            // tags:
            //      private

            if (this.inputTextarea.validate()) {
                var message = this.get("value");

                // Hide tooltip message when user input comments
                this.inputTextarea.displayMessage(null);

                // Raise onChange event
                this.onChange(message);

                // If user want manual save
                if (this.saveDelegate) {
                    this.saveDelegate();
                } else {
                    this._save();
                }
            } else {
                // Stop key press event
                evt.preventDefault();
                this.focus();
            }
        },

        _clearData: function () {
            // summary:
            //      Set value is empty
            // tags:
            //      private

            this.set("value", "");
        }
    });
});