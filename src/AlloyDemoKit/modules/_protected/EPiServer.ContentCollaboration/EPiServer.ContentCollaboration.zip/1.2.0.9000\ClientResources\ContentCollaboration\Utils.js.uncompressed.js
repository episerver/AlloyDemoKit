﻿define("epi-contentcollaboration/Utils", [
    "dojo/_base/declare",
    "dojox/html/entities",
    "epi",
    "epi/dependency",

    "epi/i18n!epi/cms/nls/episerver.components.contentcollaboration"
],

function (
    declare,
    entities,
    epi,
    dependency,

    res
) {
    // NOTE: basically this is copy of epi/username and replaced its localization resources by CC add-on's resource.
    // We don't use epi/username directly because it make inconsitent UI since this add-on has been not translated.
    // And this add-on UI should fallback to English.

    return {
        // tags:
        //      public

        toUserNameFriendlyString: function (/*string*/username, /*string*/currentUsername, /*boolean*/capitalizeUsername, /*boolean*/keepEmptyUsername) {
            // summary:
            //      Get friendly username: if the username to be displayed is the same
            //      as the current username, this will returns "you".
            // username:
            //    The username to be displayed.
            // currentUsername:
            //    The username to compare with (optional) to see if it's the current user.
            // capitalizeUsername:
            //    If the first character should be in upper case.
            // keepEmptyUsername:
            //    If the empty username should be kept or replaced by "Installer".
            // tags:
            //    public

            if (!currentUsername) {
                currentUsername = this._getCurrentUsername();
            }

            var emtyUsername = keepEmptyUsername ? "" : res.installer,
                friendlyUsername = username && currentUsername.toLowerCase() === username.toLowerCase() ? res.you : username || emtyUsername;
            if (capitalizeUsername) {
                friendlyUsername = friendlyUsername.charAt(0).toUpperCase() + friendlyUsername.slice(1);
            }
            return friendlyUsername;
        },

        _getCurrentUsername: function () {
            if (!this.currentUsername) {
                var profile = dependency.resolve("epi.shell.Profile");
                //TODO: Make this Async
                this.currentUsername = profile.get("userName");
            }
            return this.currentUsername;
        }
    };
});
