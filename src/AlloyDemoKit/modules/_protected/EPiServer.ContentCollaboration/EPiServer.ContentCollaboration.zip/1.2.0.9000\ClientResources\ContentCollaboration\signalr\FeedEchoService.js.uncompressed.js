﻿define("epi-contentcollaboration/signalr/FeedEchoService", [

// Dojo
    "dojo/_base/lang",
    "dojo/_base/declare",

    "dojo/Deferred",
    "dojo/Evented",
    "dojo/json",
    "dojo/store/Memory",
    "dojo/Stateful",
    "dojo/when",

// EPi Framework
    "epi/epi",

// EPi CMS
    "epi-cms/_ContentContextMixin",

// EPi Addons
    "epi-contentcollaboration/ContentCollaborationSettings"

], function (

// Dojo
    lang,
    declare,

    Deferred,
    Evented,
    JSON,
    Memory,
    Stateful,
    when,

// EPi Framework
    epi,

// EPi CMS
    _ContentContextMixin,

// EPi Addons
    ContentCollaborationSettings

) {
    // summary:
    //      Static class extend jquery signalr
    return declare([Stateful, Evented, _ContentContextMixin], {

        // ready: Boolean
        //      State of this service.
        ready: null,

        // echoService: Object
        //      The client hub proxy
        echoService: null,

        // previousChannel: Content context object
        //      The previous content context that used to group clients
        previousChannel: null,

        // currentChannel: Content context object
        //      The current content context that used to group clients
        currentChannel: null,

        // url: string
        //      The base signalR url of this site to communicate with serverSide
        url: null,

        // contentType: string
        //      The content type for signalr's connection settings.
        contentType: "application/json; charset=UTF-8",

        // jsonP: Boolean
        //      Support JsonP in signalr or not.
        jsonP: false,

        // channelJoined: Boolean
        //      Flags indicates that we joined channel or not.
        channelJoined: false,

        // _notificationItemsCache: Store
        //      Memory is store that's used to cache created object.
        //      That avoid emit too many times on the same item.
        _notificationItemsCache: new Memory({ idAttribue: "id", data: [] }),

        contentContextChanged: function (ctx, callerData) {
            // summary:
            //      Called when the currently loaded content changes. I.e. a new content data object is loaded into the preview area.
            // tags:
            //      protected

            // Don't lost effort when no necessary
            if (this.currentChannel && epi.areEqual(this.currentChannel.id, ctx.id)) {
                return;
            }
            this._tryJoinChannel(true);
        },

        initialize: function () {
            // summary:
            //      Initialze new service
            // tags:
            //      private

            this.open().then(lang.hitch(this, function () {
                this._tryJoinChannel();
            })).then(lang.hitch(this, function () {
                this.set("ready", true);
            }));
        },

        open: function () {
            // summary:
            //      Open connection to server using signalR.
            // tags:
            //      public

            var self = this,
                dfd = new Deferred();

            // Initalize hub
            if (!self.echoService) {

                // this is similar with refering the /signalr/hubs generated proxy script
                // Establish a connection (without the generated proxy)
                // see http://www.asp.net/signalr/overview/signalr-20/hubs-api/hubs-api-guide-javascript-client#nogenconnection
                var connection = $.hubConnection(this.url, { useDefaultPath: false });

                self.echoService = connection.createHubProxy("feedHub");
                self.echoService.on("broadCast", function (data) {
                    // Do nothing when channel is changging.
                    if (self._isJoinningChannel) {
                        return;
                    }

                    // We received new message
                    var jsonData = JSON.parse(data);

                    // Work with feedItem only
                    if (jsonData && jsonData.item && jsonData.item.id) {
                        // Check to avoid broadcast duplicated item.
                        var feedItemCacheKey = self._buildFeedItemCacheKey(jsonData),
                            isBroadcasted = !!(self._notificationItemsCache.get(feedItemCacheKey));
                        if (isBroadcasted) {
                            return;
                        }

                        // put to cache
                        self._notificationItemsCache.put({
                            "id": feedItemCacheKey,
                            "data": jsonData
                        });

                        // remove item after 5 minute
                        setTimeout(function () {
                            self._notificationItemsCache.remove(feedItemCacheKey);
                        }, 300000); // after 5 minute we'll remove cache
                    }

                    self.emit(jsonData.action, jsonData.item);
                });
                connection.logging = true;
            }

            // Start connection
            connection.start({ contentType: self.contentType, jsonp: self.jsonP }).done(function () {
                dfd.resolve();
            });

            return dfd;
        },

        _buildFeedItemCacheKey: function (jsonData) {
            // summary:
            //      Create cache key for feed item
            // tags:
            //      private

            return lang.replace("{action}:{item.id}_{item.lastUpdateDate}", jsonData);
        },

        _storeChannel: function (/*Object*/context) {
            // summary:
            //      Store old context and set new context
            // tags:
            //      public

            if (this.currentChannel) {
                // Don't lost effort when no necessary
                if (epi.areEqual(this.currentChannel.id, context.id)) {
                    return;
                }
                this.previousChannel = lang.clone(this.currentChannel);
            }
            this.currentChannel = context;
        },

        postItem: function (/*Object*/postData) {
            // summary:
            //      Post a comment.
            // tags:
            //      public

            return this.invoke("post", postData);
        },

        updateItem: function (/*FeedItem*/feedItem) {
            // summary:
            //      Post a comment.
            // tags:
            //      public

            return this.invoke("update", feedItem);
        },

        deleteItem: function (/*FeedItem*/feedItem) {
            // summary:
            //      Post a comment.
            // tags:
            //      public

            return this.invoke("delete", feedItem);
        },

        subscribe: function (/*ContentReference*/contentLink, /*int*/subscribeType) {
            // summary:
            //      Subscribe the channel
            // tags:
            //      public

            return this.invoke("subscribe", { contentLink: contentLink, subscribeType: subscribeType });
        },

        unSubscribe: function (/*ContentReference*/contentLink) {
            // summary:
            //      Subscribe the channel
            // tags:
            //      public

            return this.invoke("unsubscribe", { contentLink: contentLink });
        },

        unSubscribeAll: function () {
            // summary:
            //      Subscribe the channel
            // tags:
            //      public

            return this.invoke("unsubscribeall", {});
        },

        removeSubscribe: function (/*ContentReference*/contentLink) {
            // summary:
            //      Subscribe the channel
            // tags:
            //      public

            return this.invoke("removesubscribe", { contentLink: contentLink });
        },

        spyEvent: function (/*ContentReference*/contentLink, /*String*/activityType, /*Json*/optionalData) {
            // summary:
            //      Spy client content event and send to server.
            // tags:
            //      public

            return this.invoke("spyevent", lang.mixin(optionalData || {}, { contentLink: contentLink, activityType: activityType }));
        },

        saveEmailNotificationType: function (/*EmailNotificationType*/emailNotificationType) {
            // summary:
            //      Create/Save email notification setting.
            // tags:
            //      public

            this.savePersonalizeSetting({ emailNotificationType: emailNotificationType });
        },

        savePersonalizeSetting: function (/*EmailNotificationType*/personalizeSetting) {
            // summary:
            //      Save personalize setting.
            // tags:
            //      public

            return this.invoke("savepersonalizesetting", personalizeSetting);
        },

        invoke: function (/*String*/methodName, /*Object*/postData) {
            var dfd = new Deferred();

            when(this._tryJoinChannel(), lang.hitch(this, function () {
                if (postData && !postData.contentLink) {
                    lang.mixin(postData, { contentLink: this.currentChannel.id });
                }
                this.echoService.invoke(methodName, postData).done(function (result) {
                    dfd.resolve(result);
                }).fail(lang.hitch(this, function (error) {
                    console.log("Invoke ", methodName, " ... FAILURE!", error);
                }));
            }));

            return dfd;
        },

        _tryJoinChannel: function (/*Boolean*/forceRefresh) {
            // summary:
            //      Check connection state and try re-connect.
            // tags:
            //      private

            var dfd = new Deferred(),
                self = this;

            // Invoke server to update channel
            when(this.getCurrentContext(), lang.hitch(this, function (ctx) {
                // Store old / set new context
                this._storeChannel(ctx);

                var self = this,
                    options = {
                        contentLink: this.currentChannel.id,
                        previousContentLink: this.previousChannel ? this.previousChannel.id : null
                    },
                    callHub2JoinChannel = lang.hitch(this, function (/*Boolean*/isForceRefresh) {
                        // Increase performance
                        var isChannelJoined = this.get("channelJoined");
                        if (isChannelJoined && !isForceRefresh) {
                            dfd.resolve();
                            return;
                        }

                        this._isJoinningChannel = true;
                        this.echoService.invoke("join", options).done(lang.hitch(this, function () {
                            this._isJoinningChannel = false;
                            this.set("channelJoined", true);
                            dfd.resolve();
                        })).fail(lang.hitch(this, function (error) {
                            console.log("Joinning channel ... FAILURE!", error);
                        }));
                    });

                if (this.echoService.connection.state === $.signalR.connectionState.disconnected ||
                    this.echoService.connection.state === $.signalR.connectionState.connecting) {
                    // Connection hasn't been started yet
                    this.echoService.connection.start({ contentType: self.contentType, jsonp: self.isSupportJsonP }).done(lang.hitch(this, function () {
                        callHub2JoinChannel(true/*always force refresh in this case*/);
                    }));
                } else {
                    // Normal case when everythings is ok.
                    callHub2JoinChannel(forceRefresh);
                }
            }));

            return dfd;
        },

        _channelJoinedSetter: function (/*Boolean*/value) {
            // summary:
            //      Customize set method to emit event
            // tags:
            //      public

            this.channelJoined = value;
            this.emit("channeljoined", {});
        }
    });
});