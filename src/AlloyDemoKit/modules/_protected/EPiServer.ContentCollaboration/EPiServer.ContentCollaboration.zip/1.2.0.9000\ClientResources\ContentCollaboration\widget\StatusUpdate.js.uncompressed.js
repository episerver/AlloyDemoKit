require({cache:{
'url:epi-contentcollaboration/widget/templates/StatusUpdate.html':"﻿<div class=\"dijit dijitReset dijitInline epi-statusUpdate-editor\">\r\n    <div class=\"epi-comment-container\">\r\n        <div class=\"epi-comment-title\">\r\n            <span class=\"dijitReset dijitInline dijitIcon epi-iconBubble\"></span>\r\n            <span class=\"dijitReset dijitInline\">${resources.writecomment}</span>\r\n        </div>\r\n        <span class=\"epi-placeholder\">\r\n            <span data-dojo-type=\"epi/shell/widget/ValidationTextarea\"\r\n                data-dojo-attach-point=\"inputTextarea\"\r\n                class=\"epi-commentBox\"\r\n                data-dojo-attach-event=\"onKeyPress:_onKeyPress, isValid:_isValid\"\r\n                data-dojo-props=\"intermediateChanges:${intermediateChanges}, required:${required}, missingMessage:'${resources.requiredfield}'\">\r\n            </span>\r\n        </span>\r\n    </div>\r\n    <div data-dojo-type=\"epi-contentcollaboration/widget/UserGroupSearchBox\" data-dojo-attach-point=\"userGroupSelector\"></div>\r\n    <div class=\"epi-component-toolbar\">\r\n        <button class=\"dijitButton Salt epi-floatRight\" data-dojo-type=\"dijit/form/Button\" data-dojo-attach-point=\"postButton\" type=\"button\" data-dojo-attach-event=\"onClick:_onChange\">${resources.post}</button>\r\n    </div>\r\n</div>\r\n"}});
﻿define("epi-contentcollaboration/widget/StatusUpdate", [

// Dojo
    "dojo/_base/array",
    "dojo/_base/connect",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-style",
    "dojo/when",

// EPi Framework
    "epi/shell/widget/ValidationTextarea",

// EPi CMS
    "epi-cms/_ContentContextMixin",

// CA
    "epi-contentcollaboration/widget/CommentBase",
    "epi-contentcollaboration/widget/UserGroupSearchBox",

// Resources
    "epi/i18n!epi/cms/nls/episerver.components.contentcollaboration", // use in template
    "dojo/text!./templates/StatusUpdate.html"

], function (

// Dojo
    array,
    connect,
    declare,
    lang,
    domStyle,
    when,

// EPi Framework
    ValidationTextarea, // use in template

// EPi CMS
    _ContentContextMixin,

// CA
    CommentBase,
    UserGroupSearchBox,

// Resources
    resources,
    template

) {
    // module:
    //      epi-contentcollaboration/widget/StatusUpdate
    // summary:
    //      Widget to display status update.

    return declare([CommentBase, _ContentContextMixin], {

        // ellipsisPlaceHolderText: [public] Boolean
        //      The flag to indicate should or should not ellipsis place holder text of the input control
        ellipsisPlaceHolderText: true,

        // templateString: String
        //      String template of this widget.
        templateString: template,

        // resources: Object
        //      Json object represent for XML lang file.
        resources: resources,

        postCreate: function () {
            this.inherited(arguments);

            when(this.getCurrentContext(), lang.hitch(this, function (ctx) {
                this.set("model", ctx);
            }));

            this.own(
                // Should raise resize event after user/groups has tagged or removed
                connect.connect(this.userGroupSelector, "onResize", lang.hitch(this, this.onResize))
            );
        },

        _getPlaceHolderFormat: function () {
            // summary:
            //      Override base class to return our format.
            // tags:
            //      protected override

            return this.resources.statusplaceholder;
        },

        _buildPostData: function () {
            // summary:
            //      Virtual method to get post data.
            // tags:
            //      protected virtual

            // Get seperate users and groups array
            var userGroupsTagged = this.userGroupSelector.get("value"),
                users = array.filter(userGroupsTagged, function (item) {
                    return !item.isGroup;
                }),
                userGroups = array.filter(userGroupsTagged, function (item) {
                    return item.isGroup;
                });

            // Map array string to post to server
            var dataUsers = array.map(users, function (item) {
                    return item.name;
                }),
                dataUserGroups = array.map(userGroups, function (item) {
                    return item.name;
                });

            return {
                message: this.get("value"),
                users: dataUsers,
                userGroups: dataUserGroups
            };
        },

        contentContextChanged: function (ctx, callerData) {
            // summary:
            //      Re-set model when context is changed.
            // tags:
            //      public

            this.set("model", ctx);
        },

        _clearData: function () {
            // summary:
            //      Set value is null
            // tags:
            //      private override

            this.inherited(arguments);

            // Cleare value of user group
            this.userGroupSelector.set("value", null);
            this.userGroupSelector.textbox.value = "";
        }
    });

});