﻿define([
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/html",
    "dojo/dom-style",

    "dojo/Evented",

// dijit
    "dijit/_TemplatedMixin",
    "dijit/_Widget",

// EPi
    "epi/shell/widget/_ModelBindingMixin",

// CC Addon
    "epi-contentcollaboration/ContentCollaborationSettings",

// Templates
    "dojo/text!./templates/ShowAllComment.html",

// Resources
    "epi/i18n!epi/cms/nls/episerver.components.contentcollaboration",
],
function (
// dojo
    declare,
    lang,

    html,
    domStyle,

    Evented,

// dijit
    _TemplatedMixin,
    _Widget,

// EPi
    _ModelBindingMixin,

// CC Addon
    ContentCollaborationSettings,

// Templates
    template,

// Resources
    resources
) {
    return declare([_Widget, _TemplatedMixin, _ModelBindingMixin, Evented], {
        // summary:
        //      Widget for show all comment link.
        //
        // tags:
        //      public

        templateString: template,
        
        modelBindingMap: {
            "itemData": ["itemData"]
        },

        model: null,

        postCreate: function () {
            // summary:
            //		Post widget creation. Initialize event for buttons
            // tags:
            //      Protected

            this.inherited(arguments);
        },

        _setItemDataAttr: function (value) {
            // summary:
            //      Set the item data associated with this widget.
            // tags:
            //      private
            
            if (value.commentNumber <= ContentCollaborationSettings.MaxDisplayItems) {

                domStyle.set(this.domNode, "display", "none");
                return;
            }

            html.set(this.linkNode, lang.replace(resources.showallcomment, [value.commentNumber]));
        },

        _onClick: function () {
            // summary:
            //      Handle click event on link.
            // tags:
            //      private

            this.emit("linkClick", this, this.model.get("itemData"));
        }
    });
});