﻿define("epi-contentcollaboration/widget/FilterUser", [
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/aspect",
    "dojo/has",
    "dojo/query",
    "dojo/dom-attr",
    "dojo/dom-class",
    "dojo/dom-construct",
    "dojo/dom-style",
    "dojo/Stateful",

// epi
    "epi/shell/dgrid/util/misc",
    "epi-cms/contentediting/editors/CheckBoxListEditor",

// CA
    "epi-contentcollaboration/widget/DropDownButtonBase",
    "epi-contentcollaboration/Utils",

// Resources
    "epi/i18n!epi/cms/nls/episerver.components.contentcollaboration"
], function (
    array,
    declare,
    lang,

    aspect,
    has,
    query,
    domAttr,
    domClass,
    domConstruct,
    domStyle,
    Stateful,

// epi
    GridMiscUtil,
    CheckBoxListEditor,

// CA
    DropDownButtonBase,
    Utils,

// Resources
    resources

) {
    var CheckBoxListEditorEx = declare([CheckBoxListEditor], {
        // Summary: 
        //   Remove subscription to each item
        // tags:
        //    private

        _addCheckBoxForItem: function (item) {
            // summary:
            //      Add Remove button to each item.
            // tags:
            //      protected

            this.inherited(arguments);

            this.onAfterSetupItemUI(this, item);
        },

        addNewItem: function (/*Object*/ item) {
            // summary:
            //      Create check box for this item
            // tags:
            //      public

            this._addCheckBoxForItem(item);
            this.selections.push(item);
        }
    });

    return declare([DropDownButtonBase], {

        // storeKey: String
        //      The key string to get store by key.
        storeKey: "epi.contentcollaboration.users",

        // resources: Object
        //      Json object represent for XML lang file.
        resources: resources,

        // label: [String]
        //      The text of button
        label: resources.filter,

        "class": "epi-chromeless--with-arrow",

        // dropdownContentClass: Constructor
        //      Generic content widget class that's used to create instance for dropdownContentWidget.
        dropdownContentClass: CheckBoxListEditorEx,

        _buildQueryParams: function () {
            // summary:
            //      Build query params.
            // tags:
            //      protected override

            var queryParams = this.inherited(arguments);

            return lang.mixin(queryParams, { query: "getusersincurrentlink", isOnline: false });
        },

        _buildMenuHeader: function (/*domNode*/ contentContainer, /*Array*/ items) {
            // summary:
            //      Create menu header.
            // tags:
            //      protected

            // Display message for non data
            if (!items || items.length <= 0) {
                delete this.dropdownContentWidget;

                if (has("ie") === 9) {
                    domConstruct.create("tr", { innerHTML: this.noDataMessage, "class": "epi-dropdown-menu-container dgrid-no-data" }, contentContainer, "before");
                }
                else {
                    contentContainer.innerHTML = this.noDataMessage;
                }

                domClass.add(contentContainer, "dgrid-no-data");
            }
            else {

                var clearContainer = domConstruct.create("div", { "class": "epi-floatRight epi-padding-small" }, this.dropDown.domNode, "first");

                // Add and invisible clear all link when initialize
                this.clearAll = domConstruct.create("a", { "class": "epi-visibleLink", innerHTML: resources.clearall }, clearContainer);
                domStyle.set(this.clearAll, "visibility", "hidden");
                this.connect(this.clearAll, "onclick", lang.hitch(this, function () {
                    this.dropdownContentWidget.set("value", null);
                }));
            }
        },

        _setupEvents: function () {
            // summary:
            //      Setup event on dropdownContentWidget.
            // tags:
            //      protected

            this.inherited(arguments);

            this.own(
                aspect.after(this.dropdownContentWidget, "onChange", lang.hitch(this, function () {
                    var selectedValue = this.dropdownContentWidget.get("value");
                    domStyle.set(this.clearAll, "visibility", !!selectedValue ? "visible" : "hidden");
                }), true)
            );
        },

        addNewItem: function (item) {
            // summary:
            //      Create check box of this item
            // tags:
            //      public

            if (this.dropdownContentWidget) {
                var itemData = { value: item.name, text: Utils.toUserNameFriendlyString(GridMiscUtil.htmlEncode(item.name), null, true, null) };
                this.dropdownContentWidget.addNewItem(itemData);
            }
            else {
                this._buildMenuContent([item]);
            }
        },

        getSelections: function () {
            // summary:
            //      Return selection items
            // tags:
            //      public

            if (this.dropdownContentWidget) {
                return this.dropdownContentWidget.selections;
            }
        },

        _buildQueryOptions: function () {
            // summary:
            //      Build query options
            // tags:
            //      protected

            var queryOptions = this.inherited(arguments);

            return lang.mixin(queryOptions, { ignore: ["isOnline"] });
        },

        _buildMenuContentSettings: function (/*Array*/users) {
            // summary:
            //      Generic method to get menu content settings from items.
            //      We also normalize data (itmes) here.
            // tags:
            //      protected override

            var self = this;

            return {
                selections: array.map(users, function (user) {
                    return new Stateful({ value: user.name, text: Utils.toUserNameFriendlyString(GridMiscUtil.htmlEncode(user.name), null, true, null) });
                }),
                onAfterSetupItemUI: function (context, item) { // Inject after UI setup
                    self.onAfterSetupItemUI(context, item);
                },
                valueIsCsv: this.valueIsCsv  // Inject flag
            };
        },

        onAfterSetupItemUI: function (dropdownContentWidget, item) {
            // summary:
            //      Build base UI: checkbox and label for each item.
            // tags:
            //      protected
            if (!dropdownContentWidget.domNode) {
                return;
            }

            var currentNode = dropdownContentWidget.domNode.lastChild;

            // Create native title to each item.
            domAttr.set(currentNode, { "title": item.text });
        }

    });
});