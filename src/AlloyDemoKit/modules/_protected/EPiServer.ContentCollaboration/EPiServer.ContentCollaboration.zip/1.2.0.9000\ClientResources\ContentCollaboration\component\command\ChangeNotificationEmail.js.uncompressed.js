﻿define("epi-contentcollaboration/component/command/ChangeNotificationEmail", [
// Dojo base
    "dojo/_base/declare",

// Epi Framework
    "epi/routes",
    "epi/shell/command/_Command",

// Resources
    "epi/i18n!epi/cms/nls/episerver.components.contentcollaboration"

], function (
// Dojo base
    declare,

// Epi Framework
    epiRoutes,
    _Command,

// Resources
    resources
) {
    return declare([_Command], {

        category: "setting",

        label: resources.commands.changenotificationemail.label,

        postscript: function () {
            this.inherited(arguments);

            this.set("isAvailable", true);
            this.set("canExecute", true);
        },

        _execute: function () {
            // summary:
            //      Executes this command assuming canExecute has been checked.
            // tags:
            //      protected

            var url = epiRoutes.getActionPath({
                moduleArea: "LegacyCMS",
                path: "edit/mysettings.aspx"
            });
            window.open(url, "_blank");
        }
    });
});
