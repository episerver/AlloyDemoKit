﻿define("epi-contentcollaboration/component/command/SubscribeCommandBase", [
//Dojo base
    "dojo/_base/declare",
    "dojo/_base/lang",
    
    "dojo/topic",
    "dojo/when",
    "dojo/promise/all",

// EPi
    "epi",
    "epi/shell/command/ToggleCommand",

// CC
    "epi-contentcollaboration/ContentCollaborationSettings"

], function (
// Dojo base
    declare,
    lang,

    topic,
    when,
    all,

// EPi
    epi,
    ToggleCommand,

// CC
    ContentCollaborationSettings
    ) {

    return declare([ToggleCommand], {

        // label: String
        //      Display name of the command
        label: null,

        // value: Enum
        //      The subscription type that's defined in ContentCollaborationSettings.SubscribeTypes.
        //      The subscription type that command is reserved. 
        value: null,

        // selectedValue: Enum
        //      The subscription type that's defined in ContentCollaborationSettings.SubscribeTypes.
        //      Current selected type.
        selectedValue: null,

        // canExecute: [Boolean]
        //      Set can execute or not for this command
        //      The default value is alway true
        canExecute: true,

        postscript: function () {
            this.inherited(arguments);

            this.set("isAvailable", true);
            this.set("canExecute", this.canExecute);
        },

        _onModelChange: function () {
            // summary:
            //      Updates canExecute after the model has been updated.
            // tags:
            //      protected

            // Reset default value
            this.set("isAvailable", true);
            this.set("canExecute", this.canExecute);
            this.set("active", epi.areEqual(this.value, this.selectedValue));

            when(this.model.isUseable(), lang.hitch(this, function (isUseable) {
                this.set("canExecute", isUseable);
            }));
        },

        _execute: function () {
            // summary:
            //      Subscirbe/Unsubscribe channel
            // tags:
            //      protected

            return when(all({
                subscribeMap: this.model.get("subscribeMap"),
                currentContext: this.model.getCurrentContext()
            }), lang.hitch(this, function (results) {
                var subscribeMap = results.subscribeMap;

                var await,
                    methodName = "";

                if (subscribeMap) {
                    // selected another
                    // 1. un-selected another => unsubscribe => subscirbeMap is not null, this.active is true, value is not equal 0
                    // 2. select another => subscribe => subscribeMap is not null, this.active is true, value is not equal 0
                    if (this.value) {
                        methodName = this.active ? "unSubscribe" : "subscribe";
                    } else {
                        // 3. select default => unsubscribe => subscribeMap is not null, this.active is true, value is 0
                        methodName = "unSubscribe";
                    }
                } else {
                    // selected default
                    methodName = this.value ? "subscribe" : "";
                }

                if (methodName) {
                    var contentLink = this.value == ContentCollaborationSettings.SubscribeTypes.All && subscribeMap ?
                        subscribeMap.contentLink : results.currentContext.id;
                    this.model[methodName](contentLink, this.value);
                } else {
                    // Just update command model
                    this.model.updateCommandsModel();
                }

            }));
        }
    });
});