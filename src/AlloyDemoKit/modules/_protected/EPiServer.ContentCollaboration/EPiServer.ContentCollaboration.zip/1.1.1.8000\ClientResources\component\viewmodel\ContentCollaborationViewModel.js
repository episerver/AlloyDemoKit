﻿define([
// Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/array",

    "dojo/Deferred",
    "dojo/promise/all",
    "dojo/Stateful",
    "dojo/when",

// Dojox
    "dojox/html/entities",

// EPi
    "epi",
    "epi/dependency",
    "epi/shell/command/withConfirmation",
    "epi/shell/command/_CommandProviderMixin",
    "epi/shell/TypeDescriptorManager",
    "epi/shell/widget/dialog/Confirmation",

// EPi CMS
    "epi-cms/_ContentContextMixin",
    "epi-cms/contentediting/ContentActionSupport",
    "epi-cms/core/ContentReference",

// CA Add-on
    "epi-contentcollaboration/ContentCollaborationSettings",

//CA Add-on commands
    "epi-contentcollaboration/component/command/EditFeedItem",
    "epi-contentcollaboration/component/command/DeleteFeedItem",
    "epi-contentcollaboration/component/command/SubscribeContent",
    "epi-contentcollaboration/component/command/ChangeNotificationEmail",


// Resources
    "epi/i18n!epi/cms/nls/episerver.components.contentcollaboration"

], function (
// Dojo
    declare,
    lang,
    array,

    Deferred,
    all,
    Stateful,
    when,

// Dojox
    htmlEntities,

// EPi
    epi,
    dependency,
    withConfirmation,
    _CommandProviderMixin,
    TypeDescriptorManager,
    Confirmation,

// EPi CMS
    _ContentContextMixin,
    ContentActionSupport,
    ContentReference,

// CA Add-on
    ContentCollaborationSettings,

//CA Add-on commands
    EditFeedItem,
    DeleteFeedItem,
    SubscribeContent,
    ChangeNotificationEmail,

// Resources
    res

) {
    // summary:
    //      View model of ContentCollaboration component
    // module:
    //      "epi-contentcollaboration/component/ContentCollaborationViewModel"

    return declare([Stateful, _CommandProviderMixin, _ContentContextMixin], {

        // feedEchoService: Object
        //      Singleton instance of FeedEchoService.
        feedEchoService: null,

        // store: Object
        //      JsonRest store to get list or children
        store: null,

        // contentSubscribeStore: Object
        //      Jsonrest store to get subscribes or current subscribe state.
        contentSubscribeStore: null,

        // users: Array
        //      Get list selected users or all users (null)
        users: null,

        // queryOptions: Object
        //      The parameters that passed to server.
        queryOptions: null,

        // selectedItem: Object
        //      A selected row on grid or tree
        selectedItem: null,

        postscript: function () {
            // summary:
            //      Create new instance of ContentCollaborationViewModel
            // tags:
            //      public

            this.inherited(arguments);

            this._setupStore();

            this._resetShowAllCommentItem();

            this._setupCommands();

            this.updateCommandsModel();
        },

        _setupStore: function () {
            // summary:
            //      Get store and decorate it.
            // tags:
            //      private

            var self = this,
                registry = dependency.resolve("epi.storeregistry");

            this.feedEchoService = dependency.resolve("epi.contentcollaboration.signalr.feedservice");
            this.feedEchoService.on("create", lang.hitch(this, function (item) {

                this.set("receivedItem", item);

                // Reset model for all commands to update it's status
                this.updateCommandsModel();

                if (this._shouldShowAllCommentItem(item)) {
                    when(this.store.get(item.parentFeedId), lang.hitch(this, function (result) {
                        if (result && result.commentNumber > ContentCollaborationSettings.MaxDisplayItems) {
                            this.set("showAllCommentItem", result);
                        }
                    }));
                }
            }));

            this.feedEchoService.on("channeljoined", lang.hitch(this, function (item) {
                this.set("channelJoined", true);
            }));

            this.feedEchoService.watch("ready", lang.hitch(this, function (name, oldValue, newValue) {
                if (newValue) {
                    this.buildQueryOptions();
                }
            }));

            this.feedEchoService.on(ContentCollaborationSettings.SubscriptionActions.UPDATE, lang.hitch(this, function (item) {
                this.subscribeMap = item;
                // Update command's status
                this.updateCommandsModel();
            }));

            // Get content activity subscribe store
            this.contentSubscribeStore = this.contentSubscribeStore || registry.get("epi.contentcollaboration.contentsubscription");

            this.store = this.store || registry.get("epi.contentcollaboration");
            // Delegate light store to inject new methods: mayHaveChildren and getChildren
            this.store = lang.mixin(this.store, {
                mayHaveChildren: function (/*Object*/feedItem) {
                    // summary:
                    //      Check collapse / expand state
                    // tags:
                    //      public

                    // Always expand and create observer on each item, except 'Comment' type
                    // At the moment, we do not support multi-levels in the Feed's comment
                    return !epi.areEqual(feedItem.feedType, ContentCollaborationSettings.FeedTypes.Comment);
                },

                getChildren: function (/*Object*/feedItem, options) {
                    // summary:
                    //      Get comments for the feed item
                    // tags:
                    //      public

                    var showAllCommentItem = self.get("showAllCommentItem");
                    var isShowAllComment = showAllCommentItem && epi.areEqual(showAllCommentItem.id, feedItem.id);
                    var query = {
                        parentFeedId: feedItem.id,
                        contentLink: self.feedEchoService.currentChannel.id,
                        isShowAll: isShowAllComment
                    };

                    lang.mixin(options, {
                        ignore: ["contentLink", "isShowAll"],
                        sort: [{ attribute: "createdDate", descending: false }]
                    });
                    return this.query(query, options);
                }
            });
        },

        contentContextChanged: function (ctx, callerData) {
            // summary:
            //      Called when the currently loaded content changes. I.e. a new content data object is loaded into the preview area.
            // tags:
            //      protected

            // set subscribeMap as null to force get updated subscribeMap from server
            this.subscribeMap = null;

            this.buildQueryOptions();
            this.updateCommandsModel();

            this._resetShowAllCommentItem();
        },

        isUseable: function () {
            // summary:
            //      Check whethers current user is useable or not on the content.
            // tags:
            //      public

            return when(all({ contentData: this.getCurrentContent(), context: this.getCurrentContext() }), lang.hitch(this, function (result) {
                var contentData = result.contentData,
                    context = result.context,

                    hasAccess = ContentActionSupport.hasAccess(contentData.accessMask, ContentActionSupport.accessLevel[ContentActionSupport.action.Edit]),
                    languageAvailable = (context && context.languageContext && context.languageContext.language === context.languageContext.preferredLanguage),
                    isSupportedType = !TypeDescriptorManager.isBaseTypeIdentifier(contentData.typeIdentifier, "episerver.core.icontentmedia"),

                    restrictMessage;

                if (!hasAccess) {
                    restrictMessage = lang.replace(res.noaccessright, [htmlEntities.encode(contentData.name)]);
                } else if (!isSupportedType) {
                    restrictMessage = lang.replace(res.notsupporttype, [htmlEntities.encode(contentData.name)]);
                } else if(!languageAvailable){
                    restrictMessage = lang.replace(res.notavailablelanguage, [htmlEntities.encode(contentData.name)]);
                }

                this.set("restrictMessage", restrictMessage);
                return hasAccess && languageAvailable && isSupportedType;
            }));
        },

        updateCommandsModel: function (/*String*/category) {
            // summary:
            //      Update commands model.
            // tags:
            //      private

            array.forEach(this.getCommandsByCategory(category), function (command) {
                command.set("model", this);
            }, this);
        },

        getCommandsByCategory: function (/*string*/category, /*bool*/isAvailable) {
            // summary:
            //      Gets available commands by category
            // tags:
            //      public

            var commands = this.get("commands");

            // Filters by category.
            if (category) {
                commands = commands.filter(function (cmd) {
                    return cmd.category === category;
                }, this);
            }

            // Filters by state.
            if (isAvailable) {
                commands = commands.filter(function (cmd) {
                    return cmd.isAvailable === isAvailable;
                }, this);
            }

            return commands;
        },

        _shouldShowAllCommentItem: function (item) {
            // summary:
            //      Check whether should show on comment item or not.
            // tags:
            //      private

            if (!item) {
                return false;
            }

            var showAllCommentItem = this.get("showAllCommentItem");
            return item.feedType == ContentCollaborationSettings.FeedTypes.Comment && !epi.areEqual(showAllCommentItem.id, item.parentFeedId);
        },

        _resetShowAllCommentItem: function () {
            // summary:
            //      Reset default for showAllCommentItem to VirtualRoot.
            // tags:
            //      private

            this.set("showAllCommentItem", { id: ContentCollaborationSettings.VirtualRoot });
        },

        _buildDeleteFeedItemSettings: function () {
            // summary:
            //      Create a delete feed item settings for delete command.
            // tags:
            //      private

            var deleteFeedItemSettings = {
                cancelActionText: res.cancelbutton,
                setFocusOnConfirmButton: true,
                confirmActionText: res.deletefeeditemtitle,
                description: res.deletefeeditemdescription,
                title: res.deletefeeditemtitle
            };

            var currentItem = this.selectedItem;
            if (currentItem && currentItem.commentNumber && currentItem.commentNumber > 0) {
                lang.mixin(deleteFeedItemSettings, {
                    description: res.deletefeeditemandchildrendescription,
                });
            }

            return deleteFeedItemSettings;
        },

        _setupCommands: function () {
            // summary:
            //      Setup commands for the widget.
            // tags:
            //      private

            var commands = {
                /* Commands for context menu */
                "edit": {
                    command: new EditFeedItem({ model: this }),
                    order: 1
                },
                "delete": {
                    command: withConfirmation(new DeleteFeedItem(), lang.hitch(this, function (settings) {

                        var deferred = new Deferred(),
                            dialog = new Confirmation(lang.mixin(settings, this._buildDeleteFeedItemSettings()));

                        dialog.connect(dialog, "onAction", function (confirm) {
                            if (confirm) {
                                deferred.resolve();
                            }
                        });

                        dialog.show();

                        return deferred;
                    }), {}),
                    order: 2
                },

                /* Commands for toolbar settings position */
                "subscribe": {
                    command: new SubscribeContent(),
                    order: 3
                },

                "changeemail": {
                    command: new ChangeNotificationEmail(),
                    order: 4
                },

                sort: function () {
                    var cmds = [];
                    for (var key in this) {
                        if (key !== "toArray" && key !== "sort" && this.hasOwnProperty(key)) {
                            var index = this[key].order;
                            if (!index) {
                                index = 100;
                            }
                            this[key].command.set("order", index);
                            cmds.push([index, this[key].command]);
                        }
                    }

                    cmds.sort(function (a, b) {
                        return a[0] - b[0];
                    });

                    return cmds;
                },
                toArray: function () {
                    var sortedCommand = this.sort();
                    var cmds = [];
                    array.forEach(sortedCommand, function (key) {
                        cmds.push(key[1]);
                    });

                    return cmds;
                }
            };

            this._commandRegistry = lang.mixin(this._commandRegistry, commands);
            this.set("commands", this._commandRegistry.toArray());
        },

        buildQueryOptions: function () {
            // summary:
            //      Build query object to get list (Comments or Status)
            // tags:
            //      public

            if (!this.feedEchoService.get("ready")) {
                return;
            }

            return when(this.isUseable(), lang.hitch(this, function (isUseable) {

                // Don't query back to server when user don't has access.
                if (!isUseable) {
                    return;
                }

                var results = {
                    query: {
                        parentFeedId: ContentCollaborationSettings.VirtualRoot,
                        contentLink: this.feedEchoService.currentChannel.id
                    },
                    options: {
                        users: this.users,
                        sort: [{ attribute: "createdDate", descending: true }],
                        comparers: {
                            "users": lang.hitch(this, function (queryValue, instance) {
                                return !queryValue
                                        || (queryValue instanceof Array && queryValue.length === 0)
                                        || !!instance.createdBy && array.some(queryValue, function (user) {
                                            return epi.areEqual(user, instance.createdBy);
                                        });
                            })
                        }
                    }
                };

                this.set("queryOptions", results);
            }));
        },

        deleteItem: function () {
            // summary:
            //      Delete current selected feed item.
            // tags:
            //      public

            if (this.selectedItem) {
                when(this.feedEchoService.deleteItem(this.selectedItem), lang.hitch(this, function () {
                    if (this._shouldShowAllCommentItem(this.selectedItem)) {
                        when(this.store.get(this.selectedItem.parentFeedId), lang.hitch(this, function (result) {
                            if (result) {
                                this.set("showAllCommentItem", result);
                                return;
                            }
                            this._resetShowAllCommentItem();
                        }));
                    }
                }));
            }
        },

        _selectedItemSetter: function (/*FeedItem*/item) {
            // summary:
            //      Set selected item when selected item is changed or updated.
            // tags:
            //      public

            this.selectedItem = item;

            if (this.editing) {
                when(this._updateItem(), lang.hitch(this, function () {
                    // Notify grid to stop editing
                    this.set("editing", false);
                }));
            }
        },

        _updateItem: function () {
            // summary:
            //      Update current editing item.
            // tags:
            //      private

            if (this.selectedItem) {
                return this.feedEchoService.updateItem(this.selectedItem);
            }
        },

        editItem: function () {
            // summary:
            //      Edit current selected feed item.
            // tags:
            //      public

            // Notify grid to start editing
            this.set("editing", true);
        },

        //---------------------------------------------------------------
        // region subscribe
        //---------------------------------------------------------------

        _updateSubscribeMap: function () {
            // summary:
            //      Change subscribe state and build query option
            // tags:
            //      public

            this.buildQueryOptions();

            // Update command's status
            this.updateCommandsModel();
        },

        subscribe: function (/*ContentReference*/contentLink, /*int*/ subscriptionType) {
            // summary:
            //      Change subscribe state.
            // tags:
            //      public

            return when(this.feedEchoService.subscribe(contentLink, subscriptionType), lang.hitch(this, function (result) {
                if (result) {
                    this._updateSubscribeMap();
                }
                return result;
            }));
        },

        unSubscribe: function (/*ContentReference*/contentLink) {
            // summary:
            //      Change subscribe state.
            // tags:
            //      public

            return when(this.feedEchoService.unSubscribe(contentLink), lang.hitch(this, function () {
                this._updateSubscribeMap();
            }));
        },

        unSubscribeAll: function () {
            // summary:
            //      Un subscribe all channel.
            // tags:
            //      public

            return when(this.feedEchoService.unSubscribeAll(), lang.hitch(this, function () {
                this._updateSubscribeMap();
            }));
        },

        removeSubscribe: function (/*ContentReference*/contentLink) {
            // summary:
            //      Remove an subscribe channel
            // tags:
            //      public

            return when(this.feedEchoService.removeSubscribe(contentLink), lang.hitch(this, function () {
                this._updateSubscribeMap();
            }));
        },

        savePersonalizeSetting: function (emailNotificationType) {
            // summary:
            //      Change the personalize setting (email notification type).
            // tags:
            //      public

            return when(this.feedEchoService.saveEmailNotificationType(emailNotificationType), lang.hitch(this, function () {
                this.set("emailNotificationType", emailNotificationType);
            }));
        },

        _canSubscribeGetter: function () {
            // summary:
            //      Check whether current user can subscirbe on this content or not.
            // tags:
            //      public

            return this.isUseable();
        },

        _subscribeMapGetter: function () {
            // summary:
            //      Gets subscribe map by current user and current content link.
            // tags:
            //      public

            return when(this.getCurrentContent(), lang.hitch(this, function (content) {
                return when(this.contentSubscribeStore.query({ query: "getsubscription", contentLink: content.contentLink }), lang.hitch(this, function (subscribe) {
                    this.subscribeMap = subscribe;
                    return subscribe;
                }));
            }));
        },

        _emailNotificationTypeGetter: function () {
            // summary:
            //      Gets email notification type.
            // tags:
            //      public

            var selectedValue = this.emailNotificationType;
            return (selectedValue == undefined || selectedValue == null) ?
                            ContentCollaborationSettings.personalizeSettings.emailNotificationType
                            : selectedValue;
        },

        _emailNotificationTypeSetter: function (emailNotificationType) {
            // summary:
            //      Sets email notification type.
            // tags:
            //      public

            this.emailNotificationType = emailNotificationType;
            this.updateCommandsModel();
        }
    });
});