﻿define([
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/aspect",
    "dojo/Deferred",
    "dojo/promise/all",
    "dojo/store/Cache",
    "dojo/store/Memory",
    "dojo/when",

    "dijit/Destroyable",
// epi
    "epi/_Module",
    "epi/routes",
    "epi/shell/store/Throttle",
    "epi-cms/core/ContentReference",
    "epi-cms/contentediting/ContentActionSupport",
    "epi-cms/store/CustomQueryEngine",

// CA
    "epi-contentcollaboration/component/command/EmailNotification",
    "epi-contentcollaboration/signalr/FeedEchoService",
    "epi-contentcollaboration/ContentCollaborationSettings"
],

function (
// dojo
    array,
    declare,
    lang,

    aspect,
    Deferred,
    all,
    Cache,
    Memory,
    when,

    Destroyable,
// epi
    _Module,
    routes,
    Throttle,
    ContentReference,
    ContentActionSupport,
    CustomQueryEngine,

// CA
    EmailNotification,
    FeedEchoService,
    ContentCollaborationSettings
) {

    return declare([_Module, Destroyable], {

        // keep settings and information from module.config and this addon's custom ShellModule
        _settings: null,

        // _eventHandlers: dojo/store/Memory
        //      Contains all events that're handled.
        _eventHandlers: null,

        constructor: function (settings) {
            this._settings = settings;
            lang.mixin(ContentCollaborationSettings, settings);
            this._eventHandlers = new Memory({ data: [], id: "id" });
        },

        initialize: function () {
            // summary:
            //		Initialize module

            this.inherited(arguments);

            // Initialize data stores
            this._initializeStores();
        },

        _initializeStores: function () {
            // summary:
            //      Initialize data stores

            var registry = this.resolveDependency("epi.storeregistry"),
                light = registry.create("epi.contentcollaboration", this._getRestPath("contentcollaboration"), { id: "id", queryEngine: CustomQueryEngine }),
                feedEchoService = new FeedEchoService(this._settings.signalrSettings),   // init the SignalR service with the proper base signalrUrl
                users = registry.create("epi.contentcollaboration.users", this._getRestPath("users"), { id: "name" }),
                userMemoryStore = new Memory({ id: "name", queryEngine: CustomQueryEngine }),
                userCacheStore = new Cache(Throttle(users, "query"), userMemoryStore),
                contentSubscription = registry.create("epi.contentcollaboration.contentsubscription", this._getRestPath("contentsubscription"), { id: "id" });

            // Spy content event:
            this._spyContentEvent(feedEchoService);

            this.own(
                // Decorate user store to inject content link in query params
                aspect.around(users, "query", function (originalMethod) {
                    return function (query, options) {
                        return when(feedEchoService.getCurrentContext(), function (context) {
                            lang.mixin(query, { contentLink: context.id })
                            return originalMethod.apply(users, [query, options]);
                        });
                    }
                }),
                aspect.around(users, "get", function (originalMethod) {
                    return function (id, options) {
                        return when(feedEchoService.getCurrentContext(), function (context) {
                            lang.mixin(options, { contentLink: context.id })
                            return originalMethod.apply(users, [id, options]);
                        });
                    }
                })
            );

            // Decorate userCacheStore to cache data when query users/groups.
            userCacheStore = lang.delegate(userCacheStore, {
                query: function (query, options) {
                    return when(userMemoryStore.query(query, options), function (result) {

                        if (result && result.length > 0) {
                            return result;
                        }

                        return when(users.query(query, options), function (result) {
                            if (result && result.length > 0) {
                                array.forEach(result, function (item) {
                                    userMemoryStore.put(item);
                                });
                            }
                            return result;
                        });
                    });
                }
            });

            registry.add("epi.contentcollaboration.users.cache", userCacheStore);
            this.registerDependency("epi.contentcollaboration.signalr.feedservice", feedEchoService);

            // Notify the store (light) of changes form the server
            feedEchoService.on(ContentCollaborationSettings.FeedActions.CREATE, function (/*Object*/item) {

                light.notify(item, item.id, ContentCollaborationSettings.FeedActions.CREATE);
                contentSubscription.notify(item, item.id, ContentCollaborationSettings.FeedActions.CREATE);
                if (!epi.areEqual(item.parentFeedId, ContentCollaborationSettings.VirtualRoot)) {
                    // Try patch cache
                    when(light.get(item.parentFeedId), function (object) {
                        if (!object.commentNumber) {
                            light.patchCache(lang.mixin(object, { "commentNumber": 1 }));
                        }
                    });
                }
            });

            feedEchoService.on(ContentCollaborationSettings.FeedActions.UPDATE, function (/*Object*/item) {
                light.notify(item, item.id, ContentCollaborationSettings.FeedActions.UPDATE);
                contentSubscription.notify(item, item.id, ContentCollaborationSettings.FeedActions.UPDATE);
            });

            feedEchoService.on(ContentCollaborationSettings.FeedActions.DELETE, function (/*Object*/item) {
                if (!epi.areEqual(item.parentFeedId, ContentCollaborationSettings.VirtualRoot)) {
                    // Try update parent item
                    when(light.get(item.parentFeedId), function (parentItem) {
                        if (parentItem.commentNumber == 1) {
                            light.notify(parentItem, parentItem.id, ContentCollaborationSettings.FeedActions.UPDATE);
                            return;
                        }
                    });
                }

                light.notify(null, item.id, ContentCollaborationSettings.FeedActions.DELETE);
                contentSubscription.notify(null, item.id, ContentCollaborationSettings.FeedActions.DELETE);
            });

            // update settings from the server
            feedEchoService.on(ContentCollaborationSettings.ConfigruationActions.UPDATE, function (/*Object*/settings) {
                lang.mixin(ContentCollaborationSettings, settings);
            });

            // Init feed echo service
            feedEchoService.initialize();

            // Notifications e-mail address
            var personalizeSettings = ContentCollaborationSettings.personalizeSettings;
            if ((personalizeSettings && !personalizeSettings.email && !personalizeSettings.isShowedNoEmailNotification)) {
                // Create new NotificationEmail command here and execute it!
                var emailNotificationCmd = new EmailNotification();
                emailNotificationCmd.execute();
            }
        },

        _getRestPath: function (name) {
            return routes.getRestPath({ moduleArea: "episerver.contentcollaboration", storeName: name });
        },

        _buildHandlerKey: function (/*ContentReference*/contentLink, /*String*/methodName) {
            // summary:
            //      Build id for each handler.
            // tags:
            //      private

            return lang.replace("{0}__{1}", [contentLink, methodName]);
        },

        _tryListenEvent: function (contentLink, eventName) {
            // summary:
            //      We don't want listen an event twice
            // tags:
            //      private

            var handlerKey = this._buildHandlerKey(contentLink, eventName);
            var handler = this._eventHandlers.get(handlerKey);
            if (!handler) {
                this._eventHandlers.put({ id: handlerKey });
                return true;
            }

            return false;
        },

        _spyContentEvent: function (feedEchoService) {
            // summary: Spy content event
            //      You Published
            //
            //      You set Ready to Publish
            //      You Rejected Changes
            //
            //      You Scheduled for Publish 2015-02-15 9:05 PM
            //      You Canceled Scheduled Publishing
            //
            //      You started editing
            //      You Created a Draft
            //
            //      You Reverted to Published
            //
            //      You set this to Primary Draft
            //      You set another Draft to Primary
            // tags:
            //      private

            var self = this,
                registry = this.resolveDependency("epi.storeregistry"),
                contentDataStore = registry.get("epi.cms.contentdata"),
                contentVersionStore = registry.get("epi.cms.contentversion"),
                editingCommands = this.resolveDependency("epi.cms.contentEditing.command.Editing");

            this.own(
                //--------------------------------------------------------------------------------------
                // Listen change content status actions
                //--------------------------------------------------------------------------------------
                aspect.around(contentDataStore, "executeMethod", function (originalMethod) {
                    return function (method, id, data, options) {
                        return when(originalMethod.apply(contentDataStore, arguments), function (result) {

                            if (result && result.success && epi.areEqual(method, "ChangeStatus")) {
                                var saveAction = ContentActionSupport.saveAction,
                                    action = ContentActionSupport.action,
                                    currentAction = data && data.action;
                                switch (currentAction) {
                                    case action.Reject:
                                        when(contentDataStore.get(id), function (currentContent) {
                                            if (epi.areEqual(currentContent.status, ContentActionSupport.versionStatus.DelayedPublish)) {
                                                // Detected: You Canceled Scheduled Publishing
                                                feedEchoService.spyEvent(id, ContentCollaborationSettings.ActivityTypes.RemovedScheduleToPublish);
                                            } else {
                                                // Detected: You Rejected Changes
                                                feedEchoService.spyEvent(id, ContentCollaborationSettings.ActivityTypes.Rejected);
                                            }
                                        });
                                        break;
                                    case action.Publish:
                                        // Detected: You Published
                                        feedEchoService.spyEvent(id, ContentCollaborationSettings.ActivityTypes.Published);
                                        break;
                                    case action.CheckIn:
                                        // Detected: You set Ready to Publish
                                        feedEchoService.spyEvent(id, ContentCollaborationSettings.ActivityTypes.CheckedIn);
                                        break;
                                    case saveAction.CheckIn | saveAction.DelayedPublish | saveAction.ForceCurrentVersion:
                                        // Detected: You Scheduled for Publish 2015-02-15 9:05 PM
                                        feedEchoService.spyEvent(id, ContentCollaborationSettings.ActivityTypes.ScheduleToPublish);
                                        break;
                                    default:
                                        break;
                                }
                            }

                            return result;
                        })
                    }
                }),

                //--------------------------------------------------------------------------------------
                // Listen contentDataStore store to detect create new content action
                //--------------------------------------------------------------------------------------
                aspect.around(contentDataStore, "put", function (originalMethod) {
                    return function (content) {
                        return when(originalMethod.apply(contentDataStore, arguments), function (contentLink) {
                            feedEchoService.spyEvent(contentLink, ContentCollaborationSettings.ActivityTypes.NewDraft);
                            return contentLink;
                        })
                    }
                }),

                //--------------------------------------------------------------------------------------
                // Listen ContentVersion store to detect create new version action:
                //--------------------------------------------------------------------------------------

                //--------------------------------------------------------------------------------------
                // + Set Common Draft and Set Another To Draft action also
                //--------------------------------------------------------------------------------------
                aspect.around(contentVersionStore, "patch", function (originalMethod) {
                    return function (/*Object*/object, /*dojo.store.api.Store.PutDirectives?*/options) {
                        var dfd = new Deferred(),
                            args = arguments;

                        when(contentVersionStore.query({ query: "getcommondraftversion", contentLink: object.contentLink }), function (currentCommonDraft) {
                            when(originalMethod.apply(contentVersionStore, args), function (result) {
                                // Don't force other promise method wait any more
                                dfd.resolve(result);

                                // this patch method is for set primary draft version.
                                if (object && object.isCommonDraft) {
                                    // Deteced: You set this to Primary Draft
                                    feedEchoService.spyEvent(object.contentLink, ContentCollaborationSettings.ActivityTypes.PrimaryDraft);
                                }

                                if (currentCommonDraft && !epi.areEqual(currentCommonDraft.contentLink, object.contentLink)) {
                                    // Detected: You set another Draft to Primary
                                    feedEchoService.spyEvent(currentCommonDraft.contentLink, ContentCollaborationSettings.ActivityTypes.SetAnotherPrimaryDraft);
                                }
                            });
                        });

                        return dfd;
                    }
                }),

                //--------------------------------------------------------------------------------------
                // + Create New Draft / New Draft From Here action
                //--------------------------------------------------------------------------------------
                aspect.around(contentVersionStore, "put", function (originalMethod) {
                    return function (object, options) {
                        return when(originalMethod.apply(contentVersionStore, arguments), function (newVersion) {
                            // Detected: You Created a Draft
                            feedEchoService.spyEvent(object.originalContentLink, ContentCollaborationSettings.ActivityTypes.NewDraftFromHere);
                            // Detected: You started editing
                            feedEchoService.spyEvent(newVersion.contentLink, ContentCollaborationSettings.ActivityTypes.NewDraft);

                            return newVersion;
                        });
                    }
                }, true),

                //--------------------------------------------------------------------------------------
                // + Revert To Published action
                //--------------------------------------------------------------------------------------
                editingCommands.revertToPublished.watch("model", function (name, oldModel, newModel) {
                    if (newModel && self._tryListenEvent(newModel.contentLink, "revertToPublished")) {
                        aspect.before(newModel, "revertToPublished", function () {
                            self._isRevertingToPublished = true;
                        });
                    }
                }),

                aspect.around(contentVersionStore, "remove", function (originalMethod) {
                    return function (contentLink, options) {
                        var args = arguments,
                            contentReference = new ContentReference(contentLink);
                        return when(contentVersionStore.get(contentReference.toString()), function (contentVersion) {
                            return when(originalMethod.apply(contentVersionStore, args), function (result) {
                                var activityType = ContentCollaborationSettings.ActivityTypes.DeleteContentVersion;
                                if (self._isRevertingToPublished) {
                                    // Detected: You Reverted to Published
                                    activityType = ContentCollaborationSettings.ActivityTypes.RevertToPublished;
                                }
                                feedEchoService.spyEvent(contentReference.toString(), activityType, { "contentName": contentVersion.name, "contentLanguage": contentVersion.language, "deleteLanguageBranch" : !!options });

                                self._isRevertingToPublished = false;
                                return result;
                            });
                        });
                    }
                })
                //--------------------------------------------------------------------------------------
                // End of: Listen ContentVersion store to detect create new version action
                //--------------------------------------------------------------------------------------

            );
        }
    });
});