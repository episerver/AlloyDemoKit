﻿define("epi-contentcollaboration/component/command/ForAllItems", [
//Dojo base
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/promise/all",
    "dojo/when",
    "dojo/Deferred",

// Dijit
    "dijit/Menu",
    "dijit/popup",
    "dijit/CheckedMenuItem",

// EPi
    "epi/shell/command/_Command",
    "epi/shell/command/ToggleCommand",
    "epi/shell/command/builder/MenuBuilder",
    "epi-cms/contentediting/ContentActionSupport",

//CA command
    "epi-contentcollaboration/component/command/SendEmailCommandBase",
    "epi-contentcollaboration/component/command/PopupCommandBase",
    "epi-contentcollaboration/ContentCollaborationSettings",

// Resources
    "epi/i18n!epi/cms/nls/episerver.components.contentcollaboration"

], function (
// Dojo base
    array,
    declare,
    lang,

    all,
    when,
    Deferred,

// Dijit
    Menu,
    popupManager,
    CheckedMenuItem,

// EPi
    _Command,
    ToggleCommand,
    MenuBuilder,
    ContentActionSupport,

// CA command
    SendEmailCommandBase,
    PopupCommandBase,
    ContentCollaborationSettings,

// Resources
    resources

    ) {
    return declare([PopupCommandBase], {

        category: "setting",

        label: resources.forallitems,

        popup: null,

        popupClass: Menu,

        selectedValue: null,

        postscript: function () {
            this.inherited(arguments);
            this._menuBuilder = new MenuBuilder();
        },

        _onModelChange: function () {
            // summary:
            //      Updates canExecute after the model has been updated.
            // tags:
            //      protected

            // Reset default value
            this.set("isAvailable", true);
            this.set("canExecute", true);

            var commands = this.get("commands"),
                selectedValue = this.model.get("emailNotificationType");

            if (!commands) {
                var commands = [
                    new SendEmailCommandBase({
                        name: "AlwaysSendEmail",
                        label: resources.emailnotificationtypes.always,
                        value: ContentCollaborationSettings.EmailNotificationTypes.Always,
                        selectedValue: selectedValue,
                        model: this.model
                    }),
                    new SendEmailCommandBase({
                        name: "OnlySendEmailWhenNotLoggedIn",
                        label: resources.emailnotificationtypes.whenoffline,
                        value: ContentCollaborationSettings.EmailNotificationTypes.WhenOffline,
                        selectedValue: selectedValue,
                        model: this.model
                    }),
                    new SendEmailCommandBase({
                        name: "NeverSendEmails",
                        label: resources.emailnotificationtypes.never,
                        value: ContentCollaborationSettings.EmailNotificationTypes.Never,
                        selectedValue: selectedValue,
                        model: this.model
                    })
                ];
                this.set("commands", commands);
            } else {
                // update selected value for commands
                array.forEach(commands, function (command) {
                    command.set("selectedValue", selectedValue);
                }, this);
            }
            this.inherited(arguments);
        }
    });
});