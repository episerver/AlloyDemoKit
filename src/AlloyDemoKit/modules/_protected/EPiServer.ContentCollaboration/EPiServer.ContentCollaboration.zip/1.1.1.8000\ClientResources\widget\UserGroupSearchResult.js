﻿define([
// Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Evented",
    "dojo/dom-construct",
    "dojo/dom-style",

// Dojox
    "dojox/widget/Standby",

// Dijit
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dijit/form/_ListMouseMixin",
    "dijit/form/_ComboBoxMenuMixin",

// EPi Framework
    "epi-cms/widget/_ContentListKeyMixin",
    "epi-cms/widget/_ContentListMouseMixin",
    "epi-cms/dgrid/formatters",
    "epi/shell/dgrid/Formatter",

// DGrid
    "dgrid/OnDemandList",
    "dgrid/Selection",
    "dgrid/Keyboard",

// Templates
    "dojo/text!./templates/UserGroupSearchResult.html"
],

function (
// Dojo
    declare,
    lang,
    Evented,
    domConstruct,
    domStyle,

// Dojox
    Standby,

// Dijit
    _WidgetBase,
    _TemplatedMixin,
    _ListMouseMixin,
    _ComboBoxMenuMixin,

// EPi Framework
    _ContentListKeyMixin,
    _ContentListMouseMixin,
    formatters,
    Formatter,

// DGrid
    OnDemandList,
    Selection,
    Keyboard,

// Templates
    template
    ) {

    return declare([_WidgetBase, _TemplatedMixin, Evented, _ListMouseMixin, _ComboBoxMenuMixin, _ContentListKeyMixin, _ContentListMouseMixin], {
        // summary:
        //    A grid to display content list.
        //
        // tags:
        //    public

        // templateString: String
        //      String template of this widget.
        templateString: template,

        // _standby: Standby
        //      The standby object to indicate the loading process for grid.
        //  tags:
        //      Protected
        _standby: null,
        
        postCreate: function () {
            // summary:
            //		Initialize grid for displaying content list.
            // tags:
            //      Protected
            this.inherited(arguments);

            var gridClass = declare([OnDemandList, Selection, Keyboard, Formatter]),
                // Get item's title
                titleSelector = function (item) { return item.name; };

            this.grid = new gridClass({
                formatters: [formatters.contentItemFactory("name", titleSelector, null, null, null, null, false)],
                selectionMode: "single", // for Selection; only select a single row at a time
                cellNavigation: false // for Keyboard; allow only row-level keyboard navigation
            });

            // Hide header of the grid
            this.grid.set("showHeader", false);

            domConstruct.place(this.grid.domNode, this.containerNode);

            // trigger onSelect event when clicking on grid row
            this.grid.on(".dgrid-row:click", lang.hitch(this, function (event) {
                var row = this.grid.row(event);
                if (row) {
                    this._onSelect(row.data);
                }
            }));

            this._standby = new Standby({ target: this.domNode, color: "#fff" }).placeAt(document.body);
            this.own(this._standby);

            // assign the grid container as containerNode, so _ListMouseMixin and _ComboBoxMenuMixin can get the properly container
            this.containerNode = this._getGridContainer();
        },

        startup: function () {
            // summary:
            //		handle processing after any DOM fragments have been actually added to the document.
            // tags:
            //      Protected
            this.inherited(arguments);
            this._standby.startup();
        },

        showStandby: function (show) {
            // summary:
            //		Set standby visibility.
            // tags:
            //      Protected

            if (!this._standby) {
                return;
            }
            if (show) {
                if (!this._standby.isVisible()) {
                    this._standby.show();
                }
            } else {
                this._standby.hide();
            }
        },

        showGrid: function (show) {
            // summary:
            //		Set grid visibility.
            // tags:
            //      Protected
            domStyle.set(this.grid.domNode, "display", show ? "block" : "none");
        },

        _onSelect: function (value) {
            // summary:
            //		Emit onSelect event when an item has been selected.
            // tags:
            //      Private
            this.emit("select", value);
        },

        _getGridContainer: function () {
            // summary:
            //		Returns the grid container, which contains grid rows.
            // tags:
            //      Private
            return this.grid.contentNode;
        },

        createOptions: function (results, options, labelFunc) {
            // summary:
            //		Fills in the items in the list
            // results:
            //		Array of items
            // options:
            //		The options to the query function of the store
            //
            // labelFunc:
            //		Function to produce a label in the drop down list from a dojo.data item

            this.grid.renderArray(results);
            return this.containerNode.childNodes;
        },

        clearResultList: function () {
            // summary:
            //		Clears the entries in the list.

            this.grid.refresh();
        },

        getHighlightedOption: function () {
            // summary:
            //		This will be used to highlight the text in the textbox, to allow screen readers to know what is happening in the menu.
            //      Return null since we don't want this feature.

            return null;
        },

        showErrorMessage: function (show, message) {
            // summary:
            //		Set error message visibility.
            // tags:
            //      Protected

            this.clearResultList();
            this.showStandby(false);
            if (show && message) {
                this.errorMessage.innerHTML = message;
            }
            domStyle.set(this.errorMessage, "display", show ? "block" : "none");
        }
    });
});
