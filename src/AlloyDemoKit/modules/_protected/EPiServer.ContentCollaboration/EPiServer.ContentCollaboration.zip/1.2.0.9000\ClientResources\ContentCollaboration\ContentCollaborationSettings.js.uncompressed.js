﻿define("epi-contentcollaboration/ContentCollaborationSettings", [
// Resources
    "epi/i18n!epi/cms/nls/episerver.components.contentcollaboration"
],

function (
// Resources
    resources
) {

    return {
        VirtualRoot: "6f31b1e0-55c1-48e0-a771-bf415dc601ce",

        FeedTypes: {
            All: 0, // Ignore filtering
            Status: 1, // Update status
            Activity: 2, // Make change on content (Page, Block, MediaData)
            Comment: 4 // Comment on Activity/Status
        },

        FeedActions: {
            CREATE: "create",
            UPDATE: "update",
            DELETE: "delete"
        },

        ConfigruationActions: {
            UPDATE: "globalConfiguration_update"
        },

        SubscriptionActions: {
            UPDATE: "subscription_update"
        },

        IconClassActivityType: {
            None: "epi-iconBubble",
            Created: "epi-iconPlus",
            Saved: "epi-iconPage",
            Rejected: "epi-icon-collab--Rejected",
            Moved: "epi-iconShare",
            Published: "epi-icon-collab--Published",
            Deleted: "epi-iconTrash",
            CheckedIn: "epi-icon-collab--Ready-for-publish",
            DeleteContentVersion: "epi-iconTrash",
            ScheduleToPublish: "epi-icon-collab--Schedule-for-publish",
            NewDraft: "epi-icon-collab--Edit",
            NewDraftFromHere: "epi-icon-collab--Draft", // Create new draft from published/previously published content
            Expired: "epi-icon-collab--Expired",
            PrimaryDraft: "epi-icon-collab--Primary-draft",
            RemovedScheduleToPublish: "epi-icon-collab--Rejected",
            RevertToPublished: "epi-icon-collab--Reverted",
            RemovedExpired: "epi-icon-collab--Rejected",
            SetAnotherPrimaryDraft: "epi-icon-collab--Removed-primary-draft"
        },

        InvertClassActivityType: {
            Rejected: "epi-action-reject",
            Published: "epi-action-acept",
            CheckedIn: "epi-action-acept",
            ScheduleToPublish: "epi-action-acept",
            RemovedScheduleToPublish: "epi-action-reject",
            RevertToPublished: "epi-action-reject"
        },

        SubscribeTypes: {
            None: 0, // For this version only
            All: 1, // For all languages of this item
            LanguageOnly: 2, // For this language only
            VersionUntilPublished: 3 // For the version until next publish
        },

        ActivityTypes: {
            None: 0,
            Created: 1,
            Saved: 2,
            Rejected: 3,
            Moved: 4,
            Published: 5,
            Deleted: 6,
            CheckedIn: 7,
            DeleteContentVersion: 8,
            ScheduleToPublish: 9,
            NewDraft: 10,
            NewDraftFromHere: 11, // Create new draft from published/previously published content
            Expired: 12,
            PrimaryDraft: 13,
            RemovedScheduleToPublish: 14,
            RevertToPublished: 15,
            RemovedExpired: 16,
            SetAnotherPrimaryDraft: 17
        },

        ActionByActivityTypeResourceMap: {
            // References: https://docs.google.com/document/d/17dxxa98GGc_IzJgRCCFCCEoL3dKpANxPY8SWvP4ucXQ/edit
            // Section: UX feedback, graphic design & action texts Mar 17
            // Sub: Action texts - JOAR
            None: "set",
            Created: "set",
            Saved: "set",
            Rejected: "",                       // You Rejected Changes
            Moved: "set",
            Published: "",                      // You Published
            Deleted: "",
            CheckedIn: "set",                   // You set Ready to Publish
            DeleteContentVersion: "",
            ScheduleToPublish: "",              // You Scheduled for Publish 2015-02-15 9:05 PM
            NewDraft: "",                       // You started editing
            NewDraftFromHere: "",               // You Created a Draft
            Expired: "set",
            PrimaryDraft: "set",                // You set Primary Draft
            RemovedScheduleToPublish: "",       // You Canceled Scheduled Publishing
            RevertToPublished: "",              // You Reverted to Published
            RemovedExpired: "set",
            SetAnotherPrimaryDraft: "set"       // You set another Draft to Primary
        },

        EmailNotificationTypes: {
            Never: 0,
            Always: 1,
            WhenOffline: 2
        },

        MaxDisplayItems: 3,

        getActionByActivityTypeLocalization: function (/*string*/activityType) {
            var action = this.ActionByActivityTypeResourceMap[activityType];
            return action ? resources[action] : "";
        },

        getActivityTypeLocalization: function ( /* string */ activityType) {
            return resources.activitytypes[activityType.toLowerCase()];
        },

        getSubscribeTypeLocalization: function ( /*string*/ subscribeTypeName) {
            return resources.subscribetypes[subscribeTypeName.toLowerCase()];
        },

        getEmailNotificationTypeLocalization: function ( /*string*/ emailNotificationTypeName) {
            return resources.emailnotificationtypes[emailNotificationTypeName.toLowerCase()];
        },

        getEnumTypeName: function (/*int*/ value, /*Enum*/ enumType) {
            var name = null;
            for (var item in enumType) {
                if (enumType[item] === value) {
                    name = item;
                    break;
                }
            }
            return name;
        }
    };
});