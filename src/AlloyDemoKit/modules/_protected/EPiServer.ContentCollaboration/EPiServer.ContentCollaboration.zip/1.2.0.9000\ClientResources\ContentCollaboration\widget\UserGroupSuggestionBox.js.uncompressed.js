require({cache:{
'url:epi-contentcollaboration/widget/templates/UserGroupSuggestionBox.html':"﻿<div class=\"epi-tag-people\">\r\n    <span data-dojo-attach-point=\"userGroupContainer\">\r\n        <span class=\"epi-placeholder\">\r\n            <input data-dojo-type=\"dijit/form/TextBox\" data-dojo-attach-point=\"textbox,focusNode\" class=\"epi-tagging-textbox\" />\r\n            <span class=\"dijitPlaceHolder dijitInputField\" data-dojo-attach-point=\"_phspan,placeHolderNode\"></span>\r\n        </span>\r\n    </span>\r\n</div>\r\n"}});
﻿define("epi-contentcollaboration/widget/UserGroupSuggestionBox", [
// Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/event",
    "dojo/dom-attr",

    "dojo/on",
    "dojo/Evented",
    "dojo/keys",

// Dijit
    "dijit/focus",
    "dijit/_HasDropDown",
    "dijit/form/_ComboBoxMenu",
    "dijit/form/_AutoCompleterMixin",
    "dijit/form/TextBox",

// dgrid
    "dgrid/util/misc",

// CA AddOn
    "epi-contentcollaboration/widget/UserGroupSelector",

// Templates
    "dojo/text!./templates/UserGroupSuggestionBox.html",
    "epi/i18n!epi/cms/nls/episerver.components.contentcollaboration"
],

function (
// Dojo
    declare,
    lang,
    event,
    domAttr,

    on,
    Evented,
    keys,

// Dijit
    focusManager,
    _HasDropDown,
    _ComboBoxMenu,
    _AutoCompleterMixin,
    TextBox,

// dgrid
    miscUtil,

    UserGroupSelector,
    template,
    resources
) {

    return declare([TextBox, _HasDropDown, _AutoCompleterMixin, Evented], {
        // summary:
        //    A suggestion box, which will drop a list down when user input a string to a textbox to filter item in a pre-defined list.
        //
        // tags:
        //    public

        // templateString: String
        //      String template of this widget.
        templateString: template,

        // defaultDelay: [Integer]
        //      Delay in milliseconds between when user types something and we start
        //      searching based on that value.
        // tags:
        //      protected
        defaultDelay: 500,

        // dropDownClass: [protected extension] Function String
        //      Dropdown widget class, which would be used to create a widget, to show the search result.
        //      Subclasses should specify this.
        dropDownClass: _ComboBoxMenu,

        userGroupSelectorWidget: null,

        buildRendering: function () {
            this.inherited(arguments);

            domAttr.set(this.textbox, "autocomplete", "off");
            domAttr.set(this.textbox, "aria-haspopup", "true");
        },

        postCreate: function () {
            // summary:
            //      Post widget creation. Initialize event for buttons
            // tags:
            //      Protected

            this.inherited(arguments);

            if (!this.userGroupSelectorWidget) {
                this.userGroupSelectorWidget = new UserGroupSelector();
                this.userGroupSelectorWidget.placeAt(this.userGroupContainer, "first");
            }

            this.connect(this, "_onInput",
                miscUtil.debounce(lang.hitch(this, function (evt) {
                    this._valueChanged(evt);
                }), null, this.defaultDelay));


            this.set("placeHolder", resources.notifygroups);
            on(this.placeHolderNode, "click", lang.hitch(this, this.focus));
        },

        focus: function () {
            // summary:
            //      Set focus for textbox
            // tags:
            //      public

            focusManager.focus(this.textbox);
        },

        _setValueAttr: function (value) {
            // summary:
            //      Set value for textbox
            // tags:
            //      private

            if (this.userGroupSelectorWidget) {
                this.userGroupSelectorWidget.set("value", value);
            }
        },

        _getValueAttr: function () {
            // summary:
            //      Set value for textbox
            // tags:
            //      private

            if (this.userGroupSelectorWidget) {
                return this.userGroupSelectorWidget.get("value");
            }
            return null;
        },

        _valueChanged: function (/* Event */evt) {
            // summary:
            //      Trigger when textbox value has been changed
            // tags:
            //      private

            if (evt && evt.keyCode) {
                switch (evt.keyCode) {
                    case keys.PAGE_DOWN:
                    case keys.DOWN_ARROW:
                    case keys.PAGE_UP:
                    case keys.SPACE:
                    case keys.UP_ARROW:
                    case keys.LEFT_ARROW:
                    case keys.RIGHT_ARROW:
                        // do nothing when navigating, selecting text
                        return;
                }
            }
        }
    });
});