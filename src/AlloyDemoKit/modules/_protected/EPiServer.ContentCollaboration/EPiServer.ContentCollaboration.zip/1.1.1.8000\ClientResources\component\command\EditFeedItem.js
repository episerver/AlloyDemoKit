﻿define([
    // Dojo base
    "dojo/_base/declare",

// CA-Addon
   "epi-contentcollaboration/component/command/CommandBase",

// Resources
    "epi/i18n!epi/cms/nls/episerver.shared"

], function (
// Dojo base
    declare,

// CA-Addon
    CommandBase,

// Resources
    sharedResources

    ) {
    return declare([CommandBase], {

        category: "context",

        iconClass: "epi-iconPen",

        label: sharedResources.action.edit,

        _execute: function () {
            // summary:
            //      Executes this command assuming canExecute has been checked.
            // tags:
            //      protected

            this.model.editItem();
        }
    });
});