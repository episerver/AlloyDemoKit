﻿define([
// Dojo
    "dojo/_base/array",
    "dojo/_base/connect",
    "dojo/_base/declare",
    "dojo/_base/event",
    "dojo/_base/fx",
    "dojo/_base/lang",

    "dojo/aspect",
    "dojo/dom-construct",
    "dojo/dom-geometry",
    "dojo/dom-style",
    "dojo/dom-class",
    "dojo/fx",
    "dojo/fx/easing",
    "dojo/on",
    "dojo/query",
    "dojo/Stateful",
    "dojo/when",
    "dojo/store/Memory",
    "dojo/NodeList-traverse",
    "dojo/ready",

// Dijit
    "dijit/layout/_LayoutWidget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",

// DGrid
    "dgrid/OnDemandGrid",
    "dgrid/Selection",
    "dgrid/Keyboard",
    "dgrid/tree",
    "dgrid/extensions/ColumnResizer",

// EPi
    "epi",
    "epi/shell/widget/_ModelBindingMixin",
    "epi-cms/dgrid/WithContextMenu",
    "epi/shell/command/_WidgetCommandProviderMixin",

// CA-Addon
    "epi-contentcollaboration/ContentCollaborationSettings",
    "epi-contentcollaboration/component/viewmodel/ContentCollaborationViewModel",
    "epi-contentcollaboration/widget/ContentCollaborationTreeNode",
    "epi-contentcollaboration/widget/CommentTreeNode",
    "epi-contentcollaboration/widget/CommentBase",
    "epi-contentcollaboration/widget/SubscriptionList",
    "epi-contentcollaboration/widget/FilterUser",
    "epi-contentcollaboration/widget/StatusUpdate",
    "epi-contentcollaboration/widget/ShowAllComment",

// Resources
    "epi/i18n!epi/cms/nls/episerver.shared",
    "epi/i18n!epi/cms/nls/episerver.components.contentcollaboration",
    "dojo/text!./templates/ContentCollaboration.html"

],
function (
// Dojo
    array,
    connect,
    declare,
    event,
    baseFx,
    lang,

    aspect,
    domConstruct,
    domGeometry,
    domStyle,
    domClass,
    coreFx,
    easing,
    on,
    query,
    Stateful,
    when,
    Memory,
    NodeListTraverse,
    ready,

// Dijit
    _LayoutWidget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,

// DGrid
    OnDemandGrid,
    DgridSelection,
    Keyboard,
    Tree,
    ColumnResizer,

// EPi
    epi,
    _ModelBindingMixin,
    WithContextMenu,
    _WidgetCommandProviderMixin,

// CA-Addon
    ContentCollaborationSettings,
    ContentCollaborationViewModel,
    ContentCollaborationTreeNode,
    CommentTreeNode,
    CommentBase,
    SubscriptionList,
    FilterUser,
    StatusUpdate,
    ShowAllComment,

// Resources
    sharedResources,
    resources,
    template
) {
    // module:
    //      epi-contentcollaboration/component/ContentCollaboration
    // summary:
    //      A widget to display content activity 


    return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin, _ModelBindingMixin, _WidgetCommandProviderMixin], {

        // baseClass: String
        //      Base style class for this component.
        baseClass: "epi-contentcollaboration",

        // resources: Object
        //      The resources that represent for our language file.
        resources: resources,

        // templateString: String
        //      Separated component templage in html file. See ./templates/ContentCollaboration.htmls
        templateString: template,

        // _grid: Object
        //      DGrid that used to display 1st level activities.
        _grid: null,

        // _mappings: Object
        //      Instance of Memory, store mapping between item and tree widget.
        _mappings: null,

        // _totalFeedItems: Integer
        //      Store feed item count.
        _totalFeedItems: 0,

        // enableAnimation: Boolean
        //      Flags that indicates enable animation or not.
        enableAnimation: true,

        // Declare view model binding
        modelBindingMap: {
            "queryOptions": ["queryOptions"],
            "channelJoined": ["channelJoined"],
            "receivedItem": ["receivedItem"],
            "editing": ["editing"],
            "showAllCommentItem": ["showAllCommentItem"],
            "restrictMessage": ["restrictMessage"]
        },

        postCreate: function () {
            this.inherited(arguments);

            // Create row, widget mappings
            this._mappings = new Memory();
            this.own(this._mappings);

            // Setup main grid
            this._setupList();

            // Setup events
            this._setupEvents();

            //Add command provider
            this.commandProvider = this.model;
        },

        startup: function () {
            this.inherited(arguments);

            when(this.model.buildQueryOptions(), lang.hitch(this, function () {
                // Resize grid after DOM already
                //   to ensure all child widgets has render successful
                ready(lang.hitch(this, this.resize));
            }));
        },

        resize: function () {
            // summary:
            //      Resize this widget to the given dimensions.
            // tags:
            //      protected

            // make the grid 100% height
            if (this._grid) {
                var parent = this.getParent();
                if (parent != null) {
                    // Re-calculate height of grid 
                    var widgetContainerNode = parent.getParent().domNode,
                        headerNode = query(".epi-gadgetHeader", widgetContainerNode)[0],
                        toolbarNode = query(".epi-componentToolbar", widgetContainerNode)[0],
                        gutterNode = query(".epi-gadgetGutter", widgetContainerNode)[0],
                        headerHeight = headerNode ? domGeometry.position(headerNode).h : 30,
                        toolbarHeight = toolbarNode ? domGeometry.position(toolbarNode).h : 30,
                        gutterHeight = gutterNode ? domGeometry.position(gutterNode).h : 8,
                        statusUpdateHeight = domGeometry.position(this.sharedStatusNode).h,
                        widgetHeight = domGeometry.position(widgetContainerNode).h;

                    domStyle.set(this._grid.domNode, "height", (widgetHeight - (headerHeight + toolbarHeight + gutterHeight + statusUpdateHeight)) + "px");
                }
            }
        },

        _setupList: function () {
            // summary:
            //      create an instance/ re-load data of grid
            // tags:
            //      private

            // Start model binding mixin
            var model = new ContentCollaborationViewModel();
            this.set("model", model);
            // pass model object to SubscriptionList
            this.subscriptionList.set("model", model);

            this._grid = this._createGrid(this.model.store);
            domConstruct.place(this._grid.domNode, this.gridContainerNode);

            this.own(this._grid);
        },

        _setupEvents: function () {
            // summary:
            //      Listens events on all child widgets, list.
            // tags:
            //      private

            var hitchResize = lang.hitch(this, this.resize);

            // Resize grid when Status widget has resize
            this.own(
                // Should resize grid after any child widgets has updated UI
                //  eg: textarea, usergroups tagged
                connect.connect(this.statusUpdateNode, "onResize", hitchResize),

                aspect.after(this, "layout", hitchResize),

                // Filter by user has selected
                aspect.after(this.filterUserNode, "onChange", lang.hitch(this, function (value) {
                    var queryOptions = this.get("queryOptions"),
                        values = !value ? [] : value.split(",");

                    if (!!queryOptions) {
                        queryOptions.query = !queryOptions.query
                                                ? { users: values }
                                                : lang.mixin(queryOptions.query, { users: values });
                        this.set("queryOptions", queryOptions);
                    }
                    else {
                        this.set("queryOptions", { query: { users: values } });
                    }
                }), true)
            );

            // Setup grid events
            var self = this,
                grid = this._grid;
            this.own(
                aspect.after(grid, "expand", function (target, expand, noTransition) {
                    var row = target.element ? target : grid.row(target);

                    // Update UI for 
                    self._decorateTreeNode(row);
                    // show/hide collapse indicator
                    var expanded = this._expanded[row.id];
                    domClass.toggle(row.element, "epi-collapsed", !expanded);

                    ready(lang.hitch(this, function () {
                        // Set height to auto for connected container
                        if (row.element.connected) {
                            domStyle.set(row.element.connected, "height", "auto");
                        }
                    }));

                }, true),

                aspect.around(grid, "insertRow", lang.hitch(this, this._aroundInsertRow)),
                aspect.around(grid, "newRow", lang.hitch(this, function (originalMethod) {
                    return lang.hitch(this, function (object, parentNode, beforeNode, i, options) {

                        var rowElement = originalMethod.apply(grid, arguments);

                        // Do animation for newly created node.
                        if (this.enableAnimation) {
                            domStyle.set(rowElement, "display", "none");

                            coreFx.wipeIn({
                                node: rowElement,
                                easing: easing.expoOut,
                                duration: 1000
                            }).play();
                        }

                        return rowElement;
                    });
                })),
                aspect.before(grid, "removeRow", lang.hitch(this, function (rowElement, justCleanup) {
                    if (rowElement && rowElement.parentElement) {
                        this._expandParentRow(rowElement.parentElement);
                    }
                })),

                grid.on(".epi-feedItemComment:click", lang.hitch(this, function (evt) { // on comment action clicking, then expand row
                    var row = grid.row(evt);
                    grid.expand(row);

                    // Toggle the Textbox comment
                    domClass.toggle(row.element, "epi-feedItem-expanded");
                })),

                // Handle row click/selection event
                grid.on("dgrid-select", function (e) {
                    self.model.set("selectedItem", e.rows[0].data);
                    self.model.updateCommandsModel();
                }),

                grid.on("dgrid-refresh-complete", lang.hitch(this, function () {
                    this._totalFeedItems = grid._total;
                })),

                aspect.before(grid, "_processScroll", function (evt) {
                    // We need to re-assign value for grid._total because when render Tree in grid row
                    // the variable has been changed to number of its children.
                    grid._total != self._totalFeedItems && (grid._total = self._totalFeedItems);
                    return arguments;
                })
            );
        },

        _createGrid: function (store) {
            // summary:
            //      Creates and returns grid for displaying content.
            // tags:
            //      private

            var gridClass = declare([OnDemandGrid, DgridSelection, Keyboard, ColumnResizer, WithContextMenu]),
                self = this,
                grid = new gridClass({
                    store: store,
                    columns: {
                        createdBy: Tree({
                            field: "createdBy",
                            label: "",
                            renderCell: lang.hitch(this, this._renderTreeNode),
                            shouldExpand: function (/*Obect*/item, /*int*/currentLevel, /*Boolean*/previousExpanded) {
                                return currentLevel == 0;
                            },
                            collapseOnRefresh: false
                        })
                    },
                    minWidth: 100,
                    noDataMessage: this._getNoDataMessage(),
                    selectionMode: "single",
                    showHeader: false,
                    keepScrollPosition: true
                });

            // Add provider for context menu to create menu items.
            grid.contextMenu.addProvider(this.model);

            return grid;
        },

        _decorateTreeNode: function (/*dgrid row*/row) {
            // summary:
            //      Add show all link and post comment widget to tree container.
            // tags:
            //      private

            // Init postComment and move to bottom
            var commentContainer = row.element.connected,
                commentNode = query(".epi-commentBox", commentContainer);

            if ((!commentNode || commentNode.length <= 0)
                && (row.data.feedType == ContentCollaborationSettings.FeedTypes.Activity
                        || row.data.feedType == ContentCollaborationSettings.FeedTypes.Status)) {

                var showAllCommentItem = this.model.get("showAllCommentItem");
                if (!showAllCommentItem || !epi.areEqual(showAllCommentItem.id, row.data.id)) {
                    var showAllCommentModel = new Stateful({ itemData: row.data }),
                        showAllComment = new ShowAllComment({ model: showAllCommentModel });

                    showAllComment.on("linkClick", lang.hitch(this, function (sender, itemData) {
                        this.model.set("showAllCommentItem", itemData);
                    }));

                    showAllComment.placeAt(commentContainer);
                }

                // Post comment
                var postComment = new CommentBase({
                    "baseClass": "epi-comment",
                    model: row.data
                });
                postComment.placeAt(commentContainer);

                // Focus textarea comment when click comment link
                var mapping = this._mappings.get(row.data.id),
                    treeNode = mapping && mapping.widget;

                if (treeNode) {
                    this.own(
                        on(treeNode.commentActionNode, "click", lang.hitch(this, function (evt) {
                            event.stop(evt);
                            // Auto-expand
                            var grid = this._grid,
                                row = this._grid.row(evt),
                                rowElement = row.element,
                                expanded = grid._expanded[row.id];

                            if (!expanded) {
                                grid.expand(rowElement, true, true);
                            }
                            postComment.focus();
                        }))
                    );
                }
            }

            // Set timeout to get correct observer index.
            this.defer(lang.hitch(this, function () {
                // update observerIndex of tree container
                this._updateObserverIndex(row.element);
            }), 1);
        },

        _updateObserverIndex: function (/*Object*/item) {
            // summary:
            //      WORKAROUND: Because the dgrid tree create node with the same level with its parent row node,
            //      and the tree does not contain observerIndex. We need to set observerIndex to avoid dgrid remove
            //      listeners when update last row
            //  tags:
            //      private

            var row = this._grid.row(item),
                rowElement = row && row.element,
                currentTreeNode = rowElement && rowElement.nextSibling,
                previousTreeNode = rowElement && rowElement.previousSibling;

            // update index of tree container current and previous
            if (rowElement && currentTreeNode) {
                currentTreeNode.observerIndex = rowElement.observerIndex;
            }

            if (rowElement && previousTreeNode) {
                previousTreeNode.observerIndex = rowElement.observerIndex;
            }
        },

        _getNoDataMessage: function () {
            // summary:
            //      Get message in case have no data.
            // tags:
            //      private

            return '<span><span class="dijitReset dijitInline">' + resources.nodatamessage + '</span></span>';
        },

        _renderTreeNode: function (object, data, td, options) {
            // summary:
            //      Create tree node widget and place into grid's row
            // tags:
            //      private

            var model = new Stateful(object),
                treeNode = (object && (object.feedType == ContentCollaborationSettings.FeedTypes.Activity || object.feedType == ContentCollaborationSettings.FeedTypes.Status))
                            ? new ContentCollaborationTreeNode({ model: model })
                            : new CommentTreeNode({ model: model });
            treeNode.placeAt(td);

            this._mappings.put({ id: object.id, widget: treeNode });

            this.own(
                treeNode.on("rename", lang.hitch(this, function (val) {
                    treeNode.model.message = val;
                    this.model.set("selectedItem", treeNode.model);
                })),

                treeNode.on("delete", lang.hitch(this, function (val) {
                    var commands = this.model.get("commands");
                    array.some(commands, function (command) {
                        if (command.label === sharedResources.action.deletelabel) {
                            when(command.execute(), function () { }, function () { treeNode.resetValue(); });
                        }
                    });
                }))
            );
        },

        _setShowAllCommentItemAttr: function (item) {
            // summary:
            //      Refresh the grid when the current showAllCommentItem changed.
            // tags:
            //      private

            if (this._grid && this._grid._numObservers > 0 && item && !epi.areEqual(ContentCollaborationSettings.VirtualRoot, item.id)) {
                // notify item changed
                this._grid.store.notify(item, item.id);
            }
        },

        _setQueryOptionsAttr: function (queryOptions) {
            // summary:
            //      Customize set query options method to set grid query.
            // tags:
            //      public

            this._set("queryOptions", queryOptions);

            if (this._queryDefer && typeof this._queryDefer.remove === 'function') {
                this._queryDefer.remove();
            }

            this._queryDefer = this.defer(lang.hitch(this, function () {
                if (this._grid && queryOptions) {
                    this._grid.set("query", queryOptions.query, queryOptions.options);
                }
            }), 100);
        },

        _setRestrictMessageAttr: function (/*String - restrict message*/message) {
            // summary:
            //      Display/Hide main widget when user don't have access right.
            // tags:
            //      private

            if (!this.noAccessRightNode) {
                return;
            }

            domStyle.set(this.noAccessRightNode, "display", message ? "" : "none");
            domStyle.set(this.contentContainerNode, "display", !message ? "" : "none");

            // Update message
            this.noAccessRightNode.innerHTML = message;
        },

        _setReceivedItemAttr: function (/*Object*/object) {
            // summary:
            //      The method's called when new feed item arrived.
            // tags:
            //      public

            // update filter user widget
            if (object && (
                object.feedType == ContentCollaborationSettings.FeedTypes.Activity ||
                object.feedType == ContentCollaborationSettings.FeedTypes.Status)) {

                // Add new item only if there is not existed in selection list
                var values = this.filterUserNode.getSelections(),
                    existed = array.some(values, function (v) {
                        return v.value === object.createdBy;
                    });

                if (!existed) {
                    this.filterUserNode.addNewItem(new Stateful({ name: object.createdBy }));
                }
            }
        },

        _aroundInsertRow: function (original) {
            // summary:
            //      Called 'around' the insertRow method to add more class for current row.
            // tags:
            //      protected

            return lang.hitch(this, function (object, parent, beforeNode, i, options) {

                // Call original method
                var rowElement = original.apply(this._grid, arguments),
                    container = query(rowElement).parents(".dgrid-tree-container")[0];

                this._expandParentRow(container);

                if (object && (object.feedType == ContentCollaborationSettings.FeedTypes.Activity
                                || object.feedType == ContentCollaborationSettings.FeedTypes.Status
                    )) {
                    domClass.add(rowElement, "epi-feedActivity");
                }

                // Update observer index for ShowAllComment widget.
                if (object && (epi.areEqual(object.feedType, ContentCollaborationSettings.FeedTypes.Comment))) {
                    this.defer(function () {
                        var showAllComment = rowElement.parentElement && query(rowElement).siblings().last().prev()[0];
                        if (showAllComment && !showAllComment.observerIndex) {
                            showAllComment.observerIndex = rowElement.observerIndex;
                        }
                    }, 1);
                }

                return rowElement;
            });
        },

        _expandParentRow: function (container) {
            // summary:
            //      Expand parent row.
            // tags:
            //      private

            var parentRow = container && container.previousSibling && this._grid.row(container.previousSibling),
                expanded = parentRow && this._grid._expanded[parentRow.id];

            if (parentRow) {
                expanded ? container && domStyle.set(container, "height", "auto") : this._grid.expand(parentRow, true, true);
            }
        },

        _setEditingAttr: function (/*Boolean*/value) {
            // summary:
            //      Display/Hide comment editor.
            // tags:
            //      public

            if (this._grid) {
                var selectedItem = this.model && this.model.get("selectedItem"),
                    row = selectedItem && this._grid.row(selectedItem),
                    mapping = row && this._mappings.get(row.data.id),
                    treeNode = mapping && mapping.widget;

                if (treeNode) {
                    return value ? treeNode.startEdit() : treeNode.stopEdit();
                }
            }
        }
    });
});