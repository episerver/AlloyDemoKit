﻿define("epi-contentcollaboration/component/command/DeleteFeedItem", [
    // Dojo base
    "dojo/_base/declare",

// CA-Addon
   "epi-contentcollaboration/component/command/CommandBase",

// Resources
    "epi/i18n!epi/cms/nls/episerver.shared"

], function (
// Dojo base
    declare,

// CA-Addon
    CommandBase,

// Resources
    sharedResources

    ) {
    return declare([CommandBase], {

        category: "context",

        iconClass: "epi-iconTrash",

        label: sharedResources.action.deletelabel,

        _execute: function () {
            // summary:
            //      Executes this command assuming canExecute has been checked.
            // tags:
            //      protected

            this.model.deleteItem();
        }
    });
});