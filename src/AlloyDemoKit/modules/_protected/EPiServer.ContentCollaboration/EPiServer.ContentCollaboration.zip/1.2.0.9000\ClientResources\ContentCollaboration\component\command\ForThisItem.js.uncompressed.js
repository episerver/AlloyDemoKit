﻿define("epi-contentcollaboration/component/command/ForThisItem", [
//Dojo base
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/promise/all",
    "dojo/when",

// Dijit
    "dijit/Menu",
    "dijit/popup",

// EPi
    "epi/shell/command/_Command",
    "epi/shell/command/ToggleCommand",
    "epi/shell/command/builder/MenuBuilder",
    "epi-cms/contentediting/ContentActionSupport",

//CA command
    "epi-contentcollaboration/component/command/SubscribeCommandBase",
    "epi-contentcollaboration/component/command/PopupCommandBase",
    "epi-contentcollaboration/ContentCollaborationSettings",

// Resources
    "epi/i18n!epi/cms/nls/episerver.components.contentcollaboration"

], function (
// Dojo base
    array,
    declare,
    lang,

    all,
    when,

// Dijit
    Menu,
    popupManager,

// EPi
    _Command,
    ToggleCommand,
    MenuBuilder,
    ContentActionSupport,

// CA command
    SubscribeCommandBase,
    PopupCommandBase,
    ContentCollaborationSettings,

// Resources
    resources

    ) {
    return declare([PopupCommandBase], {

        category: "setting",

        label: resources.forthisitem,

        popup: null,

        popupClass: Menu,

        selectedValue: null,

        postscript: function () {
            this.inherited(arguments);
            this._menuBuilder = new MenuBuilder();
        },

        _onModelChange: function () {
            // summary:
            //      Updates canExecute after the model has been updated.
            // tags:
            //      protected

            // Reset default value
            this.set("isAvailable", true);
            this.set("canExecute", true);

            when(all({
                canExecute: this.model.get("canSubscribe"),
                subscribeMap: this.model.get("subscribeMap")
            }), lang.hitch(this, function (result) {

                this.set("canExecute", result.canExecute);
                this.set("active", !!result.subscribeMap && result.subscribeMap.isActive);
                this.set("selectedValue", result.subscribeMap && result.subscribeMap.isActive ?
                    ContentCollaborationSettings.SubscribeTypes[result.subscribeMap.subscribeType] : ContentCollaborationSettings.SubscribeTypes.None);

                // Create sub items
                when(this.model.getCurrentContent(), lang.hitch(this, this._createMenuSubItems));
            }));
        },

        _createMenuSubItems: function (/*Object*/ contentData) {
            // summary:
            //		Setup sub items when user click to subscribe content.
            // tags:
            //		private

            // Do nothing if content data is null or empty
            if (!contentData) {
                return;
            }

            var selectedValue = this.get("selectedValue"),
                commands = this.get("commands"),
                contentName = contentData.currentLanguageBranch ? contentData.currentLanguageBranch.name : contentData.name;

            if (!commands) {

                commands = [
                    new SubscribeCommandBase({
                        name: "SubscribeNone",
                        label: resources.subscribetypes.none,
                        value: ContentCollaborationSettings.SubscribeTypes.None,
                        selectedValue: selectedValue,
                        model: this.model
                    }),
                    new SubscribeCommandBase({
                        name: "SubscribeAll",
                        label: resources.subscribetypes.all,
                        value: ContentCollaborationSettings.SubscribeTypes.All,
                        selectedValue: selectedValue,
                        model: this.model
                    }),
                    new SubscribeCommandBase({
                        name: "SubscribeLanguageOnly",
                        label: lang.replace(resources.subscribetypes.languageonly, [contentName]),
                        value: ContentCollaborationSettings.SubscribeTypes.LanguageOnly,
                        selectedValue: selectedValue,
                        model: this.model
                    }),
                    new SubscribeCommandBase({
                        name: this._subscribeUntilContentPublishedCommandName,
                        label: lang.replace(resources.subscribetypes.versionuntilpublished, [contentName]),
                        value: ContentCollaborationSettings.SubscribeTypes.VersionUntilPublished,
                        selectedValue: selectedValue,
                        model: this.model,
                        canExecute: contentData.status !== ContentActionSupport.versionStatus.Published
                                    && contentData.status !== ContentActionSupport.versionStatus.PreviouslyPublished
                                    && contentData.status !== ContentActionSupport.versionStatus.Expired
                    })
                ];

                this.set("commands", commands);

                // Create sub menu items
                array.forEach(commands, function (command) {
                    if (!this.popup) {
                        // Construct the popup class defined in the command.
                        this.set("popup", new this.popupClass({ category: this.popupCategory }));
                    }
                    this._menuBuilder.create(command, this.popup);
                }, this);

            } else {
                // Update command model
                array.forEach(commands, function (command) {
                    // Set canExecute of SubscribeUntilContentPublished command depend on status of content data
                    //  and other commands alway true
                    command.set({
                        selectedValue: selectedValue,
                        model: this.model,
                        label: lang.replace(ContentCollaborationSettings.getSubscribeTypeLocalization(ContentCollaborationSettings.getEnumTypeName(command.value, ContentCollaborationSettings.SubscribeTypes)), [contentName]),
                        canExecute: command.name !== this._subscribeUntilContentPublishedCommandName
                                    || (contentData.status !== ContentActionSupport.versionStatus.Published
                                            && contentData.status !== ContentActionSupport.versionStatus.PreviouslyPublished
                                            && contentData.status !== ContentActionSupport.versionStatus.Expired)
                    });
                }, this);
            }
        }
    });
});