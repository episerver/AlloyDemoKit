﻿define([
// Dojo base
    "dojo/_base/declare",

// Epi Framework
    "epi/epi",
    "epi/shell/command/_Command",
    "epi/username",

// CA Add-on
    "epi-contentcollaboration/ContentCollaborationSettings"

], function (
// Dojo base
    declare,

// Epi Framework
    epi,
    _Command,
    username,

// CA Add-on
    ContentCollaborationSettings
) {
    return declare([_Command], {

        _onModelChange: function () {
            // summary:
            //      Updates canExecute after the model has been updated.
            //      User can not delete Activity and should be owner of the feed item.
            // tags:
            //      protected

            var currentUser = username._getCurrentUsername(),
                selectedItem = this.model && this.model.selectedItem,
                canExecute = selectedItem &&
                            ContentCollaborationSettings.globalSettings.allowToEditAndDeleteComments &&
                            !epi.areEqual(selectedItem.feedType, ContentCollaborationSettings.FeedTypes.Activity) &&
                            epi.areEqual(selectedItem.createdBy, currentUser);

            this.set("canExecute", canExecute);
        }
    });
});
