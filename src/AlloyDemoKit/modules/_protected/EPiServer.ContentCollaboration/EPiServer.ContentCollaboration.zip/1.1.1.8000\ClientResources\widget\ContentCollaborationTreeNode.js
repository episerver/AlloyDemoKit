﻿define([
// Dojo
    "dojo/_base/declare",
    "dojo/_base/connect",
    "dojo/_base/lang",
    "dojo/dom-class",
    "dojo/dom-construct",
    "dojo/dom-style",
    "dojo/on",
    "dojo/when",

// EPi
    "epi/datetime",
    "epi/shell/_ContextMixin",
    "epi/shell/dgrid/util/misc",

// CA-Addon
    "epi-contentcollaboration/ContentCollaborationSettings",
    "epi-contentcollaboration/widget/ContentCollaborationTreeNodeBase",

// CMS
    "epi-cms/core/ContentReference",

// Resources
    "epi/i18n!epi/cms/nls/episerver.components.contentcollaboration",
    "dojo/text!./templates/ContentCollaborationTreeNode.html"

],
function (
// Dojo
    declare,
    connect,
    lang,
    domClass,
    domConstruct,
    domStyle,
    on,
    when,

// EPi
    epiDate,
    _ContextMixin,
    GridMiscUtil,

// CA-Addon
    ContentCollaborationSettings,
    ContentCollaborationTreeNodeBase,

// CMS
    ContentReference,

// Resources
    resources,
    template
) {
    // module:
    //      epi-contentcollaboration/widget/ContentCollaborationTreeNode
    // summary:
    //      A widget to display content activity tree node

    return declare([ContentCollaborationTreeNodeBase, _ContextMixin], {

        resources: resources,

        templateString: template,

        showCommentLink: true,

        postCreate: function () {

            this.inherited(arguments);

            domStyle.set(this.commentActionNode, "display", this.showCommentLink ? "" : "none");
        },

        _setActivityTypeAttr: function (/*int*/ value) {

            var activityTypeName = this.model.activityType || "None";
            if (this._hasAction()) {
                // Add more icon on tile
                var icon = domConstruct.create("span", {
                    "class": lang.replace("dijitReset dijitInline dijitIcon {0}", [ContentCollaborationSettings.IconClassActivityType[activityTypeName]])
                });
                domConstruct.place(icon, this.createdByNode, "before");
            }

            if (this._isActivity()) {
                this.actionNode.innerHTML = ContentCollaborationSettings.getActionByActivityTypeLocalization(activityTypeName);
                this._renderActionName();
                domClass.add(this.contentLinkNode, lang.replace("epi-feed-header {0}", [ContentCollaborationSettings.InvertClassActivityType[activityTypeName]]));
                domClass.add(this.domNode, "epi-feedContentActivity");
            }

            when(this.getCurrentContext(), lang.hitch(this, function (currentContext) {
                var currentContextContentId = this.getContentId(currentContext.id),
                    modelContentId = this.getContentId(this.model.contentLink),
                    contentName = GridMiscUtil.htmlEncode(this.model.contentName);

                if (currentContext.language !== this.model.language) {
                    this.contentLinkNode.innerHTML += lang.replace(" {0} <a class=\"epi-link-content\">{1}</a><span class=\"epi-ct-missingLanguageRow\"> ({2})</span>", [resources.on, contentName, this.model.language]);
                }
                else if (currentContextContentId !== modelContentId) {
                    this.contentLinkNode.innerHTML += lang.replace(" {0} <a class=\"epi-link-content\">{1}</a>", [resources.on, contentName]);
                }
            }));
        },

        getContentId: function (/*String*/contentLink) {
            // summary:
            //      Get content link include its work version
            // tags:
            //      private

            return ContentReference.toContentReference(contentLink).toString();
        },

        _renderActionName: function () {
            // summary:
            //      Render actink node's template by activity type.
            // tags:
            //      private

            var activityType = this.model.activityType;
            var actionName = ContentCollaborationSettings.getActivityTypeLocalization(activityType);

            if (epi.areEqual(activityType.toLowerCase(), "scheduletopublish")) {
                var scheduleToPublishDate = this.model.othersInformation && this.model.othersInformation.scheduleToPublishDate;
                scheduleToPublishDate && (actionName = lang.replace(actionName, [epiDate.toUserFriendlyString(scheduleToPublishDate)]));
            }

            this.contentLinkNode.innerHTML = GridMiscUtil.htmlEncode(actionName);
        }
    });
});