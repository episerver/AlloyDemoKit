﻿define([
// Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",

// Dijit
    "dijit/_Widget",
    "dijit/_Templated",

// EPi Framework
    "epi/dependency",
    "epi/shell/command/_Command",

// EPi CMS
    "epi-cms/contentediting/command/_CommandWithDialogMixin",

// EPi Addons
    "epi-contentcollaboration/ContentCollaborationSettings",
    "epi-contentcollaboration/component/command/ChangeNotificationEmail",

// Resources
    "epi/i18n!epi/cms/nls/episerver.components.contentcollaboration"

], function (
// Dojo
    declare,
    lang,

// Dijit
    _Widget,
    _Templated,

// EPi Framework
    dependency,
    _Command,

// EPi CMS
    _CommandWithDialogMixin,

// EPi Addons
    ContentCollaborationSettings,
    ChangeNotificationEmail,

// Resources
    resources
) {
    var simpleDialogContent = declare([_Widget, _Templated], {
        resources: resources,
        templateString: "<div>${resources.emailnotification.description}<div>",
    });

    return declare([_Command, _CommandWithDialogMixin], {

        // title: String
        //      The dialog title.
        title: resources.emailnotification.title,

        // dialogClass: String
        //      The dialog style class name.
        //      Change it to: "epi-dialog-portrait" if our dialog content is more complex.
        dialogClass: "epi-dialog-confirm",

        // dialogContentClass: Constructor
        //      The content widget that will be displayed inside dialog.
        dialogContentClass: simpleDialogContent,

        // confirmActionText: [public] String
        //      Label to be displayed for the confirm (positive) action.
        confirmActionText: resources.emailnotification.ok,

        // cancelActionText: [public] String
        //      Label to be displayed for the cancel (negative) action.
        cancelActionText: resources.emailnotification.cancel,

        // _changeEmailCmd: Command
        //      The change email notification command.
        _changeEmailCmd: null,

        // _feedEchoService: FeedEchoService
        //      Used to update personalize setting.
        //      We only want show notification e-mail address one time when component is added.
        _feedEchoService: null,

        postscript: function () {
            this.inherited(arguments);

            this.set("isAvailable", true);
            this.set("canExecute", true);

            this._changeEmailCmd = new ChangeNotificationEmail();
            this._feedEchoService = dependency.resolve("epi.contentcollaboration.signalr.feedservice");
        },

        _execute: function () {
            // summary:
            //      Executes this command assuming canExecute has been checked.
            // tags:
            //      protected

            this.showDialog();
            this._updatePersonalizeSetting();
        },

        _updatePersonalizeSetting: function () {
            // summary:
            //      We only want show notification e-mail address one time when component is added.
            // tags:
            //      private

            var currentSettings = lang.mixin(ContentCollaborationSettings.personalizeSettingsViewModel, {
                isShowedNoEmailNotification: true
            });

            this._feedEchoService.savePersonalizeSetting(currentSettings);
        },

        onDialogExecute: function (actionParams) {
            // summary:
            //      Process value returned from dialog after it's executed.
            //      It should be implemented from delivery
            // tags:
            //      public virtual

            this.inherited(arguments);
            this._changeEmailCmd._execute();
        }
    });
});
