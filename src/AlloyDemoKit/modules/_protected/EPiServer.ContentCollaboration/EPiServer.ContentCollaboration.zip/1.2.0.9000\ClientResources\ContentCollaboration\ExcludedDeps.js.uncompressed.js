﻿/* Collects all dependencies to be excluded when bundling */
define("epi-contentcollaboration/ExcludedDeps", [
    "dojo/fx/easing",

    "dijit/_Templated",

    "dojox/widget/Standby",
    "dojox/dtl/filter/strings",
    "dojox/dtl/_base",

    "dgrid/tree",
    "dgrid/extensions/ColumnResizer",

    "epi/epi",
    "epi/layers/epi-widgets",
    "epi/shell/widgets",

    "epi/shell/command/ToggleCommand",
    "epi/shell/widget/dialog/Confirmation",
    "epi/shell/command/withConfirmation",
    "epi/shell/command/_WidgetCommandProviderMixin",
    "epi/shell/command/_WidgetCommandBinderMixin",
    "epi/shell/command/_GlobalCommandProviderMixin",

    "epi-cms/widget/_ContentListMouseMixin",
    "epi-cms/widget/_ContentListKeyMixin",
    "epi-cms/_ContentContextMixin",
    "epi-cms/dgrid/formatters",
    "epi-cms/contentediting/editors/CheckBoxListEditor",
    "epi-cms/ApplicationSettings",
    "epi-cms/dgrid/WithContextMenu",
    "epi-cms/contentediting/command/_CommandWithDialogMixin",
    "epi-cms/core/ContentReference",
    "epi-cms/contentediting/ContentActionSupport",
    "epi-cms/store/CustomQueryEngine"
], 1);