﻿define([
// Dojo
    "dojo/_base/declare",

// EPi
    "epi/shell/dgrid/util/misc",
    "epi/username",

// CA-Addon
    "epi-contentcollaboration/widget/ContentCollaborationTreeNodeBase",

// Resources
    "dojo/text!./templates/CommentTreeNode.html"

],
function (
// Dojo
    declare,

// EPi
    GridMiscUtil,
    username,

// CA-Addon
    ContentCollaborationTreeNodeBase,

// Resources
    template
) {
    // module:
    //      epi-contentcollaboration/widget/CommentTreeNode
    // summary:
    //      A widget to display content activity tree node

    return declare([ContentCollaborationTreeNodeBase], {
        
        templateString: template,

        _setCreatedByAttr: function (/*string*/ value) {
            // summary:
            //      Override set create by attribute to make lower case in friendly name.
            // tags:
            //      private

            if (this.createdByNode) {
                this.createdByNode.innerHTML = username.toUserFriendlyString(GridMiscUtil.htmlEncode(value), null, false, null);
            }
        }

    });
});