﻿define("epi-contentcollaboration/component/command/SendEmailCommandBase", [
//Dojo base
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/topic",
    "dojo/when",

// EPi
    "epi",
    "epi/shell/command/ToggleCommand"
], function (
// Dojo base
    declare,
    lang,

    topic,
    when,

// EPi
    epi,
    ToggleCommand
    ) {

    return declare([ToggleCommand], {

        // label: String
        //      Display name of the command
        label: null,

        // value: Enum
        //      The email notificaiton setting defined in ContentCollaborationSettings.EmailNotificationTypes.
        //      The email notificaiton setting  that command is reserved. 
        value: null,

        // selectedValue: Enum
        //      The email notificaiton setting defined in ContentCollaborationSettings.EmailNotificationTypes.
        //      Current selected type.
        selectedValue: null,

        // canExecute: [Boolean]
        //      Set can execute or not for this command
        //      The default value is alway true
        canExecute: true,

        postscript: function () {
            this.inherited(arguments);

            this.set("isAvailable", true);
            this.set("canExecute", this.canExecute);
        },

        _onModelChange: function () {
            // summary:
            //      Updates canExecute after the model has been updated.
            // tags:
            //      protected

            // Reset default value
            this.set("isAvailable", true);
            this.set("canExecute", this.canExecute);

            this.set("active", epi.areEqual(this.value, this.selectedValue));
        },

        _execute: function () {
            // summary:
            //      Change send email settings.
            // tags:
            //      protected

            this.model.savePersonalizeSetting(this.value);
        }
    });
});