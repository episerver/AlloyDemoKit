﻿define([
// Dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-attr",
    "dojo/dom-construct",
    "dojo/on",

// Dijit
    "dijit/_TemplatedMixin",
    "dijit/_Widget",
    "dijit/_WidgetsInTemplateMixin",

// EPi
    "epi/epi",

// CA-Addon
    "epi-contentcollaboration/widget/InlineButton",

// Resources
    "dojo/text!./templates/UserGroupSelector.html",
    "epi/i18n!epi/cms/nls/episerver.components.contentcollaboration"
],

function (
// Dojo
    array,
    declare,
    lang,
    domClass,
    domConstruct,
    on,

// Dijit
    _TemplatedMixin,
    _Widget,
    _WidgetsInTemplateMixin,

// EPi
    epi,

// CA-Addon
    InlineButton,

// Resources
    template,
    resources
) {

    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin], {

        // templateString: [String]
        //      String template of this widget.
        templateString: template,
        
        // resources: [String]
        //      Json object represent for XML lang file.
        resources: resources,

        // _selectedValues: [Array]
        //      The selected values of widget.
        _selectedValues: null,
        
        onChange: function (value) {
            // summary:
            //    Fired when value is changed.
            //
            // value:
            //    The value
            // tags:
            //    public, callback
        },

        onResize: function () {
            // summary:
            //    Fired when UI is changed or updated.
            //
            // tags:
            //    public, callback
        },
        
        destroyDescendants: function () {
            if (this._tooltip) {
                this._tooltip.destroy();
                delete this._tooltip;
            }
            this.inherited(arguments);
        },
        
        _setValueAttr: function (value) {
            //summary:
            //    Value's setter.
            //
            // value: array of items.
            //    Value to be set.
            //
            // tags:
            //    protected

            if (!lang.isArray(value)) {
                value = [value];
            }
            var filteredValue = array.filter(value, function (v) { return !!v; });
            this._setValueAndFireOnChange(filteredValue);
        },

        _setValueAndFireOnChange: function (value) {
            // summary:
            //      Set value for internal value and fire event onChange
            // tags:
            //      protected

            // Compare arrays
            if (epi.areEqual(this._selectedValues, value)) {
                return;
            }

            this._selectedValues = value;
            this.onChange(this._selectedValues);
            this._updateDisplayNode();
        },

        _getValueAttr: function () {
            //summary:
            //    Value's getter
            // tags:
            //    protected

            return this._selectedValues;
        },

        _setReadOnlyAttr: function (value) {
            // summary:
            //      Display or not dropdown button
            // tags
            //      protected

            this._set("readOnly", value);
            domClass.toggle(this.domNode, "dijitReadOnly", value);
        },

        _createItemButton: function (data) {
            //summary:
            //    create button.
            //
            // data: the object with value and text properties
            //
            // tags:
            //    private

            var button = new InlineButton({ value: data, readOnly: this.get("readOnly") });
            this.own(
                on(button, "remove", lang.hitch(this, function(value) {
                    this._remove(value);
                    button.destroy();
                }))
            );
            button.placeAt(this.dataContainer);
        },
        
        _updateDisplayNode: function () {
            //summary:
            //    update category group.
            //
            // tags:
            //    private

            // Clear domNode
            domConstruct.empty(this.dataContainer);

            if (this._selectedValues && this._selectedValues.length > 0) {
                // Loop throw selected values to create button
                this._selectedValues.forEach(function(data) {
                    this._createItemButton(data);
                }, this);
            }
            this.onResize();
        },

        _remove: function (value) {
            //summary:
            //    handles remove click event.
            //
            // arg: event argument .
            //
            // tags:
            //    private

            if (!this._selectedValues) {
                return;
            }
            
            var index = this._selectedValues.indexOf(value);
            if (index >= 0) {
                var remainingItems = lang.clone(this._selectedValues);
                remainingItems.splice(index, 1);
                this.set('value', remainingItems);
            }

            //  Hide the Post button and User/Group field when there is no remaining item in the User/Group field.
            if (this._selectedValues.length === 0) {
                this.onBlur();
            }
        }
    });
});
