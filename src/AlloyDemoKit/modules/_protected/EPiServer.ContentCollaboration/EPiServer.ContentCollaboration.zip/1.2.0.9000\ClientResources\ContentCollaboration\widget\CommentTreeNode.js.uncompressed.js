require({cache:{
'url:epi-contentcollaboration/widget/templates/CommentTreeNode.html':"﻿<div class=\"epi-content-feeditem\">\r\n    <div class=\"epi-feedChildNode epi-typo-small\">\r\n        <div class=\"epi-feedItem\">\r\n            <span class='dijitInline dijitIcon epi-iconContextMenu epi-floatRight' data-dojo-attach-point=\"contextMenuNode\">&nbsp;</span>\r\n            <strong data-dojo-attach-point=\"createdByNode\"></strong>\r\n            <span data-dojo-attach-point=\"messageNode\"></span>\r\n        </div>\r\n        <div class=\"epi-feedItem epi-created-row\">\r\n            <span data-dojo-attach-point=\"createdDateNode\" class=\"epi-secondaryText\"></span>\r\n        </div>\r\n    </div>\r\n</div>\r\n"}});
﻿define("epi-contentcollaboration/widget/CommentTreeNode", [
// Dojo
    "dojo/_base/declare",

// EPi
    "epi/shell/dgrid/util/misc",

// CA-Addon
    "epi-contentcollaboration/widget/ContentCollaborationTreeNodeBase",
    "epi-contentcollaboration/Utils",

// Resources
    "dojo/text!./templates/CommentTreeNode.html"

],
function (
// Dojo
    declare,

// EPi
    GridMiscUtil,

// CA-Addon
    ContentCollaborationTreeNodeBase,
    Utils,

// Resources
    template
) {
    // module:
    //      epi-contentcollaboration/widget/CommentTreeNode
    // summary:
    //      A widget to display content activity tree node

    return declare([ContentCollaborationTreeNodeBase], {
        
        templateString: template,

        _setCreatedByAttr: function (/*string*/ value) {
            // summary:
            //      Override set create by attribute to make lower case in friendly name.
            // tags:
            //      private

            if (this.createdByNode) {
                this.createdByNode.innerHTML = Utils.toUserNameFriendlyString(GridMiscUtil.htmlEncode(value), null, false, null);
            }
        }

    });
});