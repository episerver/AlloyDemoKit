﻿define([
// Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-style",
    "dojox/html/entities",
    "dojo/on",

// Dijit
    "dijit/_Widget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    
// Resources
    "dojo/text!./templates/InlineButton.html"
],
function (
// Dojo
    declare,
    lang,
    domStyle,
    entities,
    on,

// Dijit
    _Widget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    
// Resources
    template
) {
    // module:
    //      epi-contentcollaboration/widget/InlineButton
    // summary:
    //      A base widget to display inline button.

    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin], {

        // value: Object
        //      Initial value of widget.
        value: null,
        
        // templateString: String
        //      String template of this widget.
        templateString: template,

        onRemove: function(/*String*/value) {
            // summary:
            //      Callback event when user click remove button.
            // tags:
            //      public
        },

        postCreate: function () {
            this.inherited(arguments);

            // Raise onRemove event 
            this.own(
                on(this.removeNode, "click", lang.hitch(this, function () {
                    if (!this.get("readOnly")) {
                        this.onRemove(this.get("value"));
                    }
                }))
            );
        },

        focus: function () {
            // summary:
            //      Focus to remove button
            // tags:
            //      public

            this.removeNode.focus();
        },

        _setValueAttr: function(/*Object*/value) {
            // summary:
            //      Set value of widget.
            // tags:
            //      public

            domStyle.set(this.domNode, "display", !value ? "none" : "");
            this.value = value;

            // Do nothing when value is null
            if (!value) {
                return;
            }

            // Display text
            var text = value.name || value;
            this.displayNode.innerHTML = entities.encode(text);
            this.displayNode.title = text;
        },

        _getValueAttr: function () {
            // summary:
            //      Return value of widget.
            // tags:
            //      public

            return this.value;
        },

        _setReadOnlyAttr: function (value) {
            // summary:
            //      Display or not dropdown button
            // tags
            //      protected

            this._set("readOnly", value);

            domStyle.set(this.removeNode, "display", value ? "none" : "");
        }
    });
});