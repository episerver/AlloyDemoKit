﻿define("epi-contentcollaboration/widget/DropDownButtonBase", [
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/aspect",
    "dojo/when",
    "dojo/dom-class",
    "dojo/dom-construct",

// dijit
    "dijit/DropDownMenu",
    "dijit/form/DropDownButton",

// epi
    "epi/dependency",
    "epi-cms/_ContentContextMixin",

// resources
    "epi/i18n!epi/cms/nls/episerver.components.contentcollaboration"

], function (
    declare,
    lang,

    aspect,
    when,
    domClass,
    domConstruct,

// dijit
    DropDownMenu,
    DropDownButton,

// epi
    dependency,
    _ContentContextMixin,

// resources
    resources

) {

    return declare([DropDownButton, _ContentContextMixin], {

        // baseClass: String
        //      Base style class names for this widget.
        baseClass: "epi-chromeless epi-dropdown-selector-button epi-secondaryText",

        // autoWidth: [protected] Boolean
        //      Override base class
        //      Set to false, ensure the drop down should just be its default width
        autoWidth: false,

        //  valueIsCsv: [Boolean]
        //      The flag to indicator using csv or not in value
        valueIsCsv: true,

        // storeKey: String
        //      The key string to get store by key.
        storeKey: null,

        // dropDown: Object
        //      Instance of drop down menu.
        dropDown: null,

        // dropdownContentClass: Constructor
        //      Generic content widget class that's used to create instance for dropdownContentWidget.
        dropdownContentClass: null,

        // dropdownContentWidget: Object
        //      Widget that's displayed inside dropdown menu.
        dropdownContentWidget: null,

        // noDataMessage: String
        //      Message that's dispayed when we have no data.
        noDataMessage: resources.nodatamessage,

        // iconClass: [String]
        //      The style class for icon domNode
        iconClass: null,

        onChange: function (value) {
            // summary:
            //      Callback method for updating value.
            // tags:
            //      callback
        },

        _buildMenuHeader: function (/*domNode*/ contentContainer, /*Array*/ items) {
            // summary:
            //      Create menu header.
            // tags:
            //      protected
        },

        _buildMenuContentSettings: function (/*Array*/items) {
            // summary:
            //      Generic method to get menu content settings from items.
            //      We also normalize data (itmes) here.
            // tags:
            //      protected
        },

        _buildQueryParams: function () {
            // summary:
            //      Build query params.
            // tags:
            //      protected
        },

        _buildQueryOptions: function () {
            // summary:
            //      Build query options
            // tags:
            //      protected
        },

        _setupEvents: function () {
            // summary:
            //      Setup event on dropdownContentWidget.
            // tags:
            //      protected

            this.own(
                aspect.after(this.dropdownContentWidget, "onChange", lang.hitch(this, function () {
                    var selectedValue = this.dropdownContentWidget.get("value");
                    domClass.toggle(this.domNode, "dijitChecked", (!!selectedValue && !lang.isArray(selectedValue))
                                                                            || (lang.isArray(selectedValue) && selectedValue.length > 0));
                    this.onChange(selectedValue, this.dropdownContentWidget.selections);
                }), true)
            );
        },

        postCreate: function () {
            // summary:
            //    Raised after the widget is created.
            // tags:
            //    protected

            this.inherited(arguments);

            this.store = this.store || dependency.resolve("epi.storeregistry").get(this.storeKey);
            this.setupDropDown();

            if (this.iconNode) {
                domClass.add(this.iconNode, this.iconClass);
            }
        },

        contentContextChanged: function () {
            // summary:
            //      Setups list when content context.
            // tags:
            //      public

            this.setupDropDown();
        },

        setupDropDown: function () {
            // summary:
            //    Set up filter list drop down menu.
            // tags:
            //    protected

            if (!this.dropDown) {
                this.dropDown = new DropDownMenu({ baseClass: "epi-contentcollaboration epi-dropdown-menu" });
            } else {
                this.dropDown.destroyDescendants();
            }

            var queryParams = this._buildQueryParams();
            var queryOptions = this._buildQueryOptions();
            when(this.store.query(queryParams, queryOptions), lang.hitch(this, function (items) {
                this._buildMenuContent(items);
            }));
        },

        _buildMenuContent: function (/*Array*/items) {
            // summary:
            //      Create menu content from items.
            // tags:
            //      protected

            // Clear dom
            domConstruct.empty(this.dropDown.domNode);

            // Reset icon state for dropdown button
            domClass.toggle(this.domNode, "dijitChecked", false);

            var self = this,
                contentContainer = domConstruct.create("div", { "class": "epi-dropdown-menu-container" }, this.dropDown.domNode);

            // Create clear button or no data message
            this._buildMenuHeader(contentContainer, items);

            if (!items || items.length <= 0) {
                return;
            }

            // Create check box item
            if (this.dropdownContentClass) {
                this.dropdownContentWidget = new this.dropdownContentClass(this._buildMenuContentSettings(items));
                this.dropdownContentWidget.placeAt(contentContainer);

                this._setupEvents();
            }
        }
    });
});