﻿define([

// Dojo
    "dojo/_base/array",
    "dojo/_base/connect",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-style",
    "dojo/when",

// EPi Framework
    "epi/shell/widget/ValidationTextarea",

// EPi CMS
    "epi-cms/_ContentContextMixin",

// CA
    "epi-contentcollaboration/widget/CommentBase",
    "epi-contentcollaboration/widget/UserGroupSearchBox",

// Resources
    "epi/i18n!epi/cms/nls/episerver.components.contentcollaboration", // use in template
    "dojo/text!./templates/StatusUpdate.html"

], function (

// Dojo
    array,
    connect,
    declare,
    lang,
    domStyle,
    when,

// EPi Framework
    ValidationTextarea, // use in template

// EPi CMS
    _ContentContextMixin,

// CA
    CommentBase,
    UserGroupSearchBox,

// Resources
    resources,
    template

) {
    // module:
    //      epi-contentcollaboration/widget/StatusUpdate
    // summary:
    //      Widget to display status update.

    return declare([CommentBase, _ContentContextMixin], {

        // ellipsisPlaceHolderText: [public] Boolean
        //      The flag to indicate should or should not ellipsis place holder text of the input control
        ellipsisPlaceHolderText: true,

        // templateString: String
        //      String template of this widget.
        templateString: template,

        // resources: Object
        //      Json object represent for XML lang file.
        resources: resources,

        postCreate: function () {
            this.inherited(arguments);

            when(this.getCurrentContext(), lang.hitch(this, function (ctx) {
                this.set("model", ctx);
            }));

            this.own(
                // Should raise resize event after user/groups has tagged or removed
                connect.connect(this.userGroupSelector, "onResize", lang.hitch(this, this.onResize))
            );
        },

        _getPlaceHolderFormat: function () {
            // summary:
            //      Override base class to return our format.
            // tags:
            //      protected override

            return this.resources.statusplaceholder;
        },

        _buildPostData: function () {
            // summary:
            //      Virtual method to get post data.
            // tags:
            //      protected virtual

            // Get seperate users and groups array
            var userGroupsTagged = this.userGroupSelector.get("value"),
                users = array.filter(userGroupsTagged, function (item) {
                    return !item.isGroup;
                }),
                userGroups = array.filter(userGroupsTagged, function (item) {
                    return item.isGroup;
                });

            // Map array string to post to server
            var dataUsers = array.map(users, function (item) {
                    return item.name;
                }),
                dataUserGroups = array.map(userGroups, function (item) {
                    return item.name;
                });

            return {
                message: this.get("value"),
                users: dataUsers,
                userGroups: dataUserGroups
            };
        },

        contentContextChanged: function (ctx, callerData) {
            // summary:
            //      Re-set model when context is changed.
            // tags:
            //      public

            this.set("model", ctx);
        },

        _clearData: function () {
            // summary:
            //      Set value is null
            // tags:
            //      private override

            this.inherited(arguments);

            // Cleare value of user group
            this.userGroupSelector.set("value", null);
            this.userGroupSelector.textbox.value = "";
        }
    });

});