﻿define("epi-contentcollaboration/component/command/SubscribeContent", [
//Dojo base
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/promise/all",
    "dojo/when",

// Dijit
    "dijit/Menu",
    "dijit/popup",

// EPi
    "epi/shell/command/_Command",
    "epi/shell/command/ToggleCommand",
    "epi/shell/command/builder/MenuBuilder",
    "epi-cms/contentediting/ContentActionSupport",

//CA command
    "epi-contentcollaboration/component/command/ForThisItem",
    "epi-contentcollaboration/component/command/ForAllItems",
    "epi-contentcollaboration/component/command/PopupCommandBase",
    "epi-contentcollaboration/ContentCollaborationSettings",

// Resources
    "epi/i18n!epi/cms/nls/episerver.components.contentcollaboration"

], function (
// Dojo base
    array,
    declare,
    lang,

    all,
    when,

// Dijit
    Menu,
    popupManager,

// EPi
    _Command,
    ToggleCommand,
    MenuBuilder,
    ContentActionSupport,

// CA command
    ForThisItem,
    ForAllItems,
    PopupCommandBase,
    ContentCollaborationSettings,

// Resources
    resources

    ) {
    return declare([PopupCommandBase], {

        category: "setting",

        label: resources.commandsubscribecontent,

        selectedValue: null,

        _onModelChange: function () {
            // summary:
            //      Updates canExecute after the model has been updated.
            // tags:
            //      protected

            // Reset default value
            this.set("isAvailable", true);
            this.set("canExecute", true);

            var commands = this.get("commands");
            if (!commands) {
                commands = [new ForThisItem(), new ForAllItems()];
                this.set("commands", commands);
            }

            this.inherited(arguments);
        }
    });
});