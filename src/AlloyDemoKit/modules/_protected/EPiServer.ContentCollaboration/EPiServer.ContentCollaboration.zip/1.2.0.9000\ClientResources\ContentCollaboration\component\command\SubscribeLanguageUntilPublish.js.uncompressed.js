﻿define("epi-contentcollaboration/component/command/SubscribeLanguageUntilPublish", [
//Dojo base
    "dojo/_base/declare",

// EPi
    "epi/shell/command/ToggleCommand",

// Resources
    "epi/i18n!epi/cms/nls/episerver.labs.components.contentactivity"
], function (
// Dojo base
    declare,

// EPi
    ToggleCommand,

// Resources
    resources
    ) {

    return declare([ToggleCommand], {

        label: resources.commandsubcribelanguageuntilpublish,

        postscript: function () {
            this.inherited(arguments);

            this.set("isAvailable", true);
            this.set("canExecute", true);
        }
    });
});