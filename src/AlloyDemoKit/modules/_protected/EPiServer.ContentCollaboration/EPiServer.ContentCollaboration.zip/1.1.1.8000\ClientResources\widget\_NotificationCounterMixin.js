﻿define([
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/aspect",
    "dojo/dom-class",
    "dojo/dom-style",
    "dojo/dom-construct",
    "dojo/Stateful",
    "dojo/store/Memory",
    "dojo/when",
    "dojo/html",

// EPi
    "epi-cms/_ContentContextMixin",
    "epi-cms/ApplicationSettings",

// CA
    "epi-contentcollaboration/ContentCollaborationSettings"

], function (
    array,
    declare,
    lang,

    aspect,
    domClass,
    domStyle,
    domConstruct,
    Stateful,
    Memory,
    when,
    html,

// EPi
    _ContentContextMixin,
    ApplicationSettings,

// CA
    ContentCollaborationSettings

) {

    return declare([Stateful, _ContentContextMixin], {

        // counterNode: DOM element
        //      Element to display the counter.
        counterNode: null,

        // dropDown: widget
        //      The dropdown widget.
        dropDown: null,

        // store: JsonRest
        //      The ContentCollaboration store.
        store: null,

        // _dataBag: dojo/store/Memory
        //      The data bag that contains all unreaditem.
        _dataBag: null,

        setupCounter: function () {
            // summary:
            //      Setup notification counter.
            // tags:
            //      protected

            // Create item storage
            this._dataBag = new Memory({ data: [], id: "id" });

            // Render dom element
            this.counterNode = domConstruct.create("span", { "class": "epi-unreadItemsCounter" }, this.counterContainer);

            // Listen events
            this.own(
                aspect.after(this.store, "notify", lang.hitch(this, this._onStoreNotify), true),
                aspect.after(this.dropDown, "onOpen", lang.hitch(this, this._onDropDownOpen))
            );
        },

        contentContextChanged: function () {
            // summary:
            //      Re-calculate unread notification items when context changed.
            // tags:
            //      protected

            when(this.getCurrentContext(), lang.hitch(this, function (context) {
                this._markRead(context);
                this._updateCounter(context);
            }));
        },

        _onDropDownOpen: function () {
            // summary:
            //      Handle event when user open the notification area.
            // tags:
            //      private

            when(this.getCurrentContext(), lang.hitch(this, function (context) {
                this._markRead();
                this._updateCounter(context);
            }));
        },

        _isValid: function (/*feedItem*/item) {
            // summary:
            //      Checks whether the item is valid or not.
            // tags:
            //      private

            // editor read this item
            // or the item is created by the editor then ignore it.
            if (!item
                || (this.dropDown && this.dropDown.isActive)
                || epi.areEqual(item.createdBy, ApplicationSettings.userName)

                //|| (ContentCollaborationSettings.globalSettings.clearFeedWhenDeleteVersions
                //&& (epi.areEqual(item.activityTypeCode, ContentCollaborationSettings.ActivityTypes.RevertToPublished)
                //|| epi.areEqual(item.activityTypeCode, ContentCollaborationSettings.ActivityTypes.DeleteContentVersion)))

                || epi.areEqual(item.activityTypeCode, ContentCollaborationSettings.ActivityTypes.NewDraftFromHere)
                ) {
                return;
            }

            return when(this.getCurrentContext(), lang.hitch(this, function (context) {
                // if current context is the same with item.contentLink then return
                if (epi.areEqual(context.id, item.contentLink)) {
                    return;
                }

                // don't put an exited item.
                if (this._dataBag && this._dataBag.get(item.id)) {
                    return;
                }

                return context;
            }));
        },

        _onStoreNotify: function (item, id, actionName) {
            // summary:
            //      Handle event notify of the store.
            // tags:
            //      private

            when(this._isValid(item), lang.hitch(this, function (context) {
                if (context) {
                    this._dataBag.put(item);
                    this._updateCounter(context);
                }
            }));
        },

        _updateCounter: function (context) {
            // summary:
            //      Get unread items and update UI.
            // tags:
            //      private

            var unreadItems = this._dataBag.query(function (item) {
                return !epi.areEqual(item.contentLink, context.id);
            });

            // Update UI
            this.set("counter", unreadItems.length);
        },
        
        _setCounterAttr: function (value) {
            // summary:
            //      Set display number of unread items.
            // tags:
            //      private

            this._set("counter", value);
            html.set(this.counterNode, value.toString()); // Update inner HTML value

            // Display or hide
            domStyle.set(this.counterNode, "display", value === 0 ? "none" : "");
            domClass.toggle(this.counterContainer.parentNode, "dijitChecked", value !== 0);
        },

        _markRead: function (/*Context*/context) {
            // summary:
            //      Mark read for notification item by context.
            //      If context is null: Mark all items as read (when dropdown open for instance).
            // tags:
            //      private

            var readItems = this._dataBag.query();

            if (context) {
                readItems = this._dataBag.query(function (item) {
                    return epi.areEqual(item.contentLink, context.id);
                });
            }

            array.forEach(readItems, function (item) {
                this._dataBag.remove(item.id);
            }, this);
        }
    });
});
