﻿define([
// Dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/event",
    "dojo/_base/lang",

    "dojo/query",
    "dojo/aspect",
    "dojo/keys",
    "dojo/on",
    "dojo/dom-class",
    "dojo/dom-style",
    "dojo/dom-construct",
    "dojo/Evented",
    "dojo/when",
    "dojo/NodeList-traverse",

// Dijit
    "dijit/_Widget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/InlineEditBox",

// Dojox
    "dojox/dtl/filter/strings",

// EPi
    "epi/epi",
    "epi/dependency",
    "epi/shell/dgrid/util/misc",
    "epi/shell/widget/_ModelBindingMixin",
    "epi/datetime",
    "epi/username",

// CA-Addon
    "epi-contentcollaboration/ContentCollaborationSettings",
    "epi-contentcollaboration/widget/CommentBase",
    "epi-contentcollaboration/widget/InlineButton",

// Resources
    "epi/i18n!epi/cms/nls/episerver.components.contentcollaboration"

],
function (
// Dojo
    array,
    declare,
    event,
    lang,

    query,
    aspect,
    keys,
    on,
    domClass,
    domStyle,
    domConstruct,
    Evented,
    when,
    NodeListTraverse,

// Dijit
    _Widget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    InlineEditBox,

// Dojox
    strings,

// EPi
    epi,
    dependency,
    GridMiscUtil,
    _ModelBindingMixin,
    epiDate,
    username,

// CA-Addon
    ContentCollaborationSettings,
    CommentBase,
    InlineButton,

// Resources
    resources

) {
    // summary:
    //      Customize editor wrapper.
    // tags:
    //      private
    declare("_DGridInlineEditor", [InlineEditBox._InlineEditor], {

        postCreate: function () {
            // summary:
            //      Disable editing when click or press key.
            // tags:
            //      public

            this.inherited(arguments);

            this.own(
                on(this.domNode, "mousedown, mouseup, click, keydown, keypress, selectstart", function (e) {
                    e.stopPropagation();
                })
            );
        },

        _onBlur: function () {
            // summary:
            //      Disable _onBlur method of _InlineEditor
            // tags:
            //      private
        },

        _onChange: function () {
            // summary:
            //      Customize _onChange event.
            // tags:
            //      private

            if (this.inlineEditBox.autoSave && this.inlineEditBox.editing && this.enableSave()) {
                if (this.inlineEditBox.autoSave && this.inlineEditBox.editing) {
                    if (this.getValue() == this._resetValue) {
                        this.cancel(false);
                    } else if (this.enableSave()) {
                        this.save(false);
                    }
                }
            }
        }
    });

    // summary:
    //      Customize editor widget.
    // tags:
    //      private
    declare("_EditComment", [CommentBase], {
        displayedValue: null,

        "class": "epi-comment--editing",

        _getDisplayedValueAttr: function () {
            return this.get("value");
        }
    });

    // module:
    //      epi-contentcollaboration/widget/ContentCollaborationTreeNodeBase
    // summary:
    //      A widget base to display content activity tree node

    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin, _ModelBindingMixin, Evented], {

        // resources: Object
        //      The resources that represent for our language file.
        resources: resources,

        // isResetingValue: Boolean
        //      Used to turn on/off reset value state.
        isResetingValue: null,

        // useEllipsisForMessage: Boolean
        //      The flag to indicator using or not ellipsis for message
        useEllipsisForMessage: false,

        // templateString: String
        //      Separated component templage in html file.
        templateString: null,

        // showReadMore: [Boolean]
        //      The flag to indicator show readmore link if word count of message greater than maximum number
        showReadMore: true,

        // maxWordCount: [Integer]
        //      The maximum number words of message will display when init
        maxWordCount: 30,

        // Map property name in view model to a list of properties in this widget
        modelBindingMap: {
            "id": ["id"],
            "parentFeedId": ["parentFeedId"],
            "contentGuid": ["contentGuid"],
            "activityType": ["activityType"],
            "culture": ["culture"],
            "createdBy": ["createdBy"],
            "createdDate": ["createdDate"],
            "lastUpdateDate": ["lastUpdateDate"],
            "message": ["message"],
            "users": ["users"],
            "userGroups": ["userGroups"]
        },

        postCreate: function () {

            this.inherited(arguments);

            // Setup check list item
            this._setupUsersAndGroupsTagged();
        },

        startEdit: function () {
            // summary:
            //      Start edit.
            // tags:
            //      public

            this.messageWidget.edit();
        },

        stopEdit: function () {
            // summary:
            //      Stop edit.
            // tags:
            //      public
        },

        resetValue: function () {
            this.isResetingValue = true;
            this.messageWidget.set("value", this._formatUsersTagged(this.message));
            this.messageWidget.wrapperWidget
                && this.messageWidget.wrapperWidget.editWidget
                    && this.messageWidget.wrapperWidget.editWidget.set("value", this.message);
        },

        _onChangeValue: function (val) {
            // summary:
            //      Change message value.
            // tags:
            //      private

            if (!this.isResetingValue) {
                if (!val) {
                    this.emit("delete", val);
                    return;
                }

                if (!epi.areEqual(this.message, val)) {
                    this.emit("rename", val);
                }
            }

            // reset flag to default
            this.isResetingValue = false;
        },

        _setCreatedByAttr: function (/*string*/ value) {
            // summary:
            //      Set create by attribute
            // tags:
            //      private

            if (this.createdByNode) {
                this.createdByNode.innerHTML = username.toUserFriendlyString(GridMiscUtil.htmlEncode(value), null, true, null);
            }
        },

        _setLastUpdateDateAttr: function (/*date*/ value) {
            // summary:
            //      Set last updated date attribute
            // tags:
            //      private

            if (this.createdDateNode && value) {
                this.createdDateNode.innerHTML = epiDate.toUserFriendlyString(value);
            }
        },

        _setMessageAttr: function (/*string*/value) {
            // summary:
            //      Set message attribute
            // tags:
            //      private

            if (!value) {
                return;
            }

            this._set("message", value);

            this._setupInlineEditBox(value);
        },

        _setupUsersAndGroupsTagged: function () {
            // summary: 
            //      Combine users and groups array to make inline button
            //  tags
            //      private

            var users = this.get("users"),
                userGroups = this.get("userGroups");

            // Invisible container if users and usergroups are null
            if (!users && !userGroups) {
                if (this.userGroupsContainer) {
                    domStyle.set(this.userGroupsContainer, "display", "none");
                }
                return;
            }

            if (this.userGroupsNode) {

                var usersAndGroupsTagged = [];
                // Correct data is array alway
                if (!!users) {
                    usersAndGroupsTagged = !lang.isArray(users) ? [users] : users;
                }
                if (!!userGroups) {
                    if (!lang.isArray(userGroups)) {
                        userGroups = [userGroups];
                    }
                    //  Combine users and groups array
                    usersAndGroupsTagged = usersAndGroupsTagged.concat(userGroups);
                }

                domConstruct.empty(this.userGroupsNode);
                // Loop throw selected values to create button
                array.forEach(usersAndGroupsTagged, function (data) {
                    var button = new InlineButton({ value: data, readOnly: true });
                    button.placeAt(this.userGroupsNode);
                }, this);
            }
        },

        _setupInlineEditBox: function (/*string*/ value) {
            if (!this.messageWidget && this.messageNode) {
                this.messageWidget = new InlineEditBox({
                    value: this._formatUsersTagged(this.message),
                    renderAsHtml: true,
                    editorWrapper: "_DGridInlineEditor",
                    editor: "_EditComment",
                    editorParams: { saveDelegate: function () { }, value: value }, /* Disable autosave of edit widget*/
                    _onMouseOver: function () { /* disable style hover*/ },
                    _onClick: function () { /* disable default onclick on editor*/ },
                    onChange: lang.hitch(this, this._onChangeValue),
                    onCancel: lang.hitch(this, function () {
                        this.resetValue();
                    })
                }, this.messageNode);

                this.own(
                    on(this.messageWidget, "a.epi-readmore-content:click", lang.hitch(this, function (argument) {
                        // Display full message and hidden read more link
                        this.showReadMore = false;
                        this.messageWidget.set("value", this._formatUsersTagged(this.message));

                        var parentContainerNode = query(this.domNode).parents(".dgrid-tree-container")[0];
                        parentContainerNode && domStyle.set(parentContainerNode, "height", "auto");
                    })),

                    aspect.around(this.messageWidget, "_setValueAttr", lang.hitch(this, function (originalMethod) {
                        return lang.hitch(this, function (val) {
                            if (!val) {
                                // Don't save null or empty value, just forward this event
                                this.messageWidget.onChange(val);
                                return;
                            }
                            originalMethod.apply(this.messageWidget, arguments);
                        });
                    }))
                );
            }
        },

        _isActivity: function () {
            // summary:
            //      Return true if feed type is Activity
            // tags:
            //      private

            return this.model && this.model.feedType == ContentCollaborationSettings.FeedTypes.Activity;
        },

        _hasAction: function () {
            // summary:
            //      Return true if feed type is Activity or Status
            // tags:
            //      private
            return this.model && (this.model.feedType == ContentCollaborationSettings.FeedTypes.Activity
                                    || this.model.feedType == ContentCollaborationSettings.FeedTypes.Status);
        },

        _formatUsersTagged: function (/*string*/ text) {
            // summary:
            //      Replace placeholder "@<username>" with html string to display tagged user.
            // tags:
            //      private

            // encode message first
            var message = GridMiscUtil.htmlEncode(lang.clone(text));

            // truncate by words and show read more link
            if (this.showReadMore && strings.wordcount(message) > this.maxWordCount) {
                message = strings.truncatewords(message, this.maxWordCount) + lang.replace("...<a class=\"epi-visibleLink epi-readmore-content\">{0}</a>", [resources.readmore]);
            }

            // replace break line with br tag
            message = message.replace(new RegExp("\r?\n", "g"), "<br/>");

            return this.useEllipsisForMessage ? lang.replace("<div class=\"dojoxEllipsis\" title=\"{0}\">{0}</div>", [message]) : message;
        }
    });
});