﻿define([
    "dojo/_base/array",
    "dojo/_base/connect",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/event",

    "dojo/aspect",
    "dojo/has",
    "dojo/dom-class",
    "dojo/dom-construct",
    "dojo/dom-geometry",
    "dojo/on",
    "dojo/Stateful",
    "dojo/dom-style",
    "dojo/query",
    "dojo/topic",
    "dojo/when",
    "dojo/store/Memory",
    "dojo/html",
    "dojo/json",

// dijit
    "dijit/DropDownMenu",
    "dijit/form/DropDownButton",
    "dijit/form/CheckBox",
    "dijit/focus",
    "dijit/registry",
    "dijit/_TemplatedMixin",

// dojox
    "dojox/html/entities",

// DGrid
    "dgrid/OnDemandGrid",
    "dgrid/Selection",
    "dgrid/Keyboard",
    "dgrid/tree",
    "dgrid/extensions/ColumnResizer",

// EPi
    "epi/epi",
    "epi/dependency",
    "epi/shell/widget/dialog/Confirmation",
    "epi-cms/ApplicationSettings",
    "epi-cms/_ContentContextMixin",

// CA
    "epi-contentcollaboration/widget/ContentCollaborationTreeNode",
    "epi-contentcollaboration/widget/CommentTreeNode",
    "epi-contentcollaboration/widget/_NotificationCounterMixin",
    "epi-contentcollaboration/ContentCollaborationSettings",

// Resources
    "epi/i18n!epi/cms/nls/episerver.components.contentcollaboration",
    "dojo/text!./templates/SubscriptionList.html"

], function (
    array,
    connect,
    declare,
    lang,
    event,

    aspect,
    has,
    domClass,
    domConstruct,
    domGeometry,
    on,
    Stateful,
    domStyle,
    query,
    topic,
    when,
    Memory,
    html,
    JSON,

// dijit
    DropDownMenu,
    DropDownButton,
    CheckBox,
    focusUtil,
    registry,
    _TemplatedMixin,

// dojox
    htmlEntities,

// DGrid
    OnDemandGrid,
    DgridSelection,
    Keyboard,
    Tree,
    ColumnResizer,

// EPi
    epi,
    dependency,
    Confirmation,
    ApplicationSettings,
    _ContentContextMixin,

// CA
    ContentCollaborationTreeNode,
    CommentTreeNode,
    _NotificationCounterMixin,
    ContentCollaborationSettings,

// Resources
    resources,
    template
) {

    return declare([DropDownButton, _NotificationCounterMixin, _TemplatedMixin, _ContentContextMixin], {

        baseClass: "epi-chromelessButton epi-dropdown-selector-button",

        // storeKey: String
        //      The key string to get store by key.
        storeKey: "epi.contentcollaboration.contentsubscription",

        // model: ContentCollaborationViewModel
        //      View model object.
        model: null,

        // label: [String]
        //      The text of button
        label: resources.notifications,

        // iconClass: [String]
        //      The style class for icon. This is global icon using from CMS common icons collection
        iconClass: "epi-icon-collab--Notification",

        // templateString: String
        //      Separated component templage in html file. See ./templates/SubscriptionList.htmls
        templateString: template,

        postCreate: function () {

            this.inherited(arguments);

            this.store = this.store || dependency.resolve("epi.storeregistry").get(this.storeKey);

            this.setupDropDown();
            this.setupCounter();
        },

        setupDropDown: function () {
            // summary:
            //    Set up filter list drop down menu.
            // tags:
            //    protected

            if (!this.dropDown) {
                this.dropDown = new DropDownMenu({ baseClass: "epi-contentcollaboration epi-dropdown-menu epi-subscription", width: "300px" });
            }

            var self = this;

            this.contentContainer = domConstruct.create("div", { "class": "epi-dropdown-menu-container epi-subscription-container" }, this.dropDown.domNode);

            this._grid = this._createGrid(this.store, this.contentContainer);
            domConstruct.place(this._grid.domNode, this.contentContainer);

            this.own(
                    this._grid,
                    this._grid.on(".dgrid-row:click", lang.hitch(this, function (evt) {
                        var row = this._grid.row(evt)
                        // Redirect to version of content link
                        var contextParameters = { uri: "epi.cms.contentdata:///" + row.data.contentLink, context: this };
                        connect.publish("/epi/shell/context/request", [contextParameters, { sender: this }]);
                    })),

                    this.connect(this.dropDown, "onOpen", lang.hitch(this, function () {
                        // scroll to the top of the list
                        this._grid.scrollTo({ x: 0, y: 0 });
                    }))
                );

            this.own(aspect.after(this.store, "notify", function (object, id) {

                // Do nothing when object is deleted
                if (!object) {
                    return;
                }

                // When we receive a new feed, check this to refresh grid.
                when(self.getCurrentContext(), function (currentContext) {
                    // ignore current main feed
                    if (epi.areEqual(object.contentLink, currentContext.id)) {
                        return;
                    }
                    self.buildQueryOptions();
                });
            }, true));

            this.buildQueryOptions();
        },

        _createGrid: function (store, contentContainer) {
            // summary:
            //      Creates and returns grid for displaying content.
            // tags:
            //      private

            var gridClass = declare([OnDemandGrid, DgridSelection, Keyboard, ColumnResizer]),
                self = this,
                grid = new gridClass({
                    columns: {
                        createdBy: {
                            field: "createdBy",
                            label: "",
                            renderCell: lang.hitch(this, this._renderTreeNode),
                            collapseOnRefresh: false
                        },

                        active: {
                            label: "",
                            renderCell: lang.hitch(this, this._renderActiveNode)
                        }
                    },
                    store: store,
                    minWidth: 300,
                    noDataMessage: this._getNodataMessage(resources.nodatamessage, contentContainer),
                    selectionMode: "single",
                    showHeader: false,
                    keepScrollPosition: false
                });

            return grid;
        },

        _getNodataMessage: function (message, contentContainer) {
            // summary:
            //      Get message to display when there is no data.
            // tags:
            //      private

            if (has("ie") === 9) {
                domConstruct.create("tr", { innerHTML: message, "class": "epi-subscription-container dgrid-no-data" }, contentContainer, "before");
            }
            else {
                return resources.nodatamessage;
            }
        },

        contentContextChanged: function () {
            // summary:
            //      Rebuild query options when context changed.
            // tags:
            //      protected

            this.inherited(arguments);
            this.buildQueryOptions();
        },

        buildQueryOptions: function () {
            // summary:
            //      Build query object to get list (Comments or Status)
            // tags:
            //      public

            when(this.getCurrentContext(), lang.hitch(this, function (context) {

                var results = {
                    query: {
                        contentLink: context.id,
                        query: "getnotificationitems"
                    },
                    options: {
                        ignore: ["query"],
                        sort: [{ attribute: "createdDate", descending: true }],
                        comparers: {
                            "contentLink": lang.hitch(this, function (queryValue, instance) {
                                // Ignore virtual Root 
                                //  and not equal content link of current context
                                return !!instance.contentLink && !epi.areEqual(queryValue, instance.contentLink);
                            })
                        }
                    }
                };

                this.set("queryOptions", results);
            }));
        },

        _setQueryOptionsAttr: function (queryOptions) {
            // summary:
            //      Customize set query options method to set grid query.
            // tags:
            //      public

            this._set("queryOptions", queryOptions);
            if (this._grid) {
                this._grid.set("query", queryOptions.query, queryOptions.options);
            }
        },

        _renderActiveNode: function (object, data, td, options) {
            // summary:
            //      Render Active/Deactive checkbox
            // tags:
            //      private

            var model = new Stateful(object),
                checkBox = new CheckBox({ model: model }),
                setTooltip = function (/*Boolean*/ value) {
                    // summary:
                    //      Set tooltip depend on checked or not

                    var tooltip = value ? resources.unchecktodeactivate : resources.checktoactivate;
                    checkBox.set("title", tooltip);
                };

            // Set tooltip default for init
            setTooltip(checkBox.get("checked"));

            checkBox.connect(checkBox, "onClick", lang.hitch(this, this._onCheckBoxClick));

            checkBox.watch("checked", lang.hitch(this, function (name, oldValue, newValue) {
                setTooltip(newValue);
            }));

            checkBox.set("checked", object.fromSubscribeMap && object.fromSubscribeMap.isActive);
            if (!object.fromSubscribeMap) {
                checkBox.set("disabled", true);
            }

            checkBox.placeAt(td);
        },

        _renderTreeNode: function (object, data, td, options) {
            // summary:
            //      Create tree node widget and place into grid's row
            // tags:
            //      private

            var model = new Stateful(object),
                treeNode = new ContentCollaborationTreeNode({ model: model, showCommentLink: false, useEllipsisForMessage: true });

            treeNode.placeAt(td);
        },

        _onCheckBoxClick: function (evt) {
            // summary:
            //      Handle checkbox click event.
            // tags:
            //      private

            // we need to set focus on dropDown after checkbox clicked to avoid closing of dropDown
            // when it lost focus on chrome
            focusUtil.focus(this.dropDown.domNode);

            var checkBox = registry.getEnclosingWidget(evt.target),
                checked = checkBox.get("checked"),
                model = checkBox.get("model"),
                currentSubscription = model.fromSubscribeMap;

            when(this.store.query({ query: "refreshsubscription", contentLink: currentSubscription.contentLink }), lang.hitch(this, function (subscription) {
                var title = checked ? resources.subscribetitle : resources.unsubscribetitle,
                    subscribeTypeText = lang.replace(resources.subscribetypes[subscription.subscribeType.toLowerCase()], [subscription.languageDisplayName]),
                    description = lang.replace(resources[checked ? "subcribedescription" : "unsubcribedescription"], [htmlEntities.encode(model.contentName), subscribeTypeText]),

                    settings = {
                        cancelActionText: resources.cancelbutton,
                        setFocusOnConfirmButton: true,
                        confirmActionText: title,
                        description: description,
                        title: title
                    };

                var dialog = new Confirmation(settings);

                dialog.connect(dialog, "onAction", lang.hitch(this, function (confirm) {
                    if (confirm === true) {
                        when(this.model[checked ? "subscribe" : "unSubscribe"](subscription.contentLink), lang.hitch(this, function () {
                            this.buildQueryOptions();
                        }));
                    } else {
                        // user click on cancel button, set back the check box value.
                        checkBox.set("checked", !checked);
                    }
                }));

                dialog.show();
            }));

            // do not raise row click event
            event.stop(evt);
        }
    });
});
