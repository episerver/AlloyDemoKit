﻿define([
// libs
    'jquery',
// live monitor
    'utility'
],

function (
// libs
    $,
// live monitor
    utility
) {

    // =================================================================================================================================================
    // 'SatelliteAnimation' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Svg/Animation/Effect/SatelliteAnimation'
    // summary:
    //      The satellite effect
    // description:
    //      This is an animation to creating satellite effect for a visitor in Dashboard
    //      Public functions:
    //          apply(/*Object*/marker, /*Integer*/delay)
    // tags:
    //      public

    var SatelliteAnimation = {

        // key: [String] public
        //      The unique key that used to register to the controller
        //      The controller used this key to identifies each registered animation animation
        key: 'Satellite',

        // name: [String] public
        //      The animation animation name that used to register to the controller
        //      The application used this name to display
        name: 'Satellite',

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        apply: function (/*Object*/marker, /*Integer*/delay) {
            // summary:
            //      Create an animation pattern
            // marker: [Object]
            //      The given object that wanted to bind the indicated animation
            // delay: [Integer]
            //      The given delay time
            // tags:
            //      public

            this._initData(marker.datum());
            var repeat = utility.hitch(this, function () {
                this._transform(marker).each('end', repeat);
            });

            setTimeout(repeat, delay * 5);
        },

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

        _initData: function (d) {
            var cx = d.x + d.visitorRadius,
                fcradius = d.fociBBox.width / 2;

            d.animationInfo = {
                centerX: cx,
                centerY: d.y + d.visitorRadius,
                fociCenterX: d.fociBBox.x + fcradius,
                fociCenterY: d.fociBBox.y + fcradius,
                goFront: cx >= (d.fociBBox.x + fcradius)
            };
        },

        _transform: function (/*Object*/marker) {
            // summary:
            //      Create the path for the animation to the given marker
            // marker: [Object]
            //      The given marker object that wanted to map the path
            // tags:
            //      private

            return marker.transition().duration(1200)
                .ease("linear")
                .attrTween('transform', utility.hitch(this, this._tweenTransform))
                .styleTween('fill-opacity', utility.hitch(this, this._tweenOpacity));
        },

        _tweenTransform: function (/*Object*/d) {
            // summary:
            //      Get X,Y position and scale
            // d: [Object]
            //      The given object data
            // tags:
            //      private

            return utility.hitch(this, function (t) {
                // summary:
                //      Return X, Y and scale value at a time
                // t: [0,1]
                //      The time range

                var toX = this._getXpos(d, t),
                    toY = this._getYpos(d, t),
                    scale = d.animationInfo.goFront ? 1 : Math.sin(Math.abs(t - 0.5) * Math.PI);

                if (t === 1) {
                    d.animationInfo.goFront = (toX + d.visitorRadius) >= d.animationInfo.fociCenterX;
                }

                return 'translate(' + toX + ',' + toY + ')scale(' + scale + ')';
            });
        },

        _tweenOpacity: function (/*Object*/d) {
            // summary:
            //      Get opacity value by time
            // d: [Object]
            //      The given object data
            // tags:
            //      private

            return function (t) {
                // summary:
                //      Return opacity value at a time
                // t: [0,1]
                //      The time range

                return d.animationInfo.goFront ? 1 : Math.sin(Math.abs(t - 0.5) * Math.PI);
            };
        },

        _getXpos: function (/*Object*/d, /*number*/t) {
            // summary:
            //      Get X position by time
            // d: [Object]
            //      The current datum
            // t: number
            //      A number in [0,1]
            // tags:
            //      private

            var toX;

            if (d.animationInfo.goFront) {
                toX = (d.animationInfo.centerX < d.animationInfo.fociCenterX) ?
                    d.x + 2 * (d.animationInfo.fociCenterX - d.animationInfo.centerX) * (1 - t) :
                    d.x - 2 * (d.animationInfo.centerX - d.animationInfo.fociCenterX) * t;
            }
            else {
                toX = (d.animationInfo.centerX < d.animationInfo.fociCenterX) ? 
                    d.x + 2 * (d.animationInfo.fociCenterX - d.animationInfo.centerX) * t :
                    d.x - 2 * (d.animationInfo.centerX - d.animationInfo.fociCenterX) * (1 - t);
            }

            return toX;
        },

        _getYpos: function (/*Object*/d, /*number*/t) {
            // summary:
            //      Get Y position by time
            // d: [Object]
            //      The current datum
            // t: number
            //      A number in [0,1]
            // tags:
            //      private

            var toY;

            if (d.animationInfo.goFront) {
                toY = (d.animationInfo.centerY < d.animationInfo.fociCenterY) ?
                    d.y + 2 * (d.animationInfo.fociCenterY - d.animationInfo.centerY) * (1 - t) :
                    d.y - 2 * (d.animationInfo.centerY - d.animationInfo.fociCenterY) * t;
            }
            else {
                toY = (d.animationInfo.centerY < d.animationInfo.fociCenterY) ?
                    d.y + 2 * (d.animationInfo.fociCenterY - d.animationInfo.centerY) * t :
                    d.y - 2 * (d.animationInfo.centerY - d.animationInfo.fociCenterY) * (1 - t);
            }

            return toY;
        }

    };

    return SatelliteAnimation;

});