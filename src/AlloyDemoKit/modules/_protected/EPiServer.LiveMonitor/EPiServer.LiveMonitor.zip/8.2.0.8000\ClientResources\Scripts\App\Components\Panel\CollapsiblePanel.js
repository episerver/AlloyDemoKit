﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'components/ComponentFactory',
// resources
    'text!components/Panel/Templates/CollapsiblePanel.html'
],

function (
// libs
    $,
// live monitor
    utility,

    componentFactory,
// resources
    templateString
) {

    // =================================================================================================================================================
    // 'LiveMonitorCollapsiblePanel' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Panel/LiveMonitorCollapsiblePanel'
    // summary:
    //      The jQuery plugin component for the collapsible panel
    // description:
    //      use:
    //          $(target).LiveMonitorCollapsiblePanel(options);
    //      options:
    //          resources [Object]
    //          templateString [String]
    //          baseClasses [String]
    //          children: [Array]
    // tags:
    //      public

    // Create the defaults once
    var pluginName = 'LiveMonitorCollapsiblePanel',
        pluginOptions = {
            templateString: templateString,
            baseClasses: 'livemonitor-collapsiblePanel',
            children: []
        },
        pluginDefinitions = {

            // =================================================================================================================================================
            // Overrided functions
            // =================================================================================================================================================

            _postInit: function () {
                // summary:
                //      Post-initialize settings for the component
                // tags:
                //      protected, extension

                this._setupLayout();
                this._setupEvents();
            },

            // =================================================================================================================================================
            // Public events
            // =================================================================================================================================================

            onToggle: function (/*Event*/evt) {
                // summary:
                //      Toggle the display of the current component
                // evt: [Event]
                //      The given event
                // tags:
                //      private

                this._$collapseController.toggleClass('glyphicon-chevron-right');
                this._$collapseController.toggleClass('glyphicon-chevron-left');
            },

            // =================================================================================================================================================
            // Private functions
            // =================================================================================================================================================

            // =================================================================================================================================================
            // Setup layout functions
            // =================================================================================================================================================

            _setupLayout: function () {
                // summary:
                //      Initialize default layout settings for the component
                // tags:
                //      private

                this._setupCollapseControl();
            },

            _setupCollapseControl: function () {
                // summary:
                //      Setup for the collapsible controller control
                // tags:
                //      private

                this._$collapseController = this._$wrapper.find('.collapse-controller');
                (this._resources.tooltip && this._$collapseController)
                    && this._$collapseController.attr('title', this._resources.tooltip);
            },

            // =================================================================================================================================================
            // Setup events functions
            // =================================================================================================================================================

            _setupEvents: function () {
                // summary:
                //      Setup events for the current container
                // tags:
                //      private

                this._$collapseController.on('click', utility.hitch(this, function () {
                    this.triggerContextEvent('toggleCollapsiblePanel');
                }));
            }
        };

    // A really lightweight plugin wrapper around the constructor, 
    //  preventing against multiple instantiations
    $.fn[pluginName] = function (/*Object*/options) {
        // summary:
        //      Create a new jQuery plugin from the given settings
        // options: [Object]
        //      The given settings that wanted to decorates the default settings of the current component
        // returns: [Object]
        //      The jQuery plugin object
        // tags:
        //      protected

        // Decorates the default settings by the given settings
        $.extend(true, pluginOptions, options);

        // Create and then return a new jQuery plugin object
        return componentFactory.create(this, pluginName, pluginDefinitions, pluginOptions);
    };

});