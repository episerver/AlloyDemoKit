﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'components/ComponentFactory',

    'components/Svg/ExternalTemplatePreloader',

    'components/Button/AppSettingsButton',
    'components/Button/HighwayToolbar',
    'components/Button/ToggleFullScreenButton',
    'components/Button/ToggleCollapsiblePanelButton',

    'components/Clock/Clock',

    'components/Container/Container',
    'components/Container/ModalContainer',
    'components/Container/TabContainer',

    'components/Notification/LoadingOverlayLayoutWrapper',

    'components/ListBox/ListBox',

    'components/Panel/CollapsiblePanel',

    'components/Statistic/StatisticsBar',

    'components/Tree/MultiLayerContainer',
// resources
    'text!components/Container/Templates/Dashboard.html'
],

function (
// libs
    $,
// live monitor
    utility,

    componentFactory,

    externalTemplatePreloader,

    appSettingsButton,
    highwayToolbar,
    toggleFullScreenButton,
    toggleCollapsiblePanelButton,

    clock,

    container,
    modalContainer,
    tabContainer,

    loadingOverlayLayoutWrapper,

    listbox,

    collapsiblePanel,

    statisticsBar,

    multiLayerContainer,
// resources
    templateString
) {

    // =================================================================================================================================================
    // Plugin information
    // =================================================================================================================================================
    //
    // module:
    //      Components/Container/LiveMonitorDashboard
    // summary:
    //      
    // description:
    //      use:
    //          $(target).LiveMonitorDashboard(options);
    //
    //      options:
    //          resources: [Object]
    //          templateString: [String]
    //          baseClasses: [String]
    //
    //      required:
    //          
    //          
    // tags:
    //      public

    // Create the defaults once
    var pluginName = 'LiveMonitorDashboard',
        pluginOptions = {
            templateString: templateString,
            baseClasses: 'livemonitor-dashboard clearfix',
            notifierCallback: 'broadcastVisitorsData',
            sender: 'trace',
            senderCallback: 'getVisitorsData'
        },
        pluginDefinitions = {

            // =================================================================================================================================================
            // Overrided functions
            // =================================================================================================================================================

            _postInit: function () {
                // summary:
                //      Post-initialize settings for the component
                // tags:
                //      protected, extension

                this._setupLayout();
                this._setupEvents();

                this._setupDefaultSettings();

                this.layout();
            },

            // =================================================================================================================================================
            // Public callback functions
            // =================================================================================================================================================

            layout: function () {
                // summary:
                //      Fired while the current component in the pre-init state and before post-init
                // tags:
                //      public, extensions

                if (!utility.isValidArray(this._childPlugins)) {
                    return;
                }

                $.when(this._$layoutReady)
                    .done(utility.hitch(this, function () {
                        if (!utility.isValidArray(this._childPlugins)) {
                            return;
                        }

                        var totalItems = this._childPlugins.length,
                            instance;

                        while (totalItems--) {
                            instance = utility.getInstance(this._childPlugins[totalItems]);
                            (instance && $.isFunction(instance.layout)) && instance.layout();
                        }
                    }));

                // In case toggle visitor list button is visible, should hide the visitor list even when it is open
                if (this._$asideFirst && !this._$asideFirst.hasClass('collapsed') &&
                    this._$sidePanel && this._$sidePanel.is(':visible')) {
                    this._onToggleCollapsiblePanel();
                }
            },

            onNotified: function (/*Object*/visitorsData) {
                // summary:
                //      Fired when had any change in server side
                // visitorsData: [Object]
                //      The given visitors data that returned from server side
                //      It included following information:
                //          onlineVisitors: [Array]
                //              The given collection of online visitor object
                //          historyVisitors: [Array]
                //              The given collection of history visitor object
                // tags:
                //      public, extensions

                visitorsData = utility.getJSONObject(visitorsData);

                $.when(this._$layoutReady)
                    .done(utility.hitch(this, function () {
                        // Bind the given visitors data for each child component
                        this.bindData(visitorsData);
                    }));
            },

            onReceiveCompleted: function (/*Object*/visitorsData) {
                // summary:
                //      Fired after client requested to server and then server responsed
                // visitorsData: [Object]
                //      The given visitors data that returned from server side
                //      It included following information:
                //          onlineVisitors: [Array]
                //              The given collection of online visitor object
                //          historyVisitors: [Array]
                //              The given collection of history visitor object
                // tags:
                //      public, extensions

                visitorsData = utility.getJSONObject(visitorsData);

                visitorsData && this._bindVisitorsData(visitorsData);
            },

            bindData: function (/*Object*/data) {
                // summary:
                //      Data binding for the component's children
                // data: [Object]
                //      The given data that wanted to bind to the component's children
                // tags:
                //      public, extensions

                data && this._bindVisitorsData(data);
            },

            // =================================================================================================================================================
            // Private events
            // =================================================================================================================================================

            _onToggleCollapsiblePanel: function () {
                // summary:
                //      Fired when click on the collapsible controller of the collapsible panel component
                // tags:
                //      private

                // Collapse/Expand the collapsible panel
                this._$asideFirst && this._$asideFirst.toggleClass('collapsed visible');

                var state = this._getAsideFirstState();
                this._setComponentsState(state);

                (state === 'show') && this._requestVisitorsData();

                var visitorsTabContainer = utility.getInstance(this._$visitorsTabContainer);
                (visitorsTabContainer && $.isFunction(visitorsTabContainer.layout)) && visitorsTabContainer.layout();

                // Update state of the collapsible panel controller
                var collapsiblePanel = utility.getInstance(this._$collapsiblePanel);
                (collapsiblePanel && $.isFunction(collapsiblePanel.onToggle)) && collapsiblePanel.onToggle();

                // Update state of the ToggleCollapsiblePanelButton
                var toggleCollapsiblePanelButton = utility.getInstance(this._$toggleCollapsiblePanelButton);
                (toggleCollapsiblePanelButton && $.isFunction(toggleCollapsiblePanelButton.onToggle)) && toggleCollapsiblePanelButton.onToggle();

                this._$content && this._$content.toggleClass('col-md-10'); // TODO: Remove 'col-md-10' CSS class that depends on Twitter Bootstrap
            },

            _onShowAppSettings: function () {
                // summary:
                //      Fired when click on the cogwheel button (settings) component
                // tags:
                //      private

                this._$appSettingsModalContainer && $.isFunction(this._$appSettingsModalContainer.modal)
                    && this._$appSettingsModalContainer.modal({
                        backdrop: false
                    });
            },

            _onResetPersistenceCaches: function () {
                // summary:
                //      Reset all application settings
                // tags:
                //      private

                $.when(this._resetPersistenceCaches()).done(function () {
                    utility.refreshApp();
                });
            },

            _onSaveAppSettings: function () {
                // summary:
                //      Fired when click on the 'Save' button in the application settings modal dialog
                // tags:
                //      private

                $.when(this._resetPersistenceCaches()).done(utility.hitch(this, function () {
                    var settingItemList = this._getSettingItemList();
                    if (!utility.isValidArray(settingItemList)) {
                        return;
                    }

                    var totalItems = settingItemList.length,
                        item;
                    while (totalItems--) {
                        item = settingItemList[totalItems];

                        if (item && $.isFunction(item.getItemSetting)) {
                            this.registerSetting(item.getItemSetting());
                        }

                        if (totalItems === 0) {
                            utility.refreshApp();
                        }
                    }
                }));
            },

            _onCloseAppSettings: function () {
                // summary:
                //      Fired when click on the 'Close' button or the 'x' icon in the application settings modal dialog
                // tags:
                //      private

                var settingItemList = this._getSettingItemList();
                if (!utility.isValidArray(settingItemList)) {
                    return;
                }

                var totalItems = settingItemList.length,
                    item;
                while (totalItems--) {
                    item = settingItemList[totalItems];

                    if (item && $.isFunction(item.restoreSelection)) {
                        this.registerSetting(item.restoreSelection());
                    }
                }
            },

            _onUpdateVisitorsData: function (/*Event*/evt, /*Object*/visitorsData) {
                // summary:
                //      Bind visitors data to each visitor components:
                //          Online visitor list
                //          History visitor list
                // evt: [Event]
                //      The given event object
                // visitorsData: [Object]
                //      The given visitors data that wanted to bind to the component's children
                //          onlineVisitors: [Array]
                //              The collection of online visitor objects
                //          historyVisitors: [Array]
                //              The collection of history visitor objects
                // tags:
                //      private

                this._bindVisitorsDataToListControls(visitorsData);
            },


            // =================================================================================================================================================
            // Private functions
            // =================================================================================================================================================

            _resetPersistenceCaches: function () {
                // summary:
                //      Reset all data in persistence caches
                // tags:
                //      private

                var $deferred = $.Deferred(),
                    caches = this._resettablePersistenceCaches;

                utility.isValidArray(caches)
                    && $.each(caches, function (index, item) {
                        require(['data/' + item], function (/*Object*/persistenceCache) {
                            persistenceCache && $.isFunction(persistenceCache.resetToDefault) && persistenceCache.resetToDefault();

                            if (index == caches.length - 1) { // looped to the end of array
                                $deferred.resolve();
                            }
                        });
                    });

                return $deferred.promise();
            },

            // =================================================================================================================================================
            // Setup layout functions
            // =================================================================================================================================================

            _setupLayout: function () {
                // summary:
                //      Initialize default layout settings for the component
                // tags:
                //      private

                this._componentsResources = this._resources.components;

                this._inEmbeddedMode = LiveMonitorConfig && LiveMonitorConfig.embeddedMode;

                this._$asideFirst = this._$wrapper.find('#aside-first');
                this._$topPanel = this._$wrapper.find('#top-panel');
                this._$sidePanel = this._$wrapper.find('#side-panel');
                this._$bottomPanel = this._$wrapper.find('#bottom-panel');
                this._$content = this._$wrapper.find('#content');

                var $loadingOverlayLayoutWrapper = $(this.options.placeHolder).LiveMonitorLoadingOverlayLayoutWrapper({
                    resources: this._componentsResources.notification.loadingoverlay
                });

                // Loading overlay - START
                var loadingOverlayLayoutWrapper = utility.getInstance($loadingOverlayLayoutWrapper);
                loadingOverlayLayoutWrapper.startLoading();

                this._$layoutReady = $.Deferred();

                this._setupSharedSettings();

                this._setupAppSettingsArea();
                this._setupAsideFirstArea();
                this._setupTopPanelArea();
                this._setupSidePanelArea();
                this._setupBottomPanelArea();
                this._setupContentArea();

                // Loading overlay - STOP
                loadingOverlayLayoutWrapper.stopLoading();

                this._$layoutReady.resolve();
            },

            _setupSharedSettings: function () {
                // summary:
                //      Setup the application shared settings
                // tags:
                //      private

                externalTemplatePreloader.appendShared(this._$wrapper);
                externalTemplatePreloader.loadTemplates();
            },

            _setupAppSettingsArea: function () {
                // summary:
                //      Setup the application settings area and its children
                // tags:
                //      private

                this._$appSettingsList = $('<div id="livemonitor-applicationSettingsList"></div>').LiveMonitorListBox({
                    resources: this._componentsResources.applicationsettings,
                    baseClasses: 'form-horizontal livemonitor-listBox',
                    itemPlugin: 'LiveMonitorAppSettingsListBoxItem'
                });

                var appSettingsList = utility.getInstance(this._$appSettingsList),
                    appSettingKeyList = this.getSettingKeyList();
                appSettingsList && appSettingsList.bindData(appSettingKeyList);

                this._$appSettingsModalContainer = $('<div id="livemonitor-applicationSettingsModal"></div>').LiveMonitorModalContainer({
                    resources: this._componentsResources.modal.appsettings,
                    children: [this._$appSettingsList],
                    showReset: true,
                    showSave: true,
                    showClose: true
                });

                // Add to container
                this._$wrapper.append(this._$appSettingsModalContainer);
            },

            _setupAsideFirstArea: function () {
                // summary:
                //      Setup the first aside area and its children
                // tags:
                //      private

                !$.isArray(this._childPlugins) && (this._childPlugins = []);

                var extraInfoResources = this._componentsResources.listbox.extrainfo;

                this._$onlineVisitors = $('<div id="livemonitor-onlineVisitorList"></div>').LiveMonitorListBox({
                    resources: this._componentsResources.listbox.onlinelistbox,
                    extraInfoResources: extraInfoResources,
                    itemPlugin: 'LiveMonitorOnlineVisitorsListBoxItem'
                });

                this._$historyVisitors = $('<div id="livemonitor-historyVisitorList"></div>').LiveMonitorListBox({
                    resources: this._componentsResources.listbox.historylistbox,
                    extraInfoResources: extraInfoResources,
                    itemPlugin: 'LiveMonitorHistoryVisitorsListBoxItem'
                });

                this._$visitorsTabContainer = $('<div id="livemonitor-visitorsTabContainer"></div>').LiveMonitorTabContainer({
                    resources: this._componentsResources.visitorstabcontainer,
                    children: [
                        {
                            'id': 'online-visitors-tab',
                            name: this._componentsResources.visitorstabcontainer.online.name,
                            content: this._$onlineVisitors,
                            active: true
                        },
                        {
                            'id': 'history-visitors-tab',
                            name: this._componentsResources.visitorstabcontainer.history.name,
                            content: this._$historyVisitors
                        }
                    ]
                });
                this._childPlugins.push(this._$visitorsTabContainer);

                this._$collapsiblePanel = $('<div id="livemonitor-aside-visitorsListBoxes"></div>').LiveMonitorCollapsiblePanel({
                    resources: this._componentsResources.panel.visitorscollapsiblepanel,
                    children: [this._$visitorsTabContainer]
                });

                // Add to container
                this._$asideFirst.append(this._$collapsiblePanel);
            },

            _setupTopPanelArea: function () {
                // summary:
                //      Setup the top panel area and its children
                // tags:
                //      private

                if (!this._inEmbeddedMode) {
                    var $toggleFullScreenButton = $('<div id="livemonitor-toggleFullScreenMode"></div>').LiveMonitorToggleFullScreenButton({
                        resources: this._componentsResources.button.togglefullscreenbutton,
                        fullScreenTarget: this._$wrapper[0]
                    });

                    // Add to container
                    this._$topPanel.append($toggleFullScreenButton);
                }

                var $appSettingsButton = $('<div id="livemonitor-applicationSettings"></div>').LiveMonitorAppSettingsButton({
                    resources: this._componentsResources.button.appsettingsbutton
                });

                // Add to container
                this._$topPanel.append($appSettingsButton);
            },

            _setupSidePanelArea: function () {
                // summary:
                //      Setup the side panel area and its children
                // tags:
                //      private

                this._$toggleCollapsiblePanelButton = $('<div id="livemonitor-toggleVisitorsList"></div>').LiveMonitorToggleCollapsiblePanelButton({
                    resources: this._componentsResources.button.togglevisitorslistbutton,
                    collapsiblePanel: this._$collapsiblePanel
                });

                // Add to container
                this._$sidePanel.append(this._$toggleCollapsiblePanelButton);
            },

            _setupBottomPanelArea: function () {
                // summary:
                //      Setup the bottom panel area and its children
                // tags:
                //      private

                // =================================================================================================================================================
                // First Area
                // =================================================================================================================================================

                var $highwayToolbar = $('<div id="livemonitor-highwayToolbar"></div>').LiveMonitorHighwayToolbar({
                    resources: this._componentsResources.button.radiobuttongroup.highway
                });

                // Add to container
                this._$bottomPanel.find('.area-first').append($highwayToolbar);

                // =================================================================================================================================================
                // Second Area
                // =================================================================================================================================================

                this._$statisticsBar = $('<div id="livemonitor-statisticsBar"></div>').LiveMonitorStatisticsBar({
                    resources: this._componentsResources.statistic
                });

                var $clock = $('<div id="livemonitor-clock"></div>').LiveMonitorClock({
                    resources: this._componentsResources.clock
                });

                // Add to container
                this._$bottomPanel.find('.area-second').LiveMonitorContainer({
                    children: [this._$statisticsBar, $clock]
                });
            },

            _setupContentArea: function () {
                // summary:
                //      Setup the content area and its children
                // tags:
                //      private

                this._$multiLayerContainer = $('<div></div>').LiveMonitorMultiLayerContainer({
                    containerWidth: this._$content.width(),
                    containerHeight: this._$content.height()
                });

                // Add to container
                this._$multiLayerContainer.insertBefore(this._$topPanel);
            },

            _setupDefaultSettings: function () {
                // summary:
                //      Initializes the default settings for the current component
                // tags:
                //      private

                this._resettablePersistenceCaches = [
                    'SettingRepository',
                    'TemplateRepository',
                    'TransferRepository'
                ];

                $.when(this._$layoutReady)
                    .done(utility.hitch(this, function () {
                        // Set the default state for the collapsible panel component
                        if (this._$collapsiblePanel && this.getSetting('expandCollapsiblePanel') === 'true') {
                            this._onToggleCollapsiblePanel();
                        }

                        this._setComponentsState(this._getAsideFirstState());
                    }));
            },

            _setComponentsState: function (/*String*/state) {
                // summary:
                //      Set state for the current component's children
                // state: [String]
                //      The given state that want to set to the given components
                // tags:
                //      private

                // Set state for online/history visitors list boxes
                utility.setComponentsState([this._$visitorsTabContainer], state);
            },

            _getSettingItemList: function () {
                // summary:
                //      Get registered setting item collection
                // returns: [Array]
                //      The collection of the registered setting item object
                // tags:
                //      private

                if (!this._$appSettingsList) {
                    return;
                }

                var appSettingList = utility.getInstance(this._$appSettingsList);
                if (!appSettingList) {
                    return;
                }

                return $.isFunction(appSettingList.getChildren) && appSettingList.getChildren();
            },

            _getAsideFirstState: function () {
                // summary:
                //      Get first aside component state
                // returns: [String]
                // tags:
                //      private

                return this._$asideFirst.hasClass('collapsed') ? 'hide' : 'show';
            },

            // =================================================================================================================================================
            // Setup events functions
            // =================================================================================================================================================

            _setupEvents: function () {
                // summary:
                //      Setup events for the current container
                // tags:
                //      private

                this.bindContextEvent('toggleCollapsiblePanel', utility.hitch(this, this._onToggleCollapsiblePanel));

                this.bindContextEvent('showVisitorsTabContent', utility.hitch(this, this._requestVisitorsData));

                this.bindContextEvent('showAppSettings', utility.hitch(this, this._onShowAppSettings));

                this.bindContextEvent('modalDialogResetting', utility.hitch(this, this._onResetPersistenceCaches));
                this.bindContextEvent('modalDialogSaving', utility.hitch(this, this._onSaveAppSettings));
                this.bindContextEvent('modalDialogClosing', utility.hitch(this, this._onCloseAppSettings));

                this.bindContextEvent('updateVisitorsData', utility.hitch(this, this._onUpdateVisitorsData));
            },

            // =================================================================================================================================================
            // Data binding functions
            // =================================================================================================================================================

            _getFilteredVisitorsData: function (/*Object*/visitorsData) {
                // summary:
                //      Filter to get visitors visiting current dashboard UI language
                // visitorsData: [Object]
                //      The given visitors data that returned from server side
                //      It included following information:
                //          onlineVisitors: [Array]
                //              The given collection of online visitor object
                //          historyVisitors: [Array]
                //              The given collection of history visitor object
                // returns: [Object]
                //      The filtered visitors data by the given setting language
                // tags:
                //      private

                if (!visitorsData || !$.isArray(visitorsData.onlineVisitors) || !$.isArray(visitorsData.historyVisitors)) {
                    return;
                }

                if (this._getLanguageId() === '') {
                    return {
                        onlineVisitors: visitorsData.onlineVisitors,
                        historyVisitors: visitorsData.historyVisitors
                    };
                }

                var filter = utility.hitch(this, this._filterVisitContents);

                return {
                    onlineVisitors: visitorsData.onlineVisitors.filter(filter),
                    historyVisitors: visitorsData.historyVisitors.filter(filter)
                };
            },

            _filterVisitContents: function (/*Object*/itemData) {
                // summary:
                //      Funtion to test whether a visitor is visiting a page in language selected for UI 
                // itemData: [Object]
                //      The given item data object to be verified
                // tags:
                //      private

                if (!itemData || !itemData.visit.currentContent
                        || !itemData.visit.currentContent.languageId) {
                    return false;
                }

                return itemData.visit.currentContent.languageId.toLowerCase() === this._getLanguageId();
            },

            _bindVisitorsData: function (/*Object*/visitorsData) {
                // summary:
                //      Bind visitors data to each visitor components:
                //          Multi-layer container
                //          Online visitor list
                //          History visitor list
                // visitorsData: [Object]
                //      The given visitors data that wanted to bind to the component's children
                //          onlineVisitors: [Array]
                //              The collection of online visitor objects
                //          historyVisitors: [Array]
                //              The collection of history visitor objects
                // tags:
                //      private

                visitorsData = this._getFilteredVisitorsData(visitorsData);

                var onlineVisitors = visitorsData.onlineVisitors;

                this._bindComponentData(this._$statisticsBar, onlineVisitors);
                this._bindComponentData(this._$multiLayerContainer, onlineVisitors);

                this._bindVisitorsDataToListControls(visitorsData);
            },

            _bindVisitorsDataToListControls: function (/*Object*/visitorsData) {
                // summary:
                //      Bind visitors data to each visitor components:
                //          Online visitor list
                //          History visitor list
                // visitorsData: [Object]
                //      The given visitors data that wanted to bind to the component's children
                //          onlineVisitors: [Array]
                //              The collection of online visitor objects
                //          historyVisitors: [Array]
                //              The collection of history visitor objects
                // tags:
                //      private

                this._bindComponentData(this._$onlineVisitors, visitorsData.onlineVisitors);
                this._bindComponentData(this._$historyVisitors, visitorsData.historyVisitors);
            },

            _bindComponentData: function (/*Object*/pluginObject, /*Object*/data) {
                // summary:
                //      Get component object and then bind the given data to it
                // pluginObject: [Object]
                //      The given jQuery plugin object
                // data: [Object]
                //      The given data that wanted to bind to the given component
                // tags:
                //      private

                if (!pluginObject || !data) {
                    return;
                }

                var instance = utility.getInstance(pluginObject);
                if (!instance) {
                    return;
                }

                (data && $.isFunction(instance.bindData)) && instance.bindData(utility.cloneObject(data));
            },

            // =================================================================================================================================================
            // Request data functions
            // =================================================================================================================================================

            _requestVisitorsData: function () {
                // summary:
                //      Send request to server ('getVisitorsData') in order to get hierarchical data
                // tags:
                //      private

                // Send a request to 'getVisitorsData' proxy function
                //  with following parameters:
                //      languageId: [String]
                //          The given language identification
                $.isFunction(this.send) && this.send();
            }

        };

    // A really lightweight plugin wrapper around the constructor, 
    //  preventing against multiple instantiations
    $.fn[pluginName] = function (/*Object*/options) {
        // summary:
        //      Create a new jQuery plugin from the given settings
        // options: [Object]
        //      The given settings that wanted to decorates the default settings of the current component
        // returns: [Object]
        //      The jQuery plugin object
        // tags:
        //      protected

        // Decorates the default settings by the given settings
        $.extend(true, pluginOptions, options);

        // Create and then return a new jQuery plugin object
        return componentFactory.create(this, pluginName, pluginDefinitions, pluginOptions);
    };

});