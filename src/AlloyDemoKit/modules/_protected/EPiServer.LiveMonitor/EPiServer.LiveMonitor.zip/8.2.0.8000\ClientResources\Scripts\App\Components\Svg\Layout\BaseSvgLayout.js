﻿define([
// libs
    'jquery',
    'd3',
// live monitor
    'utility'
],

function (
// libs
    $,
    dataVisualizer,
// live monitor
    utility
) {

    // =================================================================================================================================================
    // Component information
    // =================================================================================================================================================
    //
    // module:
    //      Components/Svg/Layout/BaseSvgLayout
    // summary:
    //      
    // description:
    //      
    // tags:
    //      public

    var BaseSvgLayout = {

        // =================================================================================================================================================
        // Protected functions
        // =================================================================================================================================================

        _stopPropagation: function () {
            // summary:
            //      Stop event propagation of the data visualizer (at the moment, it is d3js)
            // tags:
            //      protected

            var event = dataVisualizer.event;
            if (event) {
                $.isFunction(event.stopPropagation) && event.stopPropagation();
            }
        },

        _shouldUpdate: function (/*Array*/updateData) {
            // summary:
            //      Verify that should update and refresh the component with the given data
            // updateData: [Array]
            //      The given data set that wanted to bind to the current component
            // tags:
            //      protected

            if (this._currentData && utility.isEquals(this._currentData, updateData)) {
                return false;
            }

            this._currentData = updateData;

            return true;
        },

        _getTemplateContent: function (/*Object*/selector) {
            // summary:
            //      Get template content by the given selector object
            // selector: [Object]
            //      The given d3js selector object
            // returns: [Object]
            //      A d3js element object
            // tags:
            //      protecte

            return dataVisualizer.select(selector).select('.livemonitor-templateContent').node();
        },

    };

    return BaseSvgLayout;

});