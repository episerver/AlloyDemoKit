﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'components/ComponentFactory',

    'components/ListBox/ListBoxItem',
// resources
    'text!components/ListBox/Templates/AppSettingsListBoxItem.html',
    'text!components/ListBox/Templates/TextControl.html',
    'text!components/ListBox/Templates/SelectControl.html'
],

function (
// libs
    $,
// live monitor
    utility,

    componentFactory,

    listBoxItem,
// resources
    templateString,
    textControlTemplateString,
    selectControlTemplateString
) {

    // =================================================================================================================================================
    // 'LiveMonitorAppSettingsListBoxItem' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/ListBox/LiveMonitorAppSettingsListBoxItem'
    // summary:
    //      The jQuery plugin component for the application settings listbox item
    // description:
    //      use:
    //          $(target).LiveMonitorAppSettingsListBoxItem(options);
    //      options:
    //          resources [Object]
    //          templateString [String]
    //          itemData [Object]
    //          itemIdPrefix [String]
    //          itemIdField [String]
    // tags:
    //      public

    // Create the defaults once
    var pluginName = 'LiveMonitorAppSettingsListBoxItem',
        pluginOptions = {
            templateString: templateString
        },
        pluginDefinitions = {

            // _textControlTemplateString: [String] private
            //      Template string for the INPUT (type="text") control
            _textControlTemplateString: textControlTemplateString,

            // _selectControlTemplateString: [String] private
            //      Template string for the SELECT control
            _selectControlTemplateString: selectControlTemplateString,

            // =================================================================================================================================================
            // Overrided functions
            // =================================================================================================================================================

            _postInit: function () {
                // summary:
                //      Post-initialize settings for the component
                // tags:
                //      protected, extension

                this._setupLayout();
            },

            // =================================================================================================================================================
            // Public functions
            // =================================================================================================================================================

            getItemSetting: function () {
                // summary:
                //      Get entered value in the current component input control
                // returns: [Object]
                //      The application setting item object
                // tags:
                //      public

                return {
                    settingKey: this._itemData,
                    value: this._$inputControl && this._$inputControl.val()
                };
            },

            restoreSelection: function () {
                // summary:
                //      Remove temporary selection of the current component
                // tags:
                //      public

                this._selection && this._selection.prop('selected', true);
            },

            // =================================================================================================================================================
            // Private functions
            // =================================================================================================================================================

            // =================================================================================================================================================
            // Layout functions
            // =================================================================================================================================================

            _setupLayout: function () {
                // summary:
                //      Setup layout for the current component
                // tags:
                //      private

                this._itemData = this.options.itemData;

                this._setupSettingItem();
            },

            _setupSettingItem: function () {
                // summary:
                //      Setup the setting item
                // tags:
                //      private

                if (!this._itemData) {
                    return;
                }

                this._$controlContainer = this._$controlContainer || this._$wrapper.find('.form-group .control-container');

                this._setSettingName();

                var uiValueList = this.getSettingValues(this._itemData),
                    settingValue = this.getSetting(this._itemData);
                $.isArray(uiValueList)
                    ? this._appendSelectControl()
                    : this._appendTextControl();

                this._setSettingValue(uiValueList, settingValue);
            },

            _appendTextControl: function () {
                // summary:
                //      Append INPUT (type="text") control to the given container
                // tags:
                //      private

                this._$textControl = this._$textControl || $(this._textControlTemplateString);

                !utility.isValidArray(this._$controlContainer.has(this._$textControl))
                    && this._$controlContainer.append(this._$textControl);
            },

            _appendSelectControl: function () {
                // summary:
                //      Append SELECT control to the given container
                // tags:
                //      private

                this._$selectControl = this._$selectControl || $(this._selectControlTemplateString);

                !utility.isValidArray(this._$controlContainer.has(this._$selectControl))
                    && this._$controlContainer.append(this._$selectControl);
            },

            _setSettingName: function () {
                // summary:
                //      Set setting name
                // tags:
                //      private

                var resourceKey = this._itemData.toLowerCase();
                if (!this._resources || !this._resources.hasOwnProperty(resourceKey)) {
                    return;
                }

                this._$settingName = this._$settingName || this._$wrapper.find('.form-group .control-label');
                this._$settingName && this._$settingName.text(this._resources[resourceKey].text);
            },

            _setSettingValue: function (/*Array*/uiValueList, /*Object*/settingValue) {
                // summary:
                //      Set setting value
                // uiValueList: [Array]
                //      The given registered application settings value list
                // settingValue: [Object]
                //      The given registered application settings value
                // tags:
                //      private

                this._$inputControl = this._$controlContainer.find('.form-control');
                if (!this._$inputControl) {
                    return;
                }

                if (!utility.isValidArray(uiValueList)) {
                    this._$inputControl.val(settingValue);

                    return;
                }

                var totalItems = uiValueList.length,
                    item,
                    $option;

                while (totalItems--) {
                    item = uiValueList[totalItems];
                    if (!item) {
                        continue;
                    }

                    $option = $('<option></option>');
                    $option.attr('value', item.key);
                    $option.text(item.name);

                    if (item.key == settingValue) {
                        this._selection = $option;
                        $option.prop('selected', true);
                    }

                    $option.prependTo(this._$inputControl);
                }
            }

        };

    // A really lightweight plugin wrapper around the constructor, 
    //  preventing against multiple instantiations
    $.fn[pluginName] = function (/*Object*/options) {
        // summary:
        //      Create a new jQuery plugin from the given settings
        // options: [Object]
        //      The given settings that wanted to decorates the default settings of the current component
        // returns: [Object]
        //      The jQuery plugin object
        // tags:
        //      protected

        // Decorates the default settings by the given settings
        var basePrototype = $.fn['LiveMonitorListBoxItem'].prototype,
            concreteOptions = $.extend(true, {}, basePrototype.pluginOptions, pluginOptions, options),
            concreteDefinitions = $.extend(true, {}, basePrototype.pluginDefinitions, pluginDefinitions);

        // Create and then return a new jQuery plugin object
        return componentFactory.create(this, pluginName, concreteDefinitions, concreteOptions);
    };

});