﻿define([
// libs
    'jquery',
// live monitor
    'components/ComponentFactory',

    'components/Statistic/StatisticItem',

    'data/StatisticRepository'
],

function (
// libs
    $,
// live monitor
    componentFactory,

    statisticItem,

    statisticRepository
) {

    // =================================================================================================================================================
    // 'LiveMonitorClientsPerHourStatistic' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Button/LiveMonitorClientsPerHourStatistic'
    // summary:
    //      The jQuery plugin component for the clients per hour statistic
    // description:
    //      use:
    //          $(target).LiveMonitorClientsPerHourStatistic(options);
    //      options:
    //          resources [Object]
    //          autoCalculate [Boolean]
    // tags:
    //      public

    // Create the defaults once
    var pluginName = 'LiveMonitorClientsPerHourStatistic',
        pluginOptions = {
            // autoCalculate [Boolean] public
            //      Flag indicates that should or should not auto calculate clients per hour
            autoCalculate: false
        },
        pluginDefinitions = {

            // =================================================================================================================================================
            // Overrided functions
            // =================================================================================================================================================

            _getStatisticNumber: function () {
                // summary:
                //      Get the calculated statistic number
                // returns: [Integer]
                //      The statistic number
                // tags:
                //      protected, extensions

                return statisticRepository.getClientsPerHour(this.options.autoCalculate);
            }

            // =================================================================================================================================================
            // Private functions
            // =================================================================================================================================================

        };

    // A really lightweight plugin wrapper around the constructor, 
    //  preventing against multiple instantiations
    $.fn[pluginName] = function (/*Object*/options) {
        // summary:
        //      Create a new jQuery plugin from the given settings
        // options: [Object]
        //      The given settings that wanted to decorates the default settings of the current component
        // returns: [Object]
        //      The jQuery plugin object
        // tags:
        //      protected

        // Decorates the default settings by the given settings
        var basePrototype = $.fn['LiveMonitorStatistic'].prototype,
            baseOptions = basePrototype.pluginOptions,
            concreteOptions = $.extend(true, {}, baseOptions, pluginOptions, options),
            baseDefinitions = basePrototype.pluginDefinitions,
            concreteDefinitions = $.extend(true, {}, baseDefinitions, pluginDefinitions);

        // Create and then return a new jQuery plugin object
        return componentFactory.create(this, pluginName, concreteDefinitions, concreteOptions);
    };

});