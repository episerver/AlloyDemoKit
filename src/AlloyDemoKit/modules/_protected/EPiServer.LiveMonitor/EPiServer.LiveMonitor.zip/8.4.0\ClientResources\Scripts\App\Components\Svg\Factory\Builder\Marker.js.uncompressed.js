﻿define([
// libs
    'jquery',
// live monitor
    'utility'
],

function (
// libs
    $,
// live monitor
    utility
) {

    // =================================================================================================================================================
    // 'MarkerElementBuilder' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Svg/Factory/Builder/MarkerElementBuilder'
    // summary:
    //      The element builder class for 'marker' SVG object
    // description:
    //      Create the 'MARKER' SVG element
    // tags:
    //      public

    var MarkerElementBuilder = {

        elementName: 'marker',

        create: function (/*Object*/markerSettings, /*Array*/container, /*Function?*/recursiveCreate) {
            // summary:
            //      Create a MARKER svg object from the given settings and then append it to the given container
            // markerSettings: [Object]
            //      The given MARKER settings
            // container: [Array]
            //      The given container
            // recursiveCreate: [Function?]
            //      Indicated that should or should not create children recursively
            // tags:
            //      public

            if (!markerSettings) {
                return;
            }

            var markerList = container.selectAll(this.elementName)
                        .data(utility.getItemCollection(markerSettings))
                            .enter()
                    .append(this.elementName)
                        .attr('id', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.elementId;
                        })
                        .attr('class', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.classes;
                        })
                        .attr('viewBox', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.viewBox;
                        })
                        .attr('refX', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.refX;
                        })
                        .attr('refY', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.refY;
                        })
                        .attr('markerUnits', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.markerUnits;
                        })
                        .attr('markerWidth', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.markerWidth;
                        })
                        .attr('markerHeight', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.markerHeight;
                        })
                        .attr('orient', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.orient;
                        });

            $.isFunction(recursiveCreate) && recursiveCreate(markerSettings, /*container*/markerList);
        }

    };

    return MarkerElementBuilder;

});