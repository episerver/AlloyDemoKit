﻿define([
// libs
    'jquery',
    'd3',
// live monitor
    'utility',

    'components/Svg/Factory/Builder/Circle',
    'components/Svg/Factory/Builder/Defs',
    'components/Svg/Factory/Builder/Ellipse',
    'components/Svg/Factory/Builder/Group',
    'components/Svg/Factory/Builder/LinearGradient',
    'components/Svg/Factory/Builder/Marker',
    'components/Svg/Factory/Builder/Path',
    'components/Svg/Factory/Builder/Stop',
    'components/Svg/Factory/Builder/Text'
],

function (
// libs
    $,
    dataVisualizer,
// live monitor,
    utility,

    CircleElementBuilder,
    DefsElementBuilder,
    EllipseElementBuilder,
    GroupElementBuilder,
    LinearGradientElementBuilder,
    MarkerElementBuilder,
    PathElementBuilder,
    StopElementBuilder,
    TextElementBuilder
) {

    // =================================================================================================================================================
    // 'MarkupFactory' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Svg/Factory/MarkupFactory'
    // summary:
    //      The factory class for the application markup template
    // description:
    //      Public functions:
    //          init()
    //          create(/*Object*/settings, /*Array?*/container)
    //          registerBuilders(/*Array*/builderList)
    //          registerBuilder(/*Object*/builder)
    // tags:
    //      public

    var MarkupFactory = {

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        init: function () {
            // summary:
            //      Initialization for the current factory
            // tags:
            //      public

            this._setupDefaultBuilders();
        },

        create: function (/*Object*/settings, /*Array?*/container) {
            // summary:
            //      Create a new SVG element or append a created SVG element to the given container if any
            // settings: [Object]
            //      The given settings of a SVG object
            // container: [Array]
            //      The given container
            // tags:
            //      public

            return container ? this._append(settings, container) : this._create(settings);
        },

        registerBuilders: function (/*Array*/builderList) {
            // summary:
            //      Registers a collection of builder object to the current factory
            // builderList: [Array]
            //      The given collection of builder object that wants to register to the factory
            // tags:
            //      public

            if (!utility.isValidArray(builderList)) {
                return;
            }

            var self = this;
            $.each(builderList, function (index, item) {
                self.registerBuilder(item);
            });
        },

        registerBuilder: function (/*Object*/builder) {
            // summary:
            //      Registers the given builder to the current factory
            // builder: [Object]
            //      The given builder object that wants to register to the factory
            // tags:
            //      public

            if (!builder || !builder.elementName || !$.isFunction(builder.create)) {
                return;
            }

            !$.isArray(this._builders) && (this._builders = []);

            !utility.getItemFromCollection(this._builders, builder, this._filter) && this._builders.push(builder);
        },

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

        _setupDefaultBuilders: function () {
            // summary:
            //      Registers default builders for the current factory
            // tags:
            //      private

            this.registerBuilder(CircleElementBuilder);
            this.registerBuilder(DefsElementBuilder);
            this.registerBuilder(EllipseElementBuilder);
            this.registerBuilder(GroupElementBuilder);
            this.registerBuilder(LinearGradientElementBuilder);
            this.registerBuilder(MarkerElementBuilder);
            this.registerBuilder(PathElementBuilder);
            this.registerBuilder(StopElementBuilder);
            this.registerBuilder(TextElementBuilder);
        },

        _create: function (/*Object*/settings) {
            // summary:
            //      Create a SVG object from the given settings
            // settings: [Object]
            //      The given settings of a SVG object
            // returns: [Object]
            //      A SVG object
            // tags:
            //      private

            if (!settings || !settings.svg) {
                return;
            }

            var svg = dataVisualizer.select(document.createElement('p'))
                    .append('svg')
                        .attr('class', settings.svg.classes)
                        .attr('height', settings.svg.height)
                        .attr('width', settings.svg.width);

            this._append(settings.svg, svg);

            return svg.node();
        },

        _append: function (/*Object*/settings, /*Array*/container) {
            // summary:
            //      Create a SVG object from the given settings and then append it to the given container
            // settings: [Object]
            //      The given settings of a SVG object
            // container: [Array]
            //      The given container
            // tags:
            //      private

            var builder,
                self = this;
            $.each(settings, function (key, value) {
                if (typeof settings[key] === 'object') {
                    builder = utility.getItemFromCollection(self._builders, { elementName: key }, self._filter);
                    if (builder && $.isFunction(builder.create)) {
                        builder.create(/*settings*/value, container, utility.hitch(self, self._invokeCreateRecursive));
                    }
                }
            });
        },

        // =================================================================================================================================================
        // Utility functions
        // =================================================================================================================================================

        _filter: function (/*Object*/source, /*Object*/target) {
            // summary:
            //      Filters by comparing part(s) of the given source and target objects
            // source: [Object]
            //      The given source object
            // target: [Object]
            //      The given target object
            // returns: [Boolean]
            // tags:
            //      private

            return utility.filterBy('elementName', source, target);
        },

        _invokeCreateRecursive: function (/*Object*/settings, /*Array*/container) {
            // summary:
            //      Recursive create SVG object from the given settings and then append it to the given container
            // settings: [Object]
            //      The given SVG settings
            // container: [Array]
            //      The given container
            // tags:
            //      private

            var items = container[0];
            if (!utility.isValidArray(items)) {
                return;
            }

            var self = this;
            $.each(items, function (index, item) {
                self._append(utility.isValidArray(settings) ? settings[index] : settings, dataVisualizer.select(item));
            });
        }
    };

    // Initialization for the MarkupFactory
    MarkupFactory.init();

    return MarkupFactory;

});