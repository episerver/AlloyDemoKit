﻿define([
// libs
    'jquery',
    'signalR.hubs',
// live monitor
    'utility'
],

function (
// libs
    $,
    hubs,
// live monitor
    utility
) {

    // =================================================================================================================================================
    // 'LiveMonitorCommunicator' class information
    // =================================================================================================================================================
    // module:
    //      'App/Services/Communicator'
    // summary:
    //      The communicator class for the application (between clients and server)
    //      It provides:
    //          notifier: to broadcasts all changes to clients
    //          sender: to requests and then receives data from server
    //      It will:
    //          Notifies all changes in server side for the target clients
    //          Abstract requests from client to server to get indicated data
    // description:
    //      notifier: [Object]
    //          Public functions:
    //              broadcastVisitorsData(/*Array*/visitorsData)
    //      sender: [Object]
    //          Public functions:
    //              getPreloadedContent(/*Object*/filterConditions)
    //                  filterConditions: [Object]
    //                      contentId: [String]
    //                      languageId: [String]
    //
    //              getChildContents(/*Object*/filterConditions)
    //                  filterConditions: [Object]
    //                      parentId: [String]
    //                      languageId: [String]
    //
    //              getCurrentStatistics(/*Object*/filterConditions)
    //                  filterConditions: [Object]
    //                      languageId: [String]
    //
    //              getSiteTransfers(/*Object*/filterConditions)
    //                  filterConditions: [Object]
    //                      languageId: [String]
    //
    //              getSiteHighways(/*Object*/filterConditions)
    //                  filterConditions: [Object]
    //                      languageId: [String]
    //
    //              getVisitorsData(/*Object*/filterConditions)
    //                  filterConditions: [Object]
    //                      languageId: [String]
    //
    // tags:
    //      public

    var LiveMonitorCommunicator = {

        // key: [String] public
        //      The unique key that used to register to the controller
        //      The controller used this key to identifies each registered communicator
        key: 'LiveMonitorCommunicator',

        // name: [String] public
        //      The communicator name that used to register to the controller
        //      The application used this name to display
        name: 'Live Monitor Communicator',

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        init: function () {
            // summary:
            //      Initialization settings for the communicator
            // tags:
            //      public

            this.notifier.init();
        },

        connectionReady: function () {
            // summary:
            //      Ensure that the given SignalR connection is ready to use
            // returns: [$.Deferred]
            //      The jQuery Deferred object
            // tags:
            //      public

            var settings = {
                contentType: 'application/json; charset=UTF-8'
            };

            return $.connection.hub.start(settings).promise();
        },

        // =================================================================================================================================================
        // Notifier class
        // =================================================================================================================================================

        notifier: {
            // summary:
            //      Broadcast client(s) about any change on the server side
            // tags:
            //      class, public

            _visitor: $.connection.visitorTrackerHub.client,

            // =================================================================================================================================================
            // Public functions
            // =================================================================================================================================================

            init: function () {
                // summary:
                //      Initialization settings for the notifier
                // tags:
                //      public

                this._setupDefaultNotifiers();
            },

            broadcastVisitorsData: function (/*[Object] visitorsData*/) {
                // summary:
                //      Broadcast visitors data for all clients
                // visitorsData: [Object]
                //      Object's properties:
                //          onlineVisitors: [Array]
                //              The collection of the online visitor object
                //          historyVisitors: [Array]
                //              The collection of the offline visitor object
                // tags:
                //      public

            },

            // =================================================================================================================================================
            // Private functions
            // =================================================================================================================================================

            _setupDefaultNotifiers: function () {
                // summary:
                //      Setup default notifiers for the current communicator
                // tags:
                //      private

                this._visitor.broadcastVisitorsData = utility.hitch(this, function (visitorsData) {
                    this.broadcastVisitorsData(visitorsData);
                });
            }
        },

        // =================================================================================================================================================
        // Sender class
        // =================================================================================================================================================

        sender: {
            // summary:
            //      Send request to the server side to get the indicated data
            // tags:
            //      class, public

            trace: $.connection.traceHub.server,

            // =================================================================================================================================================
            // Public functions
            // =================================================================================================================================================

            init: function () {
                // summary:
                //      Initialization settings for the notifier
                // tags:
                //      public

                this._setupDefaultSenders();
            },

            // =================================================================================================================================================
            // Private functions
            // =================================================================================================================================================

            _setupDefaultSenders: function () {
                // summary:
                //      Setup default notifiers for the current communicator
                // tags:
                //      private
            }
        }
    };

    // Initialization settings
    LiveMonitorCommunicator.init();

    return LiveMonitorCommunicator;

});