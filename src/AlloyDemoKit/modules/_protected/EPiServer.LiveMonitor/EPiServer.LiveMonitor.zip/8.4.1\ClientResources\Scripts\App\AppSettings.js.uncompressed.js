﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'data/SettingRepository'
],

function (
// libs
    $,
// live monitor
    utility,

    settingRepository
) {

    // =================================================================================================================================================
    // 'AppSettings' class information
    // =================================================================================================================================================
    // module:
    //      'App/AppSettings'
    // summary:
    //      An application settings class
    // description:
    //      An example of the stored settings:
    //          var applicationSettings = {
    //              monitoringTarget: {
    //                  value: '1',
    //                  isVisible: false
    //              },
    //              preloadedLevel: {
    //                  value: '3',
    //                  isVisible: true
    //              },
    //              languageId: {
    //                  value: 'en',
    //                  isVisible: true
    //              },
    //              expandCollapsiblePanel: {
    //                  value: 'false',
    //                  isVisible: true,
    //                  registeredValueList: [
    //                      {
    //                          key: 'true',
    //                          name: 'Yes'
    //                      },
    //                      {
    //                          key: 'false',
    //                          name: 'No'
    //                      }
    //                  ]
    //              },
    //              communicator: {
    //                  value: 'LiveMonitorCommunicator',
    //                  isVisible: true,
    //                  registeredValueList: [
    //                      {
    //                          key: 'LiveMonitorCommunicator',
    //                          name: 'Live Monitor Communicator'
    //                      },
    //                      {
    //                          key: 'DemoCommunicator',
    //                          name: 'Demo Communicator'
    //                      }
    //                  ]
    //              },
    //              animation: {
    //                  value: 'AnimationPattern1',
    //                  isVisible: true,
    //                  registeredValueList: [
    //                      {
    //                          key: 'AnimationPattern1',
    //                          name: 'Animation Pattern 1'
    //                      },
    //                      {
    //                          key: 'AnimationPattern2',
    //                          name: 'Animation Pattern 2'
    //                      }
    //                  ]
    //              }
    //          };
    // tags:
    //      public

    var AppSettings = {

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        init: function () {
            // summary:
            //      Initialization for the current controller
            // tags:
            //      public

            this._config = LiveMonitorConfig;
            this._repository = settingRepository;
        },

        getSettingKeyList: function () {
            // summary:
            //      Get all application registered settings
            // returns: [Array]
            //      The registered application settings key collection
            // tags:
            //      public

            var appSettings = this._repository.getAppSettings();
            if (!appSettings) {
                return;
            }

            var settingKeyList = [];
            $.each(appSettings, function (key, setting) {
                if (setting && setting.isVisible) {
                    settingKeyList.push(key);
                }
            });

            return settingKeyList;
        },

        getSettingValues: function (/*String*/settingKey) {
            // summary:
            //      Get setting value by the given setting key
            // settingKey: [String]
            //      The given setting key
            // returns: [Object]
            //      The saved setting value collection
            // tags:
            //      public

            var setting = this._repository.getSetting(settingKey);
            if (setting && setting.registeredValueList) {
                return setting.registeredValueList;
            }
        },

        getSetting: function (/*String*/settingKey) {
            // summary:
            //      Get setting value by the given setting key
            // settingKey: [String]
            //      The given setting key
            // returns: [Object]
            //      The saved setting value
            // tags:
            //      public

            var setting = this._repository.getSetting(settingKey);
            if (setting && setting.value) {
                return setting.value;
            }
        },

        registerSetting: function (/*Object*/setting) {
            // summary:
            //      Register the given setting to the application settings
            // setting: [Object]
            //      The given setting information in key/value pair format
            //          settingKey: [String]
            //          settingValue: [Object]
            // tags:
            //      public

            this._repository.saveSetting(setting);
        },

        clearSetting: function (/*String*/settingKey) {
            // summary:
            //      Clear the registered setting value by the given setting key
            // settingKey: [String]
            //      The given setting key
            // tags:
            //      public

            if (!settingKey) {
                return;
            }

            this._repository.saveSetting({
                settingKey: settingKey,
                value: ''
            });
        }

    };

    AppSettings.init();

    return AppSettings;

});