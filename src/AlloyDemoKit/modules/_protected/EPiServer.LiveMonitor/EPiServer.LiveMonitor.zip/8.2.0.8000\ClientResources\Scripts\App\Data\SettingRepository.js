﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'data/PersistenceCache'
],

function (
// libs
    $,
// live monitor
    utility,

    persistenceCache
) {

    // =================================================================================================================================================
    // 'SettingRepository' class information
    // =================================================================================================================================================
    // module:
    //      'App/Data/SettingRepository'
    // summary:
    //      The repository for application settings
    // description:
    //      Public functions:
    //          getAppSettings()
    //          getSetting(/*String*/settingKey)
    //          saveSeting(/*Object*/setting)
    // tags:
    //      public

    var SettingRepository = {

        // _storageKey: [String] private
        //      The application settings key
        _storageKey: 'livemonitor-application-settings',

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        getAppSettings: function () {
            // summary:
            //      Get application settings from the application storage in JSON format
            // returns: [Object]
            //      The JSON object
            // tags:
            //      public

            return this._storage.getAllData();
        },

        getSetting: function (/*String*/settingKey) {
            // summary:
            //      Get value from store by the given setting key
            // settingKey: [String]
            //      The given setting key
            // returns: [Object]
            //      The value that got from the store by the given key
            // tags:
            //      private

            var appSettings;
            if (!settingKey || !(appSettings = this.getAppSettings())) {
                return;
            }

            return appSettings.hasOwnProperty(settingKey) && appSettings[settingKey];
        },

        saveSetting: function (/*Object*/setting) {
            // summary:
            //      Save the given setting object to the store
            // tags:
            //      private

            // Verifies the given setting object is valid format or not
            if (!setting || !setting.settingKey) {
                return;
            }

            var appSettings = this.getAppSettings() || {},
                conditions = {
                    validRegisterValue: setting.registerValue
                        && setting.registerValue.key
                        && setting.registerValue.name,
                    validRegisterValueList: utility.isValidArray(setting.registerValueList)
                };

            appSettings = (registeredSetting = appSettings[setting.settingKey])
                ? this._getUpdatedSettings(appSettings, registeredSetting, setting, conditions)
                : this._getNewSettings(appSettings, setting, conditions);

            // Save setting object
            this._storage.saveData(appSettings);
        },

        // =================================================================================================================================================
        // Overrided functions
        // =================================================================================================================================================

        _onInit: function () {
            // summary:
            //      Initialization settings
            // tags:
            //      protected, extensions

            this._config = LiveMonitorConfig;

            this._setupDefaultSettings();
        },

        _onResetToDefault: function () {
            // summary:
            //      Restore default application settings
            // tags:
            //      protected, extensions

            this._setupDefaultSettings();
        },

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

        // =================================================================================================================================================
        // Default settings functions
        // =================================================================================================================================================

        _setupDefaultSettings: function () {
            // summary:
            //      Register default settings to the application settings
            // tags:
            //      private

            var appSettings = this.getAppSettings();

            this._setupMonitoringTargetSetting();
            this._setupCommunicatorSetting(appSettings);
            this._setupLanguageSetting(appSettings);
            this._setupPreloadedLevelSetting(appSettings);
            this._setupExpandVisitorsPanelSetting(appSettings);
            this._setupThemeSetting(appSettings);
            this._setupAnimationSetting(appSettings);
        },

        _setupMonitoringTargetSetting: function () {
            // summary:
            //      Setup settings for monitoring target
            // tags:
            //      private

            // targetContentId: [String]
            //      The default setting for the target content identification
            this.saveSetting({
                settingKey: 'monitoringTarget',
                value: this._config && this._config.monitoringTarget,
                isVisible: false
            });
        },

        _setupCommunicatorSetting: function (/*Object*/appSettings) {
            // summary:
            //      Setup settings for monitoring target
            // appSettings: [Object]
            //      The given application settings object
            // tags:
            //      private

            // communicator: [String]
            //      The default setting for the communicator
            if (!appSettings || !appSettings.communicator) {
                this.saveSetting({
                    settingKey: 'communicator',
                    value: 'LiveMonitorCommunicator',
                    isVisible: false
                });
            }
        },

        _setupLanguageSetting: function (/*Object*/appSettings) {
            // summary:
            //      Setup settings for monitoring target
            // appSettings: [Object]
            //      The given application settings object
            // tags:
            //      private

            var languageSetting = this._config && this._config.language,
                hasDefault = !!(languageSetting && languageSetting.default),
                defaultLanguage = hasDefault
                    ? languageSetting.default
                    : 'en';

            // languageId: [String]
            //      The default setting for the language id
            if (!appSettings || !appSettings.languageId) {
                this.saveSetting({
                    settingKey: 'languageId',
                    value: defaultLanguage,
                    isVisible: true
                });
            }
        },

        _setupPreloadedLevelSetting: function (/*Object*/appSettings) {
            // summary:
            //      Setup settings for monitoring target
            // appSettings: [Object]
            //      The given application settings object
            // tags:
            //      private

            // preloadedLevel: [Integer]
            //      The default setting for the preloaded level of the tree
            if (!appSettings || !appSettings.preloadedLevel) {
                // Register preloaded level in range (1-5)
                var registerValueList = [],
                    number;
                for (var i = 0; i < 5; i++) {
                    number = i + 1;
                    registerValueList.push({
                        key: number,
                        name: number
                    });
                }

                this.saveSetting({
                    settingKey: 'preloadedLevel',
                    value: 3,
                    registerValueList: registerValueList,
                    isVisible: true
                });
            }
        },

        _setupExpandVisitorsPanelSetting: function (/*Object*/appSettings) {
            // summary:
            //      Setup settings for monitoring target
            // appSettings: [Object])
            //      The given application settings object
            // tags:
            //      private

            // expandVisitorsPanel: [Boolean]
            //      The default setting to expand|collapse the visitors panel
            if (!appSettings || !appSettings.expandCollapsiblePanel) {
                this.saveSetting({
                    settingKey: 'expandCollapsiblePanel',
                    value: 'false',
                    isVisible: true,
                    registerValueList: [
                        {
                            key: 'true',
                            name: 'Yes'
                        },
                        {
                            key: 'false',
                            name: 'No'
                        }
                    ]
                });
            }
        },

        _setupThemeSetting: function (/*Object*/appSettings) {
            // summary:
            //      Setup settings for monitoring target
            // appSettings: [Object]
            //      The given application settings object
            // tags:
            //      private

            var themeSetting = this._config && this._config.theme,
                hasDefault = !!(themeSetting && themeSetting.default);

            // NOTE: Always overrides this setting
            // themesRootPath: [String]
            //      The default setting for the themes root path
            this.saveSetting({
                settingKey: 'themesRootPath',
                value: themeSetting && themeSetting.rootPath,
                isVisible: false
            });

            // theme: [String]
            //      The default setting for the theme
            if (!appSettings || !appSettings.theme) {
                var defaultTheme = hasDefault
                    ? themeSetting.default
                    : 'Dark';

                this.saveSetting({
                    settingKey: 'theme',
                    value: defaultTheme,
                    // Do not want this setting show as text (editable), so that register a value list for it
                    registerValueList: [
                        {
                            key: defaultTheme,
                            name: defaultTheme
                        }
                    ],
                    isVisible: true
                });
            }
        },

        _setupAnimationSetting: function (/*Object*/appSettings) {
            // summary:
            //      Setup settings for animation
            // appSettings: [Object]
            //      The given application settings object
            // tags:
            //      private

            // animation: [String]
            //      The default setting for the animation
            if (!appSettings || !appSettings.animation) {
                var animationSetting = this._config && this._config.animation,
                    hasDefault = !!(animationSetting && animationSetting.default),
                    defaultAnimation = hasDefault
                        ? animationSetting.default
                        : 'Simple';

                this.saveSetting({
                    settingKey: 'animation',
                    value: defaultAnimation,
                    isVisible: true
                });
            }
        },

        // =================================================================================================================================================
        // Store functions
        // =================================================================================================================================================

        _getNewSettings: function (/*Object*/appSettings, /*Object*/newSetting, /*Object*/createConditions) {
            // summary:
            //      Create a new setting and then store it to the application settings
            // appSettings: [Object]
            //      The given application settings object
            // newSetting: [Object]
            //      The given new setting object that want to register to the application settings
            // createConditions: [Object]
            //  Valid conditions to create a new setting:
            //      validRegisterValue: [Boolean]
            //      validRegisterValueList: [Boolean]
            // tags:
            //      private

            appSettings[newSetting.settingKey] = {
                value: newSetting.value,
                isVisible: newSetting.isVisible
            };

            if (createConditions && createConditions.validRegisterValue) {
                appSettings[newSetting.settingKey].registeredValueList = [newSetting.registerValue];
            }

            if (createConditions && createConditions.validRegisterValueList) {
                appSettings[newSetting.settingKey].registeredValueList = newSetting.registerValueList;
            }

            return appSettings;
        },

        _getUpdatedSettings: function (/*Object*/appSettings, /*Object*/registeredSetting, /*Object*/updateSetting, /*Object*/updateConditions) {
            // summary:
            //      Update an existing setting in the application settings
            // appSettings: [Object]
            //      The given application settings object
            // registeredSetting: [Object]
            //      The given registered settings of the application settings
            // updateSetting: [Object]
            //      The given updated setting object that want to overrides the existing in the application settings
            // updateConditions: [Object]
            //  Valid conditions to update an existing setting:
            //      validRegisterValue: [Boolean]
            //      validRegisterValueList: [Boolean]
            // tags:
            //      private

            if (updateSetting.value != null) {
                registeredSetting.value = updateSetting.value;
            }

            if (updateSetting.isVisible != null) {
                registeredSetting.isVisible = updateSetting.isVisible;
            }

            if (updateConditions && updateConditions.validRegisterValue) {
                if (!utility.isValidArray(registeredSetting.registeredValueList) || updateSetting.mode === 'clean') {
                    registeredSetting.registeredValueList = [];
                }

                if (utility.inCollection(updateSetting.registerValue, registeredSetting.registeredValueList) === -1) {
                    registeredSetting.registeredValueList.unshift(updateSetting.registerValue);
                }
            }

            if (updateConditions && updateConditions.validRegisterValueList) {
                if (!utility.isValidArray(registeredSetting.registeredValueList) || updateSetting.mode === 'clean') {
                    registeredSetting.registeredValueList = [];
                }

                var registerValueList = updateSetting.registerValueList,
                    totalItems = registerValueList.length,
                    item;

                while (totalItems--) {
                    item = registerValueList[totalItems];
                    if (!item) {
                        continue;
                    }

                    if (utility.inCollection(item, registeredSetting.registeredValueList) !== -1) {
                        continue;
                    }

                    registeredSetting.registeredValueList.unshift(item);
                }
            }

            appSettings[updateSetting.settingKey] = registeredSetting;

            return appSettings;
        }

    };

    var settingRepository = $.extend(true, {}, persistenceCache, SettingRepository);
    settingRepository.init();

    return settingRepository;

});