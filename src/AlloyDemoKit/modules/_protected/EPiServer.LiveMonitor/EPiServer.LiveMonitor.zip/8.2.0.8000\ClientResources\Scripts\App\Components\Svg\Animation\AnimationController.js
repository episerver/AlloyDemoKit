﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'app/AppSettings'
],

function (
// libs
    $,
// live monitor
    utility,

    appSettings
) {

    // =================================================================================================================================================
    // 'AnimationController' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Svg/Animation/AnimationController'
    // summary:
    //      The controller class for all the application animations
    // description:
    //      Public functions:
    //          init()
    //          load(/*String*/animationKey, /*Object*/marker, /*Integer*/delay)
    //          registerAnimations(/*Array*/animationList)
    //          registerAnimation(/*Object*/animation)
    // tags:
    //      public

    // =================================================================================================================================================
    // AnimationController class
    // =================================================================================================================================================

    var AnimationController = {

        // _filterName: [String] private
        //      The filter function name
        _filterName: 'key',

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        init: function () {
            // summary:
            //      Initialization for the current controller
            // tags:
            //      public

            this._appSettings = appSettings;
        },

        load: function (/*String*/animationKey, /*Object*/marker, /*Integer*/delay) {
            // summary:
            //      Bind the indicated animation to the given marker object
            // animationKey: [String]
            //      The given animation key that used to translates to the correct animation animation object
            // marker: [Object]
            //      The given object that wanted to bind the indicated animation
            // delay: [Integer]
            //      The given delay time
            // tags:
            //      public

            if (!marker || !animationKey) {
                return;
            }

            var filterConditions = {
                key: animationKey
            };

            var animation = utility.getItemFromCollection(this._animations, filterConditions, this._filterName);
            (animation && $.isFunction(animation.apply)) && animation.apply(marker, delay);
        },

        registerAnimations: function (/*Array*/animationList) {
            // summary:
            //      Registers a collection of builder object to the current controller
            // builderList: [Array]
            //      The given collection of builder object that wants to register to the controller
            // tags:
            //      public

            if (!utility.isValidArray(animationList)) {
                return;
            }

            var totalItems = animationList.length;
            while (totalItems--) {
                this.registerAnimation(animationList[totalItems]);
            }
        },

        registerAnimation: function (/*Object*/animation) {
            // summary:
            //      Registers the given animation to the current controller
            // animation: [Object]
            //      The given animation object that wants to register to the controller
            // tags:
            //      public

            if (!animation || !animation.key || !animation.name || !$.isFunction(animation.apply)) {
                return;
            }

            !$.isArray(this._animations) && (this._animations = []);

            if (!utility.getItemFromCollection(this._animations, animation, this._filterName)) {
                this._animations.unshift(animation);

                // Register animation name to the application settings
                this._appSettings.registerSetting({
                    settingKey: 'animation',
                    registerValue: {
                        key: animation.key,
                        name: animation.name
                    }
                });
            }
        }

    };

    // Initialization for the AnimationController
    AnimationController.init();

    return AnimationController;

});