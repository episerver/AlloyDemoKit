﻿define([
// libs
    'jquery',
    'd3'
],

function (
// libs
    $,
    dataVisualizer
) {

    // =================================================================================================================================================
    // AppUtility class
    // =================================================================================================================================================

    var AppUtility = {
        // =================================================================================================================================================
        // Common functions
        // =================================================================================================================================================

        hitch: function (/*Object*/scope, /*Function*/fn) {
            // summary:
            //      It returns a function that will execute a given function in a given scope.
            //      This function allows you to control how a function executes, particularly in asynchronous operations.
            // scope: [Object]
            //      The given scope
            // fn: [Function]
            //      The given function
            // returns: [Function]
            //      The given function that will execute a given function in a given scope
            // tags:
            //      public

            return function () {
                return fn.apply(scope, arguments);
            }
        },

        convertArrayToObject: function (/*Array*/inputArray) {
            // summary:
            //      Convert the given instance of Array to an object
            // inputArray: [Array]
            //      The given instance of Array that want to convert to an object
            // returns: [Object]
            //      The converted object
            // tags:
            //      public

            return $.extend({}, inputArray);
        },

        convertObjectToArray: function (/*Object*/inputObject) {
            // summary:
            //      Convert the given object to an Array
            // inputObject: [Object]
            //      The given object that want to convert to an Array
            // returns: [Array]
            //      The converted Array
            // tags:
            //      public

            if (!inputObject) {
                return;
            }

            return $.map(inputObject, function (item, index) {
                return [item];
            });
        },

        inCollection: function (/*Object*/value, /*Array*/collection) {
            // summary:
            //      Verifies the given value object is contains in the given collection
            // value: [Object]
            //      The given value object that want to find in the given collection
            // collection: [Array]
            //      The given collection to verifies
            // returns: [Integer]
            //      Not found: -1
            //      Found: The index in the given collection
            // tags:
            //      public

            if (!value || !this.isValidArray(collection)) {
                return -1;
            }

            var totalItems = collection.length;

            while (totalItems--) {
                if (this.isEquals(value, collection[totalItems])) {
                    return totalItems;
                }
            }

            return -1;
        },

        isEquals: function (/*Object*/object1, /*Object*/object2) {
            // summary:
            //      Compare the given two objects.
            //      Compares objects without digging into prototypes, then compares properties' projections recursively, and also compares constructors.
            // remarks:
            //      Known issues (well, they have very low priority, probably you'll never notice them):
            //          objects with different prototype structure but same projection
            //          functions may have identical text but refer to different closures
            // object1: [Object]
            //      The given first object to compare
            // object2: [Object]
            //      The given second object to compare
            // returns: [Boolean]
            //      The given two objects are equals or not
            // tags:
            //      public

            var leftChain, rightChain;

            function compare2Objects(x, y) {
                var p;

                // remember that NaN === NaN returns false
                // and isNaN(undefined) returns true
                if (isNaN(x) && isNaN(y) && typeof x === 'number' && typeof y === 'number') {
                    return true;
                }

                // Compare primitives and functions.
                // Check if both arguments link to the same object.
                // Especially useful on step when comparing prototypes
                if (x === y) {
                    return true;
                }

                // Works in case when functions are created in constructor.
                // Comparing dates is a common scenario. Another built-ins?
                // We can even handle functions passed across iframes
                if ((typeof x === 'function' && typeof y === 'function') ||
                   (x instanceof Date && y instanceof Date) ||
                   (x instanceof RegExp && y instanceof RegExp) ||
                   (x instanceof String && y instanceof String) ||
                   (x instanceof Number && y instanceof Number)) {
                    return x.toString() === y.toString();
                }

                // At last checking prototypes as good a we can
                if (!(x instanceof Object && y instanceof Object)) {
                    return false;
                }

                if (x.isPrototypeOf(y) || y.isPrototypeOf(x)) {
                    return false;
                }

                if (x.constructor !== y.constructor) {
                    return false;
                }

                if (x.prototype !== y.prototype) {
                    return false;
                }

                // check for infinitive linking loops
                if (leftChain.indexOf(x) > -1 || rightChain.indexOf(y) > -1) {
                    return false;
                }

                // Quick checking of one object beeing a subset of another.
                // todo: cache the structure of arguments[0] for performance
                for (p in y) {
                    if (y.hasOwnProperty(p) !== x.hasOwnProperty(p)) {
                        return false;
                    } else if (typeof y[p] !== typeof x[p]) {
                        return false;
                    }
                }

                for (p in x) {
                    if (y.hasOwnProperty(p) !== x.hasOwnProperty(p)) {
                        return false;
                    } else if (typeof y[p] !== typeof x[p]) {
                        return false;
                    }

                    switch (typeof (x[p])) {
                        case 'object':
                        case 'function':
                            leftChain.push(x);
                            rightChain.push(y);

                            if (!compare2Objects(x[p], y[p])) {
                                return false;
                            }

                            leftChain.pop();
                            rightChain.pop();

                            break;

                        default:
                            if (x[p] !== y[p]) {
                                return false;
                            }

                            break;
                    }
                }

                return true;
            }

            if (arguments.length < 1) {
                // throw "Need two or more arguments to compare";
                return true;
            }

            for (var i = 1, l = arguments.length; i < l; i++) {

                leftChain = []; // TODO: this can be cached
                rightChain = [];

                if (!compare2Objects(arguments[0], arguments[i])) {
                    return false;
                }
            }

            return true;
        },

        isValidArray: function (/*Object*/data) {
            // summary:
            //      Verify the given object is an instance of Array or not
            // data: [Object]
            //      The given object that want to verify
            // tags:
            //      public

            return $.isArray(data) && data.length > 0;
        },

        isHiding: function (/*Object*/element) {
            // summary:
            //      Verifies the given element is showing or not
            // element: [Object]
            //      The given object that is an instance of jQuery selector object
            // returns: [Boolean]
            // tags:
            //      public

            return element && element.css('display') === 'none';
        },

        formatTemplateString: function (/*String*/templateString, /*Object*/data) {
            // summary:
            //      Apply the given data to the given template string
            // templateString: [String]
            //      The given template string
            // data: [Object]
            //      The given data source object that used to replace format pattern in the string
            // returns: [String]
            //      The formated string
            // tags:
            //      public

            if (!templateString || !data) {
                return;
            }

            var matches = templateString.match(new RegExp('\\{\\w+(\\.\\w+)*\\}', 'gim')),
                key;

            if (!this.isValidArray(matches)) {
                return templateString;
            }

            var totalItems = matches.length,
                item,
                value;

            while (totalItems--) {
                item = matches[totalItems];
                if (!item) {
                    continue;
                }

                // Get string without curly brackets '{}'
                key = item.substring(1, item.length - 1);
                value = this.escapeHtml(this.getValueFromKey(data, key) || '');

                templateString = templateString.replace(new RegExp(item, 'gim'), value);
            }

            return templateString;
        },

        escapeHtml: function (/*String*/rawHtmlValue) {
            // summary:
            //      Escapes HTML from the given HTML string
            // rawHtmlValue: [String]
            //      The given HTML string
            // returns: [String]
            //      The escaped HTML string
            // tags:
            //      public

            if ($.type(rawHtmlValue) !== 'string') {
                return rawHtmlValue;
            }

            return rawHtmlValue
                .replace(/&/gim, '&amp;')
                .replace(/"/gim, '&quot;')
                .replace(/'/gim, '&#39;')
                .replace(/</gim, '&lt;')
                .replace(/>/gim, '&gt;');
        },

        cloneObject: function (/*Object*/source) {
            // summary:
            //      Clone the given source object
            // source: [Object]
            //      The given source object
            // returns: [Object]
            //      The cloned object
            // tags:
            //      public

            return JSON.parse(JSON.stringify(source));
        },

        setComponentsState: function (/*Array*/components, /*String*/state) {
            // summary:
            //      Set the given state for all the given components
            // components: [Array]
            //      The given collection of the component
            // state: [String]
            //      The indicate state that want to set to the given components
            // tags:
            //      public

            if ($.type(state) !== 'string' || !this.isValidArray(components)) {
                return;
            }

            var totalItems = components.length,
                item,
                instance;

            while (totalItems--) {
                item = components[totalItems];
                if (!item) {
                    continue;
                }

                instance = this.getInstance(item);
                if (!instance || !$.isFunction(instance.setState)) {
                    continue;
                }

                instance.setState(state);
            }
        },

        getURLParameter: function (/*String*/param) {
            // summary:
            //      Gets URL param value from the given URL param key.
            // param: [String]
            //      The URL param key.
            // returns: [String]
            //      URL param value.
            // tags:
            //      public

            var url = window.location.search.substring(1),
                urlVariables = url.split('&'),
                index = 0,
                totalItems = urlVariables.length,
                paramName;

            for (; index < totalItems; index++) {
                paramName = urlVariables[index].split('=');
                if (paramName[0] == param) {
                    return paramName[1];
                }
            }
        },

        getJSONObject: function (/*Object|String*/inputValue) {
            // summary:
            //      Gets JSON object from the given input value
            // inputValue: [Object|String]
            //      The given object that want to convert to JSON object if applicable
            // returns: [Object]
            //      JSON object
            // tags:
            //      public
            return typeof inputValue === 'string' ? $.parseJSON(inputValue) : inputValue;
        },

        getInstance: function (/*Object|String*/plugin, /*String?*/pluginName) {
            // summary:
            //      Get the instance of the given plugin object by the given name
            // plugin: [Object|String]
            //      The given jQuery plugin object
            // pluginName: [String?] OPTIONAL
            //      The given jQuery plugin name
            // returns: [Object]
            //      The instance of the jQuery plugin object
            // tags:
            //      public

            var pluginObject = $.type(plugin) === 'string' ? $(plugin) : plugin;
            if (pluginObject && pluginObject.length === 0) {
                return;
            }

            !pluginName && (pluginName = $.data(pluginObject[0], 'plugin-name'));
            if (!pluginName) {
                return;
            }

            return pluginObject.data(pluginName);
        },

        getItemCollection: function (/*Object*/data) {
            // summary:
            //      Change the given data object to an instance of Array object
            // data: [Object]
            //      The given data
            // returns: [Array]
            //      An instance of Array
            // tags:
            //      public

            return this.isValidArray(data) ? data : [data];
        },

        getItemFromCollection: function (/*Array*/collectionSource, /*Object*/filterConditions, /*Function*/filter) {
            // summary:
            //      Get an item object from the given array by the given filtering conditions
            // collectionSource: [Array]
            //      The given source collection
            // filterConditions: [Object]
            //      The given filtering conditions
            // filter: [Function]
            //      The given call back filtering function
            // returns: [Object]
            //      The filtered item object
            // tags:
            //      public

            if (!this.isValidArray(collectionSource)) {
                return;
            }

            return collectionSource.filter(this.hitch(this, function (/*Object*/item) {
                if ($.type(filter) === 'function') {
                    return filter(item, filterConditions);
                } else {
                    switch (filter) {
                        case 'contentId':
                            return this.filterByContentId(item, filterConditions);
                        case 'key':
                            return this.filterByKey(item, filterConditions);
                        default:
                            return;
                    }
                }
            }))[0];
        },

        getValueFromKey: function (/*Object*/source, /*String*/key) {
            // summary:
            //      Get value from the given source object and its key
            // source: [Object]
            //      The given source object
            // key: [String]
            //      The given key
            // returns: [Object]
            //      The value object from the given key
            // tags:
            //      public

            if (key.indexOf('.') === -1) {
                return source[key];
            }

            var parts = key.split('.'),
                target = source;
            $.each(parts, function (index, item) {
                if ($.type(target) === 'object' && target.hasOwnProperty(item)) {
                    target = target[item];
                }
            });

            return target;
        },

        getCombinedKey: function (/*Array*/keyParts, /*String?*/separator) {
            // summary:
            //      Build a combination key from the given collection of text
            // keyParts: [Array]
            //      The given collection of text that used to build the combination key
            // separator: [String?]
            //      The given separator string
            // returns: [String]
            //      The combined key string
            // tags:
            //      public

            if (!this.isValidArray(keyParts)) {
                return;
            }

            return keyParts.join(separator || '').replace(/-/gim, '').replace(/\./gim, '');
        },

        getCollectionFromObject: function (/*Object*/inputObject) {
            // summary:
            //      Get arguments array from the given arguments object
            // inputObject: [Object]
            //      The given arguments object
            // returns: [Array]
            // tags:
            //      public

            if (!inputObject) {
                return;
            }

            return Array.prototype.slice.call(inputObject, 0);
        },

        getRandomNumber: function (/*Integer*/min, /*Integer*/max) {
            // summary:
            //      Get a random number from the given range [min-max]
            // min: [Integer]
            //      The minimum number in range
            // max: [Integer]
            //      The maximum number in range
            // returns: [Integer]
            //      The random integer that got from the given range
            // tags:
            //      public

            return Math.floor(Math.random() * (max - min + 1) + min);
        },

        getOuterContent: function (/*Object*/element) {
            // summary:
            //      Get outer DOM content in string format of the given element
            // element: [Object]
            //      The given DOM element
            // returns: [String]
            //      The outer content string of the given element
            // tags:
            //      public

            if (!element) {
                return;
            }

            return $(element).wrap('<p></p>').parent().html();
        },

        buildPath: function (/*Array*/pathParts) {
            // summary:
            //      Build path from the given collection of path's part
            // pathParts: [Array]
            //      The given collection of path's part
            // tags:
            //      public

            return pathParts.join('/').replace('//', '/');
        },

        toggleVisibility: function (/*Array*/collection, /*Boolean*/visible) {
            // summary:
            //      Toggle the visibility for the given collection of the component
            // collection: [Array]
            //      The given collection of the component that want to toggle its visibility
            // visible: [Boolean]
            //      The flag indicate the visibility of the component
            // tags:
            //      public

            if (!this.isValidArray(collection)) {
                return;
            }

            var totalItems = collection.length,
                item;

            while (totalItems--) {
                item = collection[totalItems];

                (item && $.isFunction(item.toggleVisibility))
                    && item.toggleVisibility(visible);
            }
        },

        filterByContentId: function (/*Object*/source, /*Object*/target) {
            // summary:
            //      Filters by comparing part(s) of the given source and target objects
            // source: [Object]
            //      The given source object
            // target: [Object]
            //      The given target object
            // returns: [Boolean]
            // tags:
            //      public

            return this.filterBy('contentId', source, target);
        },

        filterByKey: function (/*Object*/source, /*Object*/target) {
            // summary:
            //      Filters by comparing part(s) of the given source and target objects
            // source: [Object]
            //      The given source object
            // target: [Object]
            //      The given target object
            // returns: [Boolean]
            // tags:
            //      public

            return this.filterBy('key', source, target);
        },

        filterBy: function (/*String*/filterProperty, /*Object*/source, /*Object*/target) {
            // summary:
            //      Filters by comparing part(s) of the given source and target objects
            // source: [Object]
            //      The given source object
            // target: [Object]
            //      The given target object
            // returns: [Boolean]
            // tags:
            //      private

            if (!filterProperty) {
                return false;
            }

            if (!source || !target) {
                return false;
            }

            if (!source.hasOwnProperty(filterProperty) || !target.hasOwnProperty(filterProperty)) {
                return false;
            }

            return source[filterProperty] === target[filterProperty];
        },

        refreshApp: function () {
            // summary:
            //      Refresh application
            // tags:
            //      public

            // window.location.reload()
            //  TRUE:
            //      The browser will skip the cache and reload the page from the server
            //  FALSE:
            //      Will do the opposite
            window.location.reload(true);
        },

        // =================================================================================================================================================
        // Data visualizer (d3js) common functions
        // =================================================================================================================================================

        loadSvgFile: function (/*String*/fileUrl) {
            // summary:
            //      Load external SVG file from the given file url
            // fileUrl: [String]
            //      The given external SVG file url
            // tags:
            //      public

            var $deferred = $.Deferred();

            if (!fileUrl) {
                $deferred.resolve();

                return $deferred.promise();
            }

            var self = this;
            dataVisualizer.xml(fileUrl, 'image/svg+xml', function (/*Object*/error, /*Object*/data) {
                if (error) {
                    // TODO: Log and then show error on the Notification component
                    $deferred.resolve();

                    return $deferred.promise();
                }

                if (!data || !data.documentElement) {
                    // TODO: Log and then show error on the Notification component
                    $deferred.resolve();

                    return $deferred.promise();
                }

                try {
                    // Adding our SVG file to HTML document
                    $deferred.resolve(document.importNode(data.documentElement, true));
                } catch (ex) {
                    $deferred.resolve(self._importNode(data.documentElement, true));
                }
            });

            return $deferred.promise();
        },

        _importNode: function (/*DOM*/node, /*Boolean*/allChildren) {
            // summary:
            //      There is a function document.importNode() in Internet Explorer 9 DOM API.
            //      However, IE9 throws a script error when it's called
            //          SCRIPT16386: No such interface supported
            // node: [DOM]
            //      The node wanted to import to the current document
            // allChildren: [Boolean]
            //      Flag to indicates should import all chilren or not
            // tags:
            //      private

            switch (node.nodeType) {
                case document.ELEMENT_NODE:
                    var newNode = document.createElementNS(node.namespaceURI, node.nodeName);
                    if (node.attributes && node.attributes.length > 0) {
                        for (var i = 0, il = node.attributes.length; i < il; i++) {
                            newNode.setAttribute(node.attributes[i].nodeName, node.getAttribute(node.attributes[i].nodeName));
                        }
                    }

                    if (allChildren && node.childNodes && node.childNodes.length > 0) {
                        for (var i = 0, il = node.childNodes.length; i < il; i++) {
                            newNode.appendChild(this._importNode(node.childNodes[i], allChildren));
                        }
                    }

                    return newNode;

                case document.TEXT_NODE:
                case document.CDATA_SECTION_NODE:
                case document.COMMENT_NODE:
                    return document.createTextNode(node.nodeValue);
            }
        }
    };

    return AppUtility;

});