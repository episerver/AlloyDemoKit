﻿define([
    "epi/_Module",
    "epi/dependency",
    "epi/routes",
    "epi/shell/HashWrapper"

], function (
    _Module,
    dependency,
    routes,
    HashWrapper

) {

    return dojo.declare([_Module], {

        // _settings: [private] Object
        //      Object store settings which sent by LiveMonitor component.
        _settings: null,

        constructor: function (settings) {
            this._settings = settings;
        },

        initialize: function () {
            // summary:
            //		Initialize module
            //
            // description:
            //      Dependencies registered by this module are: 'LiveMonitor application'

            this.inherited(arguments);

            // Initialize stores
            var registry = this.resolveDependency("epi.storeregistry");

            var route = this._getRestPath("livemonitor");

            registry.create("epi-livemonitor.livemonitor", route, { idProperty: "id" });
        },

        _getRestPath: function (name) {
            // summary:
            //      Get the rest path to a specified store.
            // prameters:
            //      name: The name of the store to get.
            // tags:
            //      private

            return routes.getRestPath({ moduleArea: "EPiServer.LiveMonitor", storeName: name });
        }

    });
});
