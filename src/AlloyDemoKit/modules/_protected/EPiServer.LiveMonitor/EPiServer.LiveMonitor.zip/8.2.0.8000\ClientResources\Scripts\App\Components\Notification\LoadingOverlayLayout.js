﻿define([
// libs
    'jquery',
// live monitor
    'components/ComponentFactory'
],

function (
// libs
    $,
// live monitor
    componentFactory
) {

    // =================================================================================================================================================
    // Component information
    // =================================================================================================================================================
    //
    // module:
    //      Components/Notification/LoadingOverlayLayout
    // summary:
    //      
    // description:
    //      
    // tags:
    //      public

    LoadingOverlayLayout = {
        // Default settings for the component
        settings: {
            placeHolder: 'body',
            layoutSize: {
                height: 600,
                width: 800
            }
        },

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        create: function (settings) {
            // summary:
            //      Create a new instance of the component
            // settings: [Object]
            //      The new settings that wanted to decorates the default settings of the given component
            // returns: [Object]
            //      An instance of the component
            // tags:
            //      public

            $.extend(true, this.settings, settings);

            this._svg = dataVisualizer.select(this.settings.placeHolder)
                .append('svg')
                .attr('class', 'livemonitor-loadingOverlayLayout');

            return this;
        },

        bindData: function (dataSet, mappingData) {
            // summary:
            //      Binding the given data to the component and its children
            // dataSet: [Array]
            //      The given data set that wanted to bind to the current component
            // mappingData: [Array]
            //      The given data that used to mapping a group to a desired position (x,y)
            // tags:
            //      public

        },

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

        _onLayoutFinished: function () {
            // summary:
            //      Fired on finished layout process
            // tags:
            //      private

        },

        _onTick: function () {
            // summary:
            //      Update position for each group element
            // tags:
            //      private

        }
    };

});