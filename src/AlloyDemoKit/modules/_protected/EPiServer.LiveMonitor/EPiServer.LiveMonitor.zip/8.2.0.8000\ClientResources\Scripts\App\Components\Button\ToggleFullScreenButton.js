﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'components/ComponentFactory',

    'components/Button/IconButton'
],

function (
// libs
    $,
// live monitor
    utility,

    componentFactory,

    iconButton
) {

    // =================================================================================================================================================
    // 'LiveMonitorToggleFullScreenButton' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Button/LiveMonitorToggleFullScreenButton'
    // summary:
    //      The jQuery plugin component for the toggle fullscreen button
    // description:
    //      use:
    //          $(target).LiveMonitorToggleFullScreenButton(options);
    //      options:
    //          resources [Object]
    //          iconClasses [String]
    //          fullScreenSelector [String]
    // tags:
    //      public

    // Create the defaults once
    var pluginName = 'LiveMonitorToggleFullScreenButton',
        pluginOptions = {
            iconClasses: 'glyphicon-fullscreen',
            fullScreenTarget: document.body,
            enableParam: 'isToggleFullScreenButtonVisible'
        },
        pluginDefinitions = {

            // =================================================================================================================================================
            // Overrided functions
            // =================================================================================================================================================

            _postInit: function () {
                // summary:
                //      Post-initialize settings for the component
                // tags:
                //      protected, extension

                this._setupLayout();
                this._setupEvents();
            },

            // =================================================================================================================================================
            // Private events
            // =================================================================================================================================================

            _onToggleFullScreenMode: function () {
                // summary:
                //      Fired when the current component received a mouse click event
                // tags:
                //      private

                this._inFullScreenMode()
                    ? this._exitFullScreenMode()
                    : this._goToFullScreenMode();

                this._setTooltipText();
            },

            _onKeyboardToggleFullScreenMode: function (/*Event*/evt) {
                // summary:
                //      Fired when the 'F11' keyboard sent
                // tags:
                //      private

                if (evt.keyCode !== 122) {
                    return;
                }

                // Stop 'F11' function
                $.isFunction(evt.preventDefault) && evt.preventDefault();
                $.isFunction(evt.stopPropagation) && evt.stopPropagation();

                this._onToggleFullScreenMode();
            },

            // =================================================================================================================================================
            // Private functions
            // =================================================================================================================================================

            _setupLayout: function () {
                // summary:
                //      Setup layout for the current component
                // tags:
                //      private

                this._setTooltipText();

                var $iconButton = this._$wrapper.find('.button-icon'),
                    iconClasses = this.options.iconClasses;
                iconClasses && $iconButton && $iconButton.addClass(iconClasses);
            },

            _setupEvents: function () {
                // summary:
                //      Setup events for the current component
                // tags:
                //      private

                this._$wrapper.on('click', utility.hitch(this, this._onToggleFullScreenMode));

                $(window).on('keydown', utility.hitch(this, this._onKeyboardToggleFullScreenMode));
            },

            _setTooltipText: function () {
                // summary:
                //      Set tooltip text for the current component by the current fullscreen mode of the browser
                // tags:
                //      private

                var tooltip = this._resources.tooltip,
                    fullScreenText = tooltip.fullscreen,
                    exitFullScreenText = tooltip.exitfullscreen;

                this._$wrapper.attr('title', this._inFullScreenMode() ? exitFullScreenText : fullScreenText);
            },

            _goToFullScreenMode: function () {
                // summary:
                //      Go to browser's fullscreen mode
                // tags:
                //      private

                var target = this.options.fullScreenTarget;
                if (!target) {
                    return;
                }

                // Supports most browsers and their versions.
                var requestFunction = target.requestFullScreen
                        || target.webkitRequestFullScreen
                        || target.mozRequestFullScreen
                        || target.msRequestFullscreen;

                if ($.isFunction(requestFunction)) {
                    // Native full screen.
                    requestFunction.call(target);
                } else if (typeof window.ActiveXObject !== 'undefined') {
                    // Older IE.
                    var wscript = new ActiveXObject('WScript.Shell');
                    if (wscript !== null) {
                        wscript.SendKeys('{F11}');
                    }
                }
            },

            _exitFullScreenMode: function () {
                // summary:
                //      Exit browser's fullscreen mode
                // tags
                //      private

                var target = document,
                    requestFunction = target.cancelFullScreen
                        || target.webkitCancelFullScreen
                        || target.mozCancelFullScreen
                        || target.msCancelFullscreen
                        || target.msExitFullscreen
                        || target.exitFullscreen;

                if ($.isFunction(requestFunction)) {
                    requestFunction.call(target);
                }
            },

            _inFullScreenMode: function () {
                // summary:
                //      Detect the current browser is in element fullscreen mode or not
                // returns: [Boolean]
                //  true:
                //      It is in element fullscreen mode
                //  false:
                //      It is not in element fullscreen mode
                // tags:
                //      private

                return document.fullscreenElement
                    || document.msFullscreenElement
                    || document.mozFullScreenElement
                    || document.webkitFullscreenElement;
            }
        };

    // A really lightweight plugin wrapper around the constructor, 
    //  preventing against multiple instantiations
    $.fn[pluginName] = function (/*Object*/options) {
        // summary:
        //      Create a new jQuery plugin from the given settings
        // options: [Object]
        //      The given settings that wanted to decorates the default settings of the current component
        // returns: [Object]
        //      The jQuery plugin object
        // tags:
        //      protected

        // Decorates the default settings by the given settings
        var baseOptions = $.fn['LiveMonitorIconButton'].prototype.pluginOptions,
            concreteOptions = $.extend(true, {}, baseOptions, pluginOptions, options);

        // Create and then return a new jQuery plugin object
        return componentFactory.create(this, pluginName, pluginDefinitions, concreteOptions);
    };

});