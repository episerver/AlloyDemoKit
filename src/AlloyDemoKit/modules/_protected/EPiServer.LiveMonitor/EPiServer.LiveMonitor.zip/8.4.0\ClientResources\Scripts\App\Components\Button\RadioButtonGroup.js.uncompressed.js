﻿define([
// libs
    'jquery',
// live monitor
    'components/ComponentFactory',
// resources
    'text!components/Button/Templates/RadioButtonGroup.html'
],

function (
// libs
    $,
// live monitor
    componentFactory,
// resources
    templateString
) {

    // =================================================================================================================================================
    // 'LiveMonitorRadioButtonGroup' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Button/LiveMonitorRadioButtonGroup'
    // summary:
    //      The jQuery plugin component for the radio button group
    // description:
    //      use:
    //          $(target).LiveMonitorRadioButtonGroup(options);
    //      options:
    //          resources [Object]
    //          templateString [String]
    //          baseClasses: [String]
    //          children [Array]
    // tags:
    //      public

    // Create the defaults once
    var pluginName = 'LiveMonitorRadioButtonGroup',
        pluginOptions = {
            templateString: templateString,
            baseClasses: 'livemonitor-radioButtonGroup',
            children: []
        },
        pluginDefinitions = {

            // =================================================================================================================================================
            // Overrided functions
            // =================================================================================================================================================

            _postInit: function () {
                // summary:
                //      Post-initialize settings for the component
                // tags:
                //      protected, extension

                this._setupLayout();
            },

            // =================================================================================================================================================
            // Private functions
            // =================================================================================================================================================

            _setupLayout: function () {
                // summary:
                //      Initialize default layout settings for the current component and its children
                // tags:
                //      private

                var groupName = this._resources.groupname,
                    $groupName = this._$wrapper.find('.group-name');

                groupName && $groupName.text(groupName);
            }
        };

    // A really lightweight plugin wrapper around the constructor, 
    //  preventing against multiple instantiations
    $.fn[pluginName] = function (/*Object*/options) {
        // summary:
        //      Create a new jQuery plugin from the given settings
        // options: [Object]
        //      The given settings that wanted to decorates the default settings of the current component
        // returns: [Object]
        //      The jQuery plugin object
        // tags:
        //      protected

        // Decorates the default settings by the given settings
        $.extend(true, pluginOptions, options);

        // Create and then return a new jQuery plugin object
        return componentFactory.create(this, pluginName, pluginDefinitions, pluginOptions);
    };

});