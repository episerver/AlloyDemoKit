﻿requirejs && requirejs.config({
    baseUrl: LiveMonitorConfig.clientResourcesRootPath,
    paths: {
        'text': 'Libs/require/text',

        'jquery': 'Libs/jquery/jquery-1.10.2.min',
        'jqueryValidate': 'Libs/jquery/jquery.validate-1.11.1.min',

        'bootstrap': 'Libs/bootstrap/js/bootstrap.min',

        'd3': 'Libs/d3/d3-3.3.13.min',

        'signalR': 'Libs/signalR/jquery.signalR-2.0.3.min',
        'signalR.hubs': LiveMonitorConfig.signalRHubs,

        'fake': 'Fake',

        'app': 'Scripts/App',
        'utility': 'Scripts/App/AppUtility',
        'components': 'Scripts/App/Components',
        'data': 'Scripts/App/Data',
        'services': 'Scripts/App/Services'
    },
    shim: {
        'jquery': {
            exports: '$'
        },
        'bootstrap': {
            deps: ['jquery']
        },
        'signalR': {
            deps: ['jquery']
        },
        'signalR.hubs': {
            deps: ['signalR']
        },
        'd3': {
            exports: 'd3'
        }
    }
});

// Load the main app module to start the app
requirejs(['app/AppMain']);