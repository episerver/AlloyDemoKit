﻿define([
// libs
    'jquery',
    'd3',
// live monitor
    'utility',

    'components/Svg/Layout/BaseSvgLayout',

    'components/Svg/Factory/MarkupController'
],

function (
// libs
    $,
    dataVisualizer,
// live monitor
    utility,

    baseSvgLayout,

    markupController
) {

    // =================================================================================================================================================
    // Component information
    // =================================================================================================================================================
    //
    // module:
    //      Components/Svg/Layout/HighwayLayout
    // summary:
    //      
    // description:
    //      
    // tags:
    //      public

    var HighwayLayout = {
        // Default settings for the component
        settings: {
            // Default place holder for the current svg element
            placeHolder: 'body'
        },

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        create: function (/*Object*/settings) {
            // summary:
            //      Create a new instance of the component
            // settings: [Object]
            //      The new settings that wanted to decorates the default settings of the given component
            // returns: [Object]
            //      An instance of the component
            // tags:
            //      public

            // Decorates default settings with the new settings
            $.extend(true, this.settings, settings);

            this._createSvg();

            return this;
        },

        bindData: function (/*Object*/highwayLayoutData) {
            // summary:
            //      Binding the given data to the component and its children
            // highwayLayoutData: [Object]
            //      The given highway layout data object.
            //          linkDataList: [Array]
            //              The collection of the force layout link object
            //          hierarchicalMappingData: [Array]
            //              The given data that used to mapping a group to a desired position (x,y)
            //          templateString: [Object]
            //              The given template string object.
            //                  transparentBall: [String]
            //                      The given transparent ball SVG template string
            //                  highwayBall: [String]
            //                      The given highway ball SVG template string
            // tags:
            //      public

            var linkDataList = highwayLayoutData.linkDataList,
                hierarchicalMappingData = highwayLayoutData.hierarchicalMappingData,
                templateString = highwayLayoutData.templateString;

            this._transparentBallTemplateString = templateString.transparentBall;
            this._highwayBallTemplateString = templateString.highwayBall;

            this.clear();

            if (!utility.isValidArray(linkDataList)) {
                return;
            }

            var nodeDataList = hierarchicalMappingData,
                shouldUpdate = this._shouldUpdate(hierarchicalMappingData);

            this._updateLinksData(linkDataList, shouldUpdate);
            this._updateNodesData(nodeDataList, shouldUpdate);

            this._updateTransferLinesData(linkDataList, shouldUpdate);
            this._updateTransfersData(linkDataList, shouldUpdate);

            this._setupTransfersLayout();
        },

        clear: function () {
            // summary:
            //      Clear the current highway layout
            // tags:
            //      public

            $(this._svg.node()).empty();
        },

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

        _createSvg: function () {
            // summary:
            //      Create the SVG element
            // tags:
            //      private

            // Create a new SVG element and then append it to the given place holder
            this._svg = this._svg || dataVisualizer.select(this.settings.placeHolder).append('svg').attr('class', 'livemonitor-highwayLayout');
        },

        // =================================================================================================================================================
        // Highway nodes functions
        // =================================================================================================================================================

        _updateNodesData: function (/*Array*/nodeDataList, /*Boolean*/shouldUpdate) {
            // summary:
            //      Update the node collection from the given data
            // nodeDataList: [Array]
            //      The given collection of node data object
            // shouldUpdate: [Boolean]
            //      Flag indicate should or should not update data
            // tags:
            //      private

            var container = this._svg.append('g').attr('class', 'highway-contents');

            // DATA JOIN
            // Join new data with old elements, if any.
            this._nodeList = container.selectAll('.highway-mapping-content')
                    .data(nodeDataList, function (/*Object*/d) {
                        // d: [Object]
                        //      The given datum object

                        return d.contentId;
                    });

            // UPDATE
            // Update old elements as needed.
            var updateNodeList = this._nodeList.attr('class', 'highway-mapping-content updated');
            shouldUpdate && this._setupNodesPosition(updateNodeList);

            // ENTER
            // Create new elements as needed.
            var newNodeList = this._nodeList.enter().append('g')
                .attr('class', 'highway-mapping-content enter')
                .attr('id', function (/*Object*/d) {
                    // d: [Object]
                    //      The given datum object

                    return 'highway-mapping-content-' + d.contentId;
                });
            this._setupNodesLayout(newNodeList[0]);
            this._setupNodesPosition(newNodeList);

            // EXIT
            // Remove old elements as needed.
            this._nodeList.exit().remove();
        },

        _setupNodesPosition: function (/*Array*/nodeList) {
            // summary:
            //      Set position for each node item in the given node collection
            // nodeList: [Array]
            //      The given node collection
            // tags:
            //      private

            nodeList.attr('transform', function (/*Object*/d) {
                // d: [Object]
                //      The given datum object

                return 'translate(' + d.x + ',' + d.y + ')';
            });
        },

        _setupNodesLayout: function (/*Array*/newNodeList) {
            // summary:
            //      Setup layout for the given nodes
            // newNodeList: [Array]
            //      The given collection of the node container object
            // tags:
            //      private

            var totalItems = newNodeList.length,
                container,
                containerNode,
                itemData;

            while (totalItems--) {
                container = dataVisualizer.select(newNodeList[totalItems]);
                containerNode = container.node();

                itemData = containerNode && container.datum();
                if (!itemData) {
                    continue;
                }

                containerNode.appendChild(this._getTemplateContent($(utility.formatTemplateString(this._transparentBallTemplateString, itemData))[0]));
            }
        },

        // =================================================================================================================================================
        // Highway links functions
        // =================================================================================================================================================

        _updateLinksData: function (/*Array*/linkDataList, /*Boolean*/shouldUpdate) {
            // summary:
            //      Update the link collection from the given data
            // linkDataList: [Array]
            //      The given collection of link data object
            // shouldUpdate: [Boolean]
            //      Flag indicate should or should not update data
            // tags:
            //      private

            var container = this._svg.append('g').attr('class', 'highway-links');

            // DATA JOIN
            // Join new data with old elements, if any.
            this._linkList = container.selectAll('.highway-link')
                .data(linkDataList, function (/*Object*/d) {
                    // d: [Object]
                    //      The given datum object

                    return d.linkId;
                });

            // UPDATE
            // Update old elements as needed.
            var updateLinkList = this._linkList.attr('class', 'highway-link updated');
            shouldUpdate && this._setupLinksPosition(updateLinkList);

            // ENTER
            // Create new elements as needed.
            var newLinkList = this._linkList.enter().insert('path', 'g')
                .attr('id', function (/*Object*/d) {
                    // d: [Object]
                    //      The given datum object

                    return 'highway-link-' + d.linkId;
                })
                .attr('class', 'highway-link enter');
            this._setupLinksPosition(newLinkList);

            // EXIT
            // Remove old elements as needed.
            this._linkList.exit().remove();
        },

        _setupLinksPosition: function (/*Array*/linkList) {
            // summary:
            //      Set position for each link item in the given link collection
            // linkList: [Array]
            //      The given link collection
            // tags:
            //      private

            linkList.attr('d', function (/*Object*/d) {
                // d: [Object]
                //      The given datum object

                // The following commands are available for path data:
                //  M = moveto
                //  L = lineto
                //  H = horizontal lineto
                //  V = vertical lineto
                //  C = curveto
                //  S = smooth curveto
                //  Q = quadratic Bézier curve
                //  T = smooth quadratic Bézier curveto
                //  A = elliptical Arc
                //  Z = closepath

                // For example:
                //  'M0 -5 L10 0 L0 5 Z'
                // The above defines a path that starts at position 0,-5
                //  with a line to position 10,0
                //  then from there, a line to 0,5
                //  and finally closing the path back to 0,-5

                var sourceX = d.source.x,
                    sourceY = d.source.y,
                    targetX = d.target.x,
                    targetY = d.target.y,
                    radius = 20;

                if (!sourceX || !sourceY || !targetX || !targetY) {
                    return null;
                } else {
                    sourceX += radius;
                    sourceY += radius;
                    targetX += radius;
                    targetY += radius;

                    return 'M' + sourceX + ' ' + sourceY + ' L' + targetX + ' ' + targetY;
                }
            });
        },

        // =================================================================================================================================================
        // Transfer lines functions
        // =================================================================================================================================================

        _updateTransferLinesData: function (/*Array*/linkDataList, /*Boolean*/shouldUpdate) {
            // summary:
            //      Update the transfer line collection from the given data
            // linkDataList: [Array]
            //      The given collection of link data object
            // shouldUpdate: [Boolean]
            //      Flag indicate should or should not update data
            // tags:
            //      private

            var container = this._svg.append('g').attr('class', 'highway-transfer-lines');

            // DATA JOIN
            // Join new data with old elements, if any.
            this._transferLineList = container.selectAll('.highway-transfer-line')
                    .data(linkDataList, function (/*Object*/d) {
                        // d: [Object]
                        //      The given datum object

                        return 'higway-transfer-line-' + d.linkId;
                    });

            // UPDATE
            // Update old elements as needed.
            var updateTransferLineList = this._transferLineList
                .attr('class', 'highway-transfer-line updated')
                .attr('marker-end', 'url(#livemonitor-highway-marker)');
            shouldUpdate && this._setupTransferLinesPosition(updateTransferLineList);

            // ENTER
            // Create new elements as needed.
            var newTransferLineList = this._transferLineList.enter().insert('path', 'g')
                .attr('id', function (/*Object*/d) {
                    // d: [Object]
                    //      The given datum object

                    return 'highway-transfer-line-' + d.linkId;
                })
                .attr('class', 'highway-transfer-line enter')
                .attr('marker-end', 'url(#livemonitor-highway-marker)');
            this._setupTransferLinesPosition(newTransferLineList);

            // EXIT
            // Remove old elements as needed.
            this._transferLineList.exit().remove();
        },

        _setupTransferLinesPosition: function (/*Array*/transferLineList) {
            // summary:
            //      Set position for each transfer line item in the given transfer line collection
            // transferLineList: [Array]
            //      The given transfer line collection
            // tags:
            //      private

            var container = this._svg;
            transferLineList.attr('d', function (/*Object*/d) {
                // d: [Object]
                //      The given datum object

                var transferLine = container.select('path#highway-link-' + d.linkId),
                    targetX = d.target.x,
                    targetY = d.target.y,
                    linkNode,
                    totalLength,
                    sourcePointer,
                    targetPointer;

                if (transferLine && (linkNode = transferLine.node())) {
                    // SVG native functions:
                    //      getTotalLength()
                    //      getPointAtLength()
                    totalLength = Math.round(linkNode.getTotalLength());

                    // The max length for best display of a highway line incase the distance between start and end points are very close
                    //  If the max length reached, hides the highway line
                    if (totalLength < 70) {
                        return null;
                    }

                    sourcePointer = linkNode.getPointAtLength(20);
                    targetPointer = linkNode.getPointAtLength(totalLength - 35);

                    var sourceX = sourcePointer.x,
                        sourceY = sourcePointer.y,
                        targetX = targetPointer.x,
                        targetY = targetPointer.y,
                        radius = 20;

                    if (!sourceX || !sourceY || !targetX || !targetY) {
                        return null;
                    } else {
                        return 'M' + sourceX + ' ' + sourceY + ' L' + targetX + ' ' + targetY;
                    }
                }

                return null;
            });
        },

        // =================================================================================================================================================
        // Highway transfers functions
        // =================================================================================================================================================

        _updateTransfersData: function (/*Array*/linkDataList, /*Boolean*/shouldUpdate) {
            // summary:
            //      Update the transfers collection from the given data
            // linkDataList: [Array]
            //      The given collection of link data object
            // shouldUpdate: [Boolean]
            //      Flag indicate should or should not update data
            // tags:
            //      private

            var container = this._svg.append('g').attr('class', 'highway-transfers');

            // DATA JOIN
            // Join new data with old elements, if any.
            this._linkTransfersList = container.selectAll('.highway-link-transfers')
                    .data(linkDataList, function (/*Object*/d) {
                        // d: [Object]
                        //      The given datum object

                        return d.linkId;
                    });

            // UPDATE
            // Update old elements as needed.
            var updateLinkTranfersList = this._linkTransfersList.attr('class', 'highway-link-transfers updated');
            shouldUpdate && this._setupTransfersPosition(updateLinkTranfersList);

            // ENTER
            // Create new elements as needed.
            var newLinkTranfersList = this._linkTransfersList.enter().append('g').attr('class', 'highway-link-transfers enter');
            this._setupTransfersPosition(newLinkTranfersList);

            // EXIT
            // Remove old elements as needed.
            this._linkTransfersList.exit().remove();
        },

        _setupTransfersPosition: function (/*Array*/linkTransferList) {
            // summary:
            //      Set position for each link transfer item in the given link transfer collection
            // linkTransferList: [Array]
            //      The given link transfer collection
            // tags:
            //      private

            var container = this._svg;
            linkTransferList.attr('transform', function (/*Object*/d) {
                // d: [Object]
                //      The given datum object

                var link = container.select('path#highway-link-' + d.linkId),
                    targetX = d.target.x,
                    targetY = d.target.y,
                    linkNode,
                    totalLength,
                    pointer;

                if (link && (linkNode = link.node())) {
                    // SVG native functions:
                    //      getTotalLength()
                    //      getPointAtLength()
                    totalLength = Math.round(linkNode.getTotalLength());

                    // The max length for best display of a transfers ball in its highway line incase the distance between start and end points are very close
                    //  If the max length reached, hides the transfers ball
                    if (totalLength < 120) {
                        return 'translate(-100, -100)';
                    }

                    pointer = linkNode.getPointAtLength(totalLength - 80);
                    if (pointer) {
                        var radius = 15;

                        targetX = pointer.x - radius;
                        targetY = pointer.y - radius;
                    }
                }

                return 'translate(' + targetX + ',' + targetY + ')';
            });
        },

        _setupTransfersLayout: function () {
            // summary:
            //      Setup layout for the given highway transfers
            // tags:
            //      private

            var linkTransfersList = this._linkTransfersList[0],
                totalItems = linkTransfersList.length,
                container,
                containerNode,
                itemData;

            while (totalItems--) {
                container = dataVisualizer.select(linkTransfersList[totalItems]);
                containerNode = container.node();

                itemData = containerNode && container.datum();
                if (!itemData) {
                    continue;
                }

                containerNode.appendChild(this._getTemplateContent($(utility.formatTemplateString(this._highwayBallTemplateString, itemData))[0]));
            }
        }

    };

    return $.extend(true, {}, baseSvgLayout, HighwayLayout);

});