﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'components/ComponentFactory',

    'components/Button/IconButton'
],

function (
// libs
    $,
// live monitor
    utility,

    componentFactory,

    iconButton
) {

    // =================================================================================================================================================
    // 'LiveMonitorToggleCollapsiblePanelButton' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Button/LiveMonitorToggleCollapsiblePanelButton'
    // summary:
    //      The jQuery plugin component for the toggle collapsible panel button
    // description:
    //      use:
    //          $(target).LiveMonitorToggleCollapsiblePanelButton(options);
    //      options:
    //          resources [Object]
    //          collapsiblePanel [Object]
    //          collapseClasses [String]
    //          expandClasses [String]
    // tags:
    //      public

    // Create the defaults once
    var pluginName = 'LiveMonitorToggleCollapsiblePanelButton',
        pluginOptions = {
            collapsiblePanel: null,
            collapseClasses: 'glyphicon-indent-right',
            expandClasses: 'glyphicon-indent-left',
        },
        pluginDefinitions = {

            // =================================================================================================================================================
            // Overrided functions
            // =================================================================================================================================================

            _postInit: function () {
                // summary:
                //      Post-initialize settings for the component
                // tags:
                //      protected, extension

                this._setupLayout();
                this._setupEvents();
            },

            // =================================================================================================================================================
            // Public events
            // =================================================================================================================================================

            onToggle: function () {
                // summary:
                //      Fired when the current component received a mouse click event
                // tags:
                //      private

                this._setupLayout();
            },

            // =================================================================================================================================================
            // Private functions
            // =================================================================================================================================================

            _setupLayout: function () {
                // summary:
                //      Setup layout for the current component
                // tags:
                //      private

                var expanded = this._isCollapsiblePanelExpanded();

                this._setIcon(expanded);
                this._setTooltipText(expanded);
            },

            _setupEvents: function () {
                // summary:
                //      Setup events for the current component
                // tags:
                //      private

                this._$wrapper.on('click', utility.hitch(this, function () {
                    this.triggerContextEvent('toggleCollapsiblePanel');
                }));
            },

            _setIcon: function (/*Boolean*/expanded) {
                // summary:
                //      Set icon classes for the current component regarding to expand/collapse state of the Components/Panel/LiveMonitorCollapsiblePanel
                // expanded: [Boolean]
                //      Indicates whether the visitor list is expanded
                // tags:
                //      private

                var options = this.options,
                    $iconButton = this._$wrapper.find('.button-icon:eq(0)');

                $iconButton.removeClass(options.collapseClasses).removeClass(options.expandClasses)
                    .addClass(expanded ? options.collapseClasses : options.expandClasses);
            },

            _setTooltipText: function (/*Boolean*/expanded) {
                // summary:
                //      Set tooltip text for the current component by the current fullscreen mode of the browser
                // expanded: [Boolean]
                //      Indicates whether the visitor list is expanded
                // tags:
                //      private

                var tooltip = this._resources.tooltip;
                this._$wrapper.attr('title', expanded ? tooltip.hidelist : tooltip.showlist);
            },

            _isCollapsiblePanelExpanded: function () {
                // summary:
                //      Indicates whether the visitor list panel is expanded
                // tags:
                //      private

                var collapsiblePanel = this.options.collapsiblePanel;

                return collapsiblePanel && !collapsiblePanel.hasClass('collapsed');
            }
        };

    // A really lightweight plugin wrapper around the constructor, 
    //  preventing against multiple instantiations
    $.fn[pluginName] = function (/*Object*/options) {
        // summary:
        //      Create a new jQuery plugin from the given settings
        // options: [Object]
        //      The given settings that wanted to decorates the default settings of the current component
        // returns: [Object]
        //      The jQuery plugin object
        // tags:
        //      protected

        // Decorates the default settings by the given settings
        var baseOptions = $.fn['LiveMonitorIconButton'].prototype.pluginOptions,
            concreteOptions = $.extend(true, {}, baseOptions, pluginOptions, options);

        // Create and then return a new jQuery plugin object
        return componentFactory.create(this, pluginName, pluginDefinitions, concreteOptions);
    };

});