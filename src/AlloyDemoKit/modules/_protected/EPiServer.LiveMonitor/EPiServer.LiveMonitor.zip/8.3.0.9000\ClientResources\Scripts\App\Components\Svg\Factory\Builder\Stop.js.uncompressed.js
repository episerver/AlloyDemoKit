﻿define([
// libs
    'jquery',
// live monitor
    'utility'
],

function (
// libs
    $,
// live monitor
    utility
) {

    // =================================================================================================================================================
    // 'StopElementBuilder' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Svg/Factory/Builder/StopElementBuilder'
    // summary:
    //      The element builder class for 'stop' SVG object
    // description:
    //      Create the 'STOP' SVG element
    // tags:
    //      public

    var StopElementBuilder = {

        elementName: 'stop',

        create: function (/*Object*/stopSettings, /*Array*/container, /*Function?*/recursiveCreate) {
            // summary:
            //      Create and then append a SVG stop element (stop') to the given container
            // stopSettings: [Object]
            //      The given STOP settings
            // container: [Array]
            //      The given container
            // recursiveCreate: [Function?]
            //      Indicated that should or should not create children recursively
            // tags:
            //      public

            if (!stopSettings) {
                return;
            }

            var stopList = container.selectAll(this.elementName)
                        .data(utility.getItemCollection(stopSettings))
                            .enter()
                    .append(this.elementName)
                        .attr('class', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.classes;
                        })
                        .attr('offset', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.offset;
                        });

            $.isFunction(recursiveCreate) && recursiveCreate(stopSettings, /*container*/stopList);
        }

    };

    return StopElementBuilder;

});