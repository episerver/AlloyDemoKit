﻿define([
// libs
    'jquery',
// live monitor
    'utility'
],

function (
// libs
    $,
// live monitor
    utility
) {

    // =================================================================================================================================================
    // 'TextElementBuilder' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Svg/Factory/Builder/TextElementBuilder'
    // summary:
    //      The element builder class for 'text' SVG object
    // description:
    //      Create the 'TEXT' SVG element
    // tags:
    //      public

    var TextElementBuilder = {

        elementName: 'text',

        create: function (/*Object*/textSettings, /*Array*/container, /*Function?*/recursiveCreate) {
            // summary:
            //      Create a TEXT svg object from the given settings and then append it to the given container
            // textSettings: [Object]
            //      The given TEXT settings
            // container: [Array]
            //      The given container
            // recursiveCreate: [Function?]
            //      Indicated that should or should not create children recursively
            // tags:
            //      public

            if (!textSettings) {
                return;
            }

            var textList = container.selectAll(this.elementName)
                        .data(utility.getItemCollection(textSettings))
                            .enter()
                    .append(this.elementName)
                        .attr('class', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.classes;
                        })
                        .attr('transform', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.transform;
                        })
                        .attr('x', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.x;
                        })
                        .attr('y', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.y;
                        })
                        .text(function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.value;
                        });

            $.isFunction(recursiveCreate) && recursiveCreate(textSettings, /*container*/textList);
        }

    };

    return TextElementBuilder;

});