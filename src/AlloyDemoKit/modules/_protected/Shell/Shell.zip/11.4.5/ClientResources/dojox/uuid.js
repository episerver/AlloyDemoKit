//>>built
define("dojox/uuid",["dojox/uuid/_base"],function(_1){return _1;});