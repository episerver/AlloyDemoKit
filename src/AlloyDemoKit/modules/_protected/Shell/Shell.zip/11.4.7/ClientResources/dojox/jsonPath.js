//>>built
define("dojox/jsonPath",["./jsonPath/query"],function(){});