//>>built
define("dojox/sql",["./sql/_base"],function(){});