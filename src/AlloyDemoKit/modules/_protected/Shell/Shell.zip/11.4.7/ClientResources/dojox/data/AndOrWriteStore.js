//>>built
define("dojox/data/AndOrWriteStore",["dojo/_base/declare","dojo/data/ItemFileWriteStore","./AndOrReadStore"],function(_1,_2,_3){return _1("dojox.data.AndOrWriteStore",[_2,_3],{});});