﻿define("epi-cms-addons-blocks/ExcludedDeps", [
    "epi/_Module",
    "epi/routes",
    "epi-cms/widget/overlay/ContentArea",
    "epi/shell/widget/_ValueRequiredMixin",
    "epi/shell/command/_CommandProviderMixin",
    "epi-cms/widget/Breadcrumb"
], 1);