require({cache:{
'url:epi-cms-addons-blocks/OptimizingBlock/templates/OptimizingBlockItem.html':"﻿<div class=\"dojoDndItem epi-overlay-block\">\r\n    <div data-dojo-attach-point=\"containerDomNode\">\r\n        <div class=\"epi-content-block-editor\" data-dojo-attach-point=\"optimizingBlockItemNode\">\r\n            <div class=\"epi-optimizing-block\">\r\n                <span class=\"epi-content-block-node\" style=\"height: auto;\">\r\n                    <span data-dojo-attach-point=\"iconNode\" role=\"presentation\"></span>\r\n                    <span data-dojo-attach-point=\"labelNode\" class=\"epi-block-title\"></span>\r\n                </span>\r\n            </div>            \r\n            <div data-dojo-attach-point=\"statisticNode\"></div>\r\n        </div>\r\n    </div>\r\n    <span class=\"epi-personalized\" data-dojo-attach-point=\"iconsContainer\">\r\n        <span class=\"epi-overlayControls epi-mediumButton \">\r\n            <span class=\"dijitReset dijitInline dijitIcon epi-iconWarning\" data-dojo-attach-point=\"warningIcon\"></span>\r\n            <span class=\"dijitReset dijitInline dijitIcon epi-iconUsers\" data-dojo-attach-point=\"personalizedIcon\"></span>\r\n        </span>\r\n    </span>\r\n    <button class=\"epi-chromelessButton epi-overlayControls epi-settingsButton epi-mediumButton\" data-dojo-attach-point=\"settingsButton\" data-dojo-type=\"dijit/form/DropDownButton\" data-dojo-props=\"showLabel:false, title:'${res.settingstooltip}', iconClass:'epi-iconContextMenu'\">\r\n        <span data-dojo-attach-point=\"contextMenu\" data-dojo-type=\"epi/shell/widget/ContextMenu\"></span>\r\n    </button>\r\n</div>\r\n"}});
﻿define("epi-cms-addons-blocks/OptimizingBlock/OptimizingBlockItem", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/dom-class",
    "dojo/dom-geometry",
    "dojo/dom-style",

// EPi Framework
    
    "epi/shell/command/_CommandProviderMixin",
    "epi/shell/TypeDescriptorManager",

    "epi-cms-addons-blocks/OptimizingBlock/StatisticInfo",
    "epi-cms-addons-blocks/OptimizingBlock/viewmodel/StatisticInfoViewModel",

    "epi-cms/contentediting/command/BlockRemove",
    "epi-cms/contentediting/command/BlockEdit",
    "epi-cms/widget/overlay/Block",
// resources
    "dojo/text!./templates/OptimizingBlockItem.html"
],

function (
// dojo
    declare,
    lang,

    domClass,
    domGeom,
    domStyle,

// epi
    _CommandProviderMixin,
    TypeDescriptorManager,

    StatisticInfo,
    StatisticInfoViewModel,

    RemoveCommand,
    EditCommand,
    Block,
// resources
    template
) {

    // module:
    //      epi-cms-addons-blocks/OptimizingBlock/OptimizingBlockItem
    // summary:
    //      The block widget is used together with the BlockArea widget to show the
    //      position of the different blocks for a ContentAreaProperty.
    // tags:
    //      public

    return declare([Block, _CommandProviderMixin], {
        templateString: template,

        // iconClass: string
        //      The icon class of page/block
        iconClass: "",

        postMixInProperties: function () {

            this.inherited(arguments);

            if (!this.commands || this.commands.length <= 0) {
                this.commands = [
                    new EditCommand(),
                    new RemoveCommand()
                ];
            }


            // Override commands provider
            this.commandProvider = this;
            this.updateCommandModel(this.viewModel);
        },

        postCreate: function () {
            this.inherited(arguments);

            this.own(
                this.viewModel.watch("statisticInfo", lang.hitch(this, this._setupUI))
            );
        },

        updatePosition: function (position) {
            // summary:
            //      Update the position of the current content
            // tags:
            //      public, extension

            this.inherited(arguments);

            return this._updateHeight();
        },

        _setupUI: function () {
            // summary:
            //      Settings for the current content
            // tags:
            //      private

            this._buildStatisticSegment();
            this._buildHeadingSegment();
            this._updateHeight();
        },

        _buildHeadingSegment: function () {
            // summary:
            //      Custom labelNode style and resize
            // tags:
            //      private

            this.labelNode.innerHTML = this.sourceItemNode.innerHTML;

            if (TypeDescriptorManager) {
                this.iconClass = TypeDescriptorManager.getValue(this.viewModel.typeIdentifier, "iconClass");
            }
            domClass.add(this.iconNode, this.iconClass);
        },

        _buildStatisticSegment: function () {
            // summary:
            //      Build statistic widget or update it's model.
            // tags:
            //      private

            if (!this.statisticInfo) {
                this.statisticInfo = new StatisticInfo();
                this.statisticInfo.placeAt(this.statisticNode);
            }

            if (this.viewModel.statisticInfo) {
                this.statisticInfo.set("model", new StatisticInfoViewModel(this.viewModel.statisticInfo));
            }
        },

        _updateHeight: function () {
            // summary:
            //      Update the height of the current source content, so that, it will automatically update the height of the related overlay
            // tags:
            //      private

            var currentHeight = domGeom.getMarginBox(this.sourceItemNode).h,
                updatedHeight = domGeom.getMarginBox(this.optimizingBlockItemNode).h,
                style = { "visibility": "hidden" },
                sizeChanged = currentHeight != updatedHeight;

            if (sizeChanged) {
                style.height = updatedHeight + "px";
            }

            domStyle.set(this.sourceItemNode, style);

            return sizeChanged;
        },

        _onContextMenuClick: function () {
            // summary:
            //      Override from Block
            // tags:
            //      private

            this.updateCommandModel(this.viewModel);
            this.viewModel.set("selected", true);

            return false; // Return false to cause prevent default in dijit/form/_ButtonMixin
        }

    });

});