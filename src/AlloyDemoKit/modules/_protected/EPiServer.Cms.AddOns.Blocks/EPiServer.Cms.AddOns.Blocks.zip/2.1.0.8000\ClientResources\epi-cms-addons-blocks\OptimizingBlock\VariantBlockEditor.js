﻿define([
// Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-class",
    "dojo/when",

// Dijit
    "dijit/_WidgetsInTemplateMixin",

// EPi Framework
    "epi/shell/TypeDescriptorManager",

// EPi CMS
    "epi-cms/contentediting/editors/ContentBlockEditor",
    "epi-cms/widget/Breadcrumb", // used in template
    "epi-cms-addons-blocks/OptimizingBlock/StatisticInfo",
    "epi-cms-addons-blocks/OptimizingBlock/viewmodel/StatisticInfoViewModel",

// Resources
    "dojo/text!./templates/VariantBlockEditor.html"
],

function (
// Dojo
    declare,
    lang,
    domClass,
    when,

// Dijit
    _WidgetsInTemplateMixin,

// EPi Framework
    TypeDescriptorManager,

// EPi CMS
    ContentBlockEditor,
    Breadcrumb,
    StatisticInfo,
    StatisticInfoViewModel,

// Resources
    template

) {
    return declare([ContentBlockEditor, _WidgetsInTemplateMixin], {
        // summary:
        //      A kind of BlockEditor to custom optimizing block node to match with MultivariantBlock UI

        templateString: template,

        // iconClass: string
        //      The icon class of page/block
        iconClass: "",

        postMixInProperties: function () {
            // summary:
            //      Add one more property for model mapping to change icon class for type of content
            // tags:
            //      Protected

            this.modelBindingMap = lang.mixin(this.modelBindingMap, {
                "typeIdentifier": ["typeIdentifier"]
            });

            this.inherited(arguments);
        },

        postCreate: function () {
            this.inherited(arguments);

            if (!this.breadcrumbNode) {
                this.breadcrumbNode = new Breadcrumb();
            }
            this.breadcrumbNode.set("contentLink", this.contentLink);

            if (!this.statisticInfo) {
                this.statisticInfo = new StatisticInfo();
                this.statisticInfo.placeAt(this.statisticNode);
            }
            this.statisticInfo.set("model", new StatisticInfoViewModel(this.model.statisticInfo));
            if (!this.model.get("selected")) {
                this.model.set("selected", false);
            }

            this.own(
                this.model.watch("statisticInfo", lang.hitch(this, function () {
                    this.statisticInfo.set("model", new StatisticInfoViewModel(this.model.statisticInfo));
                }))
            );
        },

        _setTypeIdentifierAttr: function () {
            // summary:
            //      Change icon class for type of content
            // tags:
            //      Private
            if (TypeDescriptorManager) {
                this.iconClass = TypeDescriptorManager.getValue(this.model.typeIdentifier, "iconClass");
            }
            domClass.add(this.iconNode, this.iconClass);
        },

        _onClick: function (evt) {
            // summary:
            //      Override base method to keep selected ui when re-click on selected block.

            this.inherited(arguments);

            this.model.set("selected", true);
        }

    });
});