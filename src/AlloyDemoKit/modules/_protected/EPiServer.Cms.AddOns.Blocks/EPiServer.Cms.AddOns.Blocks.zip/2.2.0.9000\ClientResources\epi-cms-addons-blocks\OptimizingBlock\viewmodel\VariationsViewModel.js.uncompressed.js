﻿define("epi-cms-addons-blocks/OptimizingBlock/viewmodel/VariationsViewModel", [
// Dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Deferred",
    "dojo/promise/all",
    "dojo/when",
    "dojo/has",

// EPi Framework
    "epi/dependency",

// EPi CMS
    "epi-cms/contentediting/viewmodel/ContentBlockViewModel",
    "epi-cms/contentediting/viewmodel/PersonalizedGroupViewModel",
    "epi-cms/contentediting/viewmodel/ContentAreaViewModel"
],

function (
// Dojo
    array,
    declare,
    lang,
    Deferred,
    all,
    when,
    has,

// EPi Framework
    dependency,

// EPi CMS
    ContentBlockViewModel,
    PersonalizedGroupViewModel,
    ContentAreaViewModel
) {
    return declare([ContentAreaViewModel], {
        // summary:
        //      Customize ContentAreaViewModel

        // dynamicDataStore: JsonRest
        //      Used to get statistic data of the block
        dynamicDataStore: null,

        // orderBy: [public] Json
        //      Order by statistic information.
        orderBy: {
            column: "boostValue",
            order: "desc"
        },

        constructor: function () {
            this.inherited(arguments);

            this.dynamicDataStore = this.dynamicDataStore || dependency.resolve("epi.storeregistry").get("episerver.cms.addons.blocks");
        },

        isMyChild: function (/*Object*/item) {
            // summary:
            //      Common method to indicate that the item is child of this model or not.
            // tags:
            //      public

            return item instanceof ContentBlockViewModel;
        },

        createModel: function (child) {
            // summary:
            //      Create ContentBlockViewModel wrap this child inside.
            // return: ContentBlockViewModel

            var model = child;
            if (!this.isMyChild(child)) {
                model = new ContentBlockViewModel(child);
                this.addChild(model);
            }

            return model;
        },

        setContentModel: function (contentModel) {
            // summary:
            //      Update child model and get their statistic data then re-ordering them by boost value desc.

            var dfd = new Deferred();

            this.set("contentModel", contentModel);

            when(this._updateStatisticInfoForModel(), lang.hitch(this, function () {
                this._sort();
                dfd.resolve();
            }));

            return dfd;
        },

        _sort: function () {
            // summary:
            //      Sort blocks order by statistic data's columns value.
            //      When we change to use dgrid then this method does not necessary.

            if (!this.orderBy || !this.orderBy.column) {
                return;
            }

            if (!this.orderBy.order) {
                this.orderBy.order = "desc";
            }

            var column = this.orderBy.column,
                isDescending = this.orderBy.order.toString().toLowerCase() === "desc",
                self = this, map = [], result = [], isOrderingChanged = false;

            function sort(a, b) {
                if (has("ie") && (a.value == b.value)) {
                    return 0;
                }
                return a.value > b.value ? 1 : -1;
            }

            function sortByAsc(a, b) { return sort(a, b); }
            function sortByDesc(a, b) { return sort(b, a); }

            map = array.map(this._data, function (item, index) {
                return {
                    value: item.statisticInfo ? parseFloat(item.statisticInfo.boostValue) : -1,
                    index: index
                };
            });

            if (isDescending) {
                map.sort(sortByDesc);
            } else {
                map.sort(sortByAsc);
            }

            result = array.map(map, function (item) {
                return self._data[item.index];
            });

            // compare old index, new index
            array.some(map, function (item, index) {
                isOrderingChanged = item.index != index;

                return isOrderingChanged;
            });

            if (isOrderingChanged) {
                // update data
                this._data = result;
                this._emitChildrenOrderingChanged();
            }
        },

        _emitChildrenOrderingChanged: function(sender) {
            // summary:
            //      Emits children changed event
            // sender: Object?
            //      The sender
            // tags:
            //      protected, internal
            
            this.emit("childrenOrderChanged", sender ? sender : this);
        },

        _updateStatisticInfoForModel: function () {
            // summary:
            //      Get statistic data then update to each child model

            var self = this;
            function onComplete(data) {
                var children = self.getChildren();
                if (children && children.length > 0) {
                    for (var i = 0; i < children.length; i++) {
                        children[i].set("statisticInfo", data[i]);
                    }
                }
            }

            return this._updateStatisticInfo(null, onComplete);
        },

        _updateStatisticInfo: function (childModel, onComplete) {
            // summary:
            //      Get statistic data then call onComplete.

            var dfd = new Deferred();

            var params = {
                contentLink: this.contentModel.get("icontent_contentlink"), // optimizing block id
                variantReferences: array.map(this.getChildren(), function (child) { return child.contentLink; }), // all variants id
                variantContentLink: childModel ? childModel.contentLink : null // variant id
            };

            when(this.dynamicDataStore.query(params), function (result) {
                onComplete.call(this, result);
                dfd.resolve();
            });

            return dfd;
        }

    });
});