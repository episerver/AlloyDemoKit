﻿define("epi-cms-addons-blocks/OptimizingBlock/viewmodel/StatisticInfoViewModel", [
// Dojo
    "dojo/_base/declare",
    "dojo/Stateful"
],function (
// Dojo
    declare,
    Stateful
) {
    return declare([Stateful], {
        // summary:
        //      Optimizing Block statistic info view model

        // boostValue: Number
        //
        boostValue: null,

        // probability: Number
        //
        probability: null,

        // viewsCount: Number
        //
        viewsCount: null,

        // goalCount: Number
        //
        goalCount: null,

        // viewDate: GMT Date Time
        //
        exposureDate: null
    });
});