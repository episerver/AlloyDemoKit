﻿define([
// Dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/dom-class",
    "dojo/dom-style",

    "dojo/on",
    "dojo/Deferred",
    "dojo/when",

//Dijit
    "dijit/_FocusMixin",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dijit/_CssStateMixin",
    "dijit/_WidgetsInTemplateMixin",

// EPi Framework
    "epi/shell/dnd/Source",
    "epi/shell/widget/ContextMenu",
    "epi/shell/widget/_ValueRequiredMixin",
    "epi/shell/command/_CommandProviderMixin",

// EPi CMS
    "epi-cms-addons-blocks/OptimizingBlock/VariantBlockEditor",
    "epi-cms-addons-blocks/OptimizingBlock/viewmodel/VariationsViewModel",
    "epi-cms/contentediting/command/BlockRemove",
    "epi-cms/contentediting/command/BlockEdit",
    "epi-cms/contentediting/editors/_TextWithActionLinksMixin",

// Resources
    "dojo/text!./templates/VariationsEditor.html"
],

function (
// Dojo
    array,
    declare,
    lang,

    domClass,
    domStyle,

    on,
    Deferred,
    when,

// Dijit
    _FocusMixin,
    _Widget,
    _TemplatedMixin,
    _CssStateMixin,
    _WidgetsInTemplateMixin,

// EPi Framework
    Source,
    ContextMenu,
    _ValueRequiredMixin,
    _CommandProviderMixin,

// EPi CMS
    VariantBlockEditor,
    VariationsViewModel,
    RemoveCommand,
    EditCommand,
    _TextWithActionLinksMixin,

// Resources
    template
) {
    return declare([
        _Widget,
        _FocusMixin,
        _TemplatedMixin,
        _WidgetsInTemplateMixin,
        _CssStateMixin,
        _CommandProviderMixin,
        _ValueRequiredMixin,
        _TextWithActionLinksMixin
    ], {
        // summary:
        //      A kind of ContentAreaEditor to custom optimizing block node to match with MultivariantBlock UI

        // baseClass: [public] String
        //    The widget's base CSS class.
        baseClass: "epi-content-area-editor",

        // templateString: String
        //      UI template for optimizing block's variations editor
        templateString: template,

        // dndTypes: Array string
        //      Acceptance types for dnd.
        dndTypes: ["epi.cms.content.light"],

        // _source: Source
        //      DnD source container.
        _source: null,

        // _updateModelDataThrottle: [private] Number (timeout id)
        //      Throttle timeout id for all calling.
        _updateModelDataThrottle: null,

        // supressValueChanged: [private] Boolean
        //      Avoid save, set value infinitive loop.
        supressValueChanged: false,

        // textWithLinks: [public] TextWithLinks widget
        //      An helper widget to open page/block pannel.
        textWithLinks: null,

        postMixInProperties: function () {

            this.inherited(arguments);

            if (!this.commands || this.commands.length <= 0) {
                this.commands = [
                    new EditCommand(),
                    new RemoveCommand()
                ];
            }

            this.model = this.model || new VariationsViewModel();

            this.contextMenu = this.contextMenu || new ContextMenu();
            this.contextMenu.addProvider(this);

            this.own(
                this.contextMenu,
                this.model.watch("selectedItem", lang.hitch(this, function (name, oldValue, newValue) {
                    //Update the commands with the selected block
                    this.updateCommandModel(newValue);
                })),

                on(this.model, "childrenChanged", lang.hitch(this, function (sender) {
                    this._trySave(true);
                })),

                on(this.model, "childrenOrderChanged", lang.hitch(this, function (sender) {
                    this._trySave(false);
                }))
            );
        },

        buildRendering: function () {

            this.inherited(arguments);

            domClass.add(this.domNode, "epi-variations-editor");

            this._source = new Source(this.rootNode, {
                accept: this.allowedDndTypes,
                creator: lang.hitch(this, this._createDndSourceItem),
                isSource: false,
                singular: true,
                alwaysCopy: false,
                parent: this.containerNode
            });

            this._source.defaultCheckAcceptance = this._source.checkAcceptance;
            this._source.checkAcceptance = lang.hitch(this, this._checkAcceptance);
            
            this.setupActionLinks(this.actionsContainer);
        },

        postCreate: function () {

            this.inherited(arguments);

            when(this._tryUpdateChildModelData(), lang.hitch(this, this._setupUI));
        },

        onChange: function (value) {
            // summary:
            //    Called when the value in the widget changes.
            // tags:
            //    public callback
        },

        _onBlur: function () {
            // summary:
            //      Override base to check that the context menu is showing or not.
            // tags:
            //      protected override

            if (this.contextMenu && this.contextMenu.isShowingNow) {
                return;
            }
            this.inherited(arguments);
        },

        isCreateLinkVisible: function () {
            // summary:
            //      Overidden mixin class, do not want show create link for optimizing block 
            // tags:
            //      protected

            return false;
        },

        _checkAcceptance: function (source, nodes) {
            // summary:
            //      Customize checkAcceptance func
            // source: Object
            //      The source which provides items
            // nodes: Array
            //      The list of transferred items

            return this.readOnly ? false : this._source.defaultCheckAcceptance(source, nodes);
        },

        _setReadOnlyAttr: function (readOnly) {
            this._set("readOnly", readOnly);

            // hide actions when readonly
            domStyle.set(this.actionsContainer, "display", readOnly ? "none" : "");

            if (this.model) {
                this.model.set("readOnly", readOnly);
            }

        },

        focus: function () {
            // summary:
            //    Focus the tree if there is a value, else focus the create block text.
            // tags:
            //    public
            if (this.model.get("value").length > 0) {
                this._focusManager.focus(this.treeNode);
            } else {
                this.textWithLinks.focus();
            }
        },

        isValid: function () {
            // summary:
            //    Check if widget's value is valid.
            // isFocused:
            //    Indicate that the widget is being focused.
            // tags:
            //    protected

            return (!this.required || this.model.get("value").length > 0);
        },

        _trySave: function (/*Boolean*/mustUpdateModel) {
            // summary:
            //    Try save value.
            // tags:
            //    private

            if (!this._started || this.supressValueChanged) {
                return;
            }

            if (mustUpdateModel) {
                when(this._save(), lang.hitch(this, function () {
                    this._tryUpdateChildModelData().then(lang.hitch(this, this._setupUI));
                }));

                return;
            }

            // data is changed by sort, update UI only
            this._setupUI();
        },

        _save: function () {
            // summary:
            //      Save this property value

            var value = this.model.get("value");

            this._set("value", value);
            this.onChange(value);
        },

        _setValueAttr: function (value) {
            this._set("value", value || []);

            this.set("supressValueChanged", true);
            this.model.set("value", value);
            this.set("supressValueChanged", false);

            if (this._started) {
                // We still call _setupUI here to support undo/redo steps
                when(this._tryUpdateChildModelData(), lang.hitch(this, this._setupUI));
            }
        },

        _setupUI: function () {
            // summary
            //      Insert source nodes.

            this._source.selectAll();
            this._source.deleteSelectedNodes();
            this._source.insertNodes(false, this.model.getChildren());
        },

        _createBlockEditor: function (item) {
            // summary:
            //      Create new block editor, add the block model to model

            var model = this.model.createModel(item),
                itemEditor = new VariantBlockEditor({
                    contextMenu: this.contextMenu,
                    model: model
                });

            return itemEditor;
        },

        _tryUpdateChildModelData: function () {
            // summary: Update child model to get statistic info.
            //

            if (this._updateModelDataThrottle) {
                clearTimeout(this._updateModelDataThrottle);
                this._updateModelDataThrottle = null;
            }

            var dfd = new Deferred();

            this._updateModelDataThrottle = setTimeout(lang.hitch(this, function () {
                if (!this.parent) {
                    this.parent = this.getParent();
                }

                if (this.parent && this.parent.contentModel) {

                    this.model.setContentModel(this.parent.contentModel);
                }

                dfd.resolve();

            }), 200);

            return dfd;

        },

        _setParentAttr: function (parent) {
            this._set("parent", parent);

            // We should check this because of _FormEditingMixin call set("parent")
            // after editorWdiget is created.
            if (this._started) {
                when(this._tryUpdateChildModelData(), lang.hitch(this, this._setupUI));
            }
        },

        _createDndSourceItem: function (item, hint) {
            // summary:
            //      Customizes create dnd item

            if (hint == "avatar") {
                return this._source.defaultCreator(item, hint);
            }

            var itemData,
                itemEditor,
                isMyChild = this.model.isMyChild(item);
            if (!isMyChild && typeof item.getNormalizedData == "function") {
                itemData = item.getNormalizedData();
            }

            itemData = itemData ? itemData.data : item;

            // create an block editor
            itemEditor = this._createBlockEditor(itemData);
            if (!isMyChild) {
                // Item is newly created so set it as selected item
                itemEditor.model.set("selected", true);
            }

            return {
                "node": itemEditor.domNode,
                "data": itemData,
                "type": this.allowedDndTypes
            };
        }

    });
});