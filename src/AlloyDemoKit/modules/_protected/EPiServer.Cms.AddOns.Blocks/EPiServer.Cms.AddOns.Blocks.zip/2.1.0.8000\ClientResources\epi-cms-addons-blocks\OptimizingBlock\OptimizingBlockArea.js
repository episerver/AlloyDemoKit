﻿define([
// Dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-class",
    "dojo/when",

// Epi Shell
    "epi/shell/dnd/Target",

// EPi CMS
    "epi-cms/widget/overlay/ContentArea",
    "epi-cms/contentediting/viewmodel/ContentBlockViewModel",

// EPi Add-on
    "epi-cms-addons-blocks/OptimizingBlock/OptimizingBlockItem",
    "epi-cms-addons-blocks/OptimizingBlock/viewmodel/VariationsViewModel"
], function (

// Dojo
    array,
    declare,
    lang,
    domClass,
    when,

// EPi Shell
    Target,

// EPi CMS
    ContentArea,
    ContentBlockViewModel,

// EPi Add-on
    OptimizingBlockItem,
    VariationsViewModel

) {

    return declare([ContentArea], {

        // blockClass: [public] Class
        //      Used to inject block overlay class.
        blockClass: OptimizingBlockItem,

        // modelClass: [public] Class
        //      Used to inject model for this.
        modelClass: VariationsViewModel,

        dndSourceClass: declare([Target], { setHorizontal: function () { } }),

        // dndSourceSettings: [public] Json object
        //      Used to inject settings for dnd source.
        dndSourceSettings: { isSource: false },

        postMixInProperties: function () {
            this.inherited(arguments);

            this.model.setContentModel(this.contentModel);
        },

        postCreate: function () {
            this.inherited(arguments);

            domClass.add(this.domNode, "epi-overlay-optimizingBlockArea");

            // TODO: Trick to update statistic infor when editor wrapper cancel edit.
            // See EditingBase.js at _onWrapperCancel method
            this.watch("active", lang.hitch(this, function (name, oldValue, newValue) {
                if (newValue === false) {
                    this.model.setContentModel(this.contentModel);
                }
            }));
        },

        refresh: function () {
            this.inherited(arguments);

            this.model.setContentModel(this.contentModel);
        },

        isCreateLinkVisible: function () {
            // summary:
            //      Overidden mixin class, do not want show create link for optimizing block 
            // tags:
            //      protected

            return false;
        },

        _onDrop: function (data, source, nodes, isCopy) {
            // Overridden to get the sorting correct when rendering the update

            var model = this.model,
                target = this._source;

            // If the drag source item and drag target item are the same node then return since
            // we don't want to move if the node is dropped on itself.
            if (target.anchor === target.targetAnchor) {
                return;
            }
            
            // Normalize the data to an array.
            data = lang.isArray(data) ? data : [data];

            model.modify(function () {
                array.forEach(data, function (item) {
                    var block = new ContentBlockViewModel(item.data);
                    model.addChild(block);
                });
            });
        }
    });
});