﻿define([
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
// epi
    "epi",
    "epi/_Module",
    "epi/routes"
],

function (
// dojo
    declare,
    lang,

// epi
    epi,
    _Module,
    routes
) {

    return declare([_Module], {

        initialize: function () {
            // summary:
            //		Initialize module

            this.inherited(arguments);

            // Initialize data stores
            this._initializeStores();
        },

        _initializeStores: function () {
            // summary:
            //      Initialize data stores

            var registry = this.resolveDependency("epi.storeregistry"),
            light = registry.create("episerver.cms.addons.blocks", this._getRestPath("optimizingblock"), { id: "contentLink" });
        },

        _getRestPath: function (name) {
            return routes.getRestPath({ moduleArea: "episerver.cms.addons.blocks", storeName: name });
        }
    });
});