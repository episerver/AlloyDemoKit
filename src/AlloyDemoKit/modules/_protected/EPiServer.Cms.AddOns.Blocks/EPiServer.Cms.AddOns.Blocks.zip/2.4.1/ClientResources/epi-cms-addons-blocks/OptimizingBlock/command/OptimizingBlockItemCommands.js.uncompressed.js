define("epi-cms-addons-blocks/OptimizingBlock/command/OptimizingBlockItemCommands", [
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/Stateful",
    "dijit/Destroyable",

    "epi/shell/command/_CommandProviderMixin",

    "epi-cms/contentediting/command/BlockRemove",
    "epi-cms/contentediting/command/BlockEdit"

], function (array, declare, Stateful, Destroyable, _CommandProviderMixin, RemoveCommand, EditCommand) {

    return declare([Stateful, Destroyable, _CommandProviderMixin], {
        // summary:
        //      Class for declaring commands for OptimizingBlockItem.
        // tags:
        //      internal

        commands: null,

        constructor: function () {
            this.commands = [
                new EditCommand(),
                new RemoveCommand()
            ];

            this.commands.forEach(function (command) {
                this.own(command);
            }, this);
        },

        _modelSetter: function (model) {
            this.model = model;

            array.forEach(this.commands, function (command) {
                command.set("model", model);
            });
        }
    });
});
