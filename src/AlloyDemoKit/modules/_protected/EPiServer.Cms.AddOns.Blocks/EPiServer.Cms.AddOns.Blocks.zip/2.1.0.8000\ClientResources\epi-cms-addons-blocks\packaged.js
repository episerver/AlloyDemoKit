﻿define([
        "epi-cms-addons-blocks/BlocksModule",
        "epi-cms-addons-blocks/OptimizingBlock/VariationsEditor",
        "epi-cms-addons-blocks/OptimizingBlock/OptimizingBlockArea"
    ], 1);