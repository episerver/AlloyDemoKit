require({cache:{
'url:epi-cms-addons-blocks/OptimizingBlock/templates/StatisticInfo.html':"﻿<div class=\"epi-optimizing-statistic\">\r\n    <ul data-dojo-attach-point=\"containerNode\"></ul>\r\n</div>\r\n"}});
﻿define("epi-cms-addons-blocks/OptimizingBlock/StatisticInfo", [
// Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-construct",

// Dijit
    "dijit/_Widget",
    "dijit/_TemplatedMixin",

// EPi Framework
    "epi/datetime",
    "epi/shell/widget/_ModelBindingMixin",

// Resources
    "dojo/text!./templates/StatisticInfo.html",
    "epi/i18n!epi/cms/nls/episerver.cms.addons.optimizingblock.statistic"
],

function (
// Dojo
    declare,
    lang,
    domConstruct,

// Dijit
    _Widget,
    _TemplatedMixin,

// EPi Framework
    epiDate,
    _ModelBindingMixin,

// Resources
    template,
    res

) {

    return declare([_Widget, _TemplatedMixin, _ModelBindingMixin], {
        // summary:
        //      A widget to display statistic information, internal used in VariantBlockEditor

        // templateString: [public] String
        //      Template for this widget (StatisticInfo.html)
        templateString: template,

        // statisticItemTemplate: [public] String
        //      A template for each item (include: Boost, Probability, ViewCount, GoalCount)
        statisticItemTemplate:
            '<li>\
                <div class="content">\
                    <div class="header">{title}</div>\
                    <div class="description">{description}</div>\
                </div>\
            </li>',

        // model: [public] Object
        //      Model for this widget (StatisticInfoViewModel)
        model: null,

        _setModelAttr: function (value) {
            // summary:
            //      Override method from _ModelBindingMixin to clear dom first.

            domConstruct.empty(this.containerNode);
            this.inherited(arguments);
        },

        modelBindingMap: {
            "boostValue": ["boostValue"],
            "probability": ["probability"],
            "viewsCount": ["viewsCount"],
            "goalCount": ["goalCount"]
        },

        _setBoostValueAttr: function (value) {
            // summary:
            //      Render UI for boost item.

            if (value === null) {
                return;
            }

            var title = res.boostvalue.title.betters.replace("{0}", value);
            if (value === 0) {
                title = res.boostvalue.title.least;
            } else if (value === 1) {
                title = res.boostvalue.title.marginally;
            }

            var html = lang.replace(this.statisticItemTemplate, {
                title: title,
                description: res.boostvalue.description
            });
            domConstruct.place(html, this.containerNode);
        },

        _setProbabilityAttr: function (value) {
            // summary:
            //      Render UI for probability item.

            if (value === null) {
                return;
            }

            var percent = value,
                title = res.probability.title
                            .replace("{0}", percent)
                            .replace("{1}", "100"),
                html = lang.replace(this.statisticItemTemplate, {
                    title: title,
                    description: res.probability.description
                });

            domConstruct.place(html, this.containerNode);
        },

        _setViewsCountAttr: function (value) {
            // summary:
            //      Render UI for view count item.

            if (value === null) {
                return;
            }

            var html;
            if (!value) {

                html = lang.replace(this.statisticItemTemplate, {
                    title: res.never.exposure,
                    description: ""
                });

            } else {

                var des = res.exposure.replace("{0}", epiDate.toUserFriendlyString(this.model.exposureDate));

                html = lang.replace(this.statisticItemTemplate, {
                    title: value,
                    description: des
                });

            }

            domConstruct.place(html, this.containerNode);
        },

        _setGoalCountAttr: function (value) {
            // summary:
            //      Render UI for goal count item.

            if (value === null) {
                return;
            }

            var html;
            if (!value) {

                html = lang.replace(this.statisticItemTemplate, {
                    title: res.never.conversion,
                    description: ""
                });

            } else {

                html = lang.replace(this.statisticItemTemplate, {
                    title: value,
                    description: res.conversion
                });

            }

            domConstruct.place(html, this.containerNode);
        }
    });
});