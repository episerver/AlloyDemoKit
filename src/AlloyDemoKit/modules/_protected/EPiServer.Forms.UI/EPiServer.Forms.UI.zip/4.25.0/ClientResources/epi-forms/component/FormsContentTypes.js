require({
  cache: {
    'url:epi-forms/component/templates/FormsContentTypes.html': "﻿<section class=\"epi-forms-contentTypes\">\n    <div data-dojo-attach-point=\"layoutContainer\" data-dojo-type=\"dijit/layout/BorderContainer\" data-dojo-props=\"gutters: false, livesplitters: false\">\n        <div class=\"epi-forms-contentTypeContainer\" data-dojo-attach-point=\"stackContainer\" data-dojo-type=\"dijit/layout/StackContainer\" data-dojo-props=\"region: 'center'\">\n            <div data-dojo-attach-point=\"contentTypeList\" data-dojo-type=\"epi-forms/widget/FormsContentTypeList\"></div>\n        </div>\n    </div>\n</section>"
  }
});

define("epi-forms/component/FormsContentTypes", [// dojo
"dojo/_base/declare", "dojo/_base/lang", "dojo/when", // dijit
"dijit/_TemplatedMixin", "dijit/_WidgetsInTemplateMixin", "dijit/layout/_LayoutWidget", "dijit/layout/BorderContainer",
/* Used in template */
"dijit/layout/StackContainer",
/* Used in template */
// epi
"epi/shell/widget/_ModelBindingMixin", "epi/shell/widget/layout/_ComponentWrapper", "epi/shell/TypeDescriptorManager", "epi-cms/_ContentContextMixin", "epi-cms/core/ContentReference", // epi-addons
"epi-forms/component/FormsContentTypesViewModel", "epi-forms/ModuleSettings", "epi-forms/widget/FormsContentTypeList",
/* Used in template */
// templates
"dojo/text!./templates/FormsContentTypes.html"], function ( // dojo
declare, lang, when, // dijit
_TemplatedMixin, _WidgetsInTemplateMixin, _LayoutWidget, BorderContainer,
/*Used in template*/
StackContainer,
/*Used in template*/
// epi
_ModelBindingMixin, _ComponentWrapper, TypeDescriptorManager, _ContentContextMixin, ContentReference, // epi-addons
FormsContentTypesViewModel, ModuleSettings, FormsContentTypeList,
/*Used in template*/
// templates
template) {
  // module:
  //      epi-forms/component/FormsContentTypes
  // summary:
  //      EPiServer Forms - Content Types component
  // tags:
  //      public
  return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin, _ModelBindingMixin, _ContentContextMixin], {
    // modelType: [public]
    //
    modelType: FormsContentTypesViewModel,
    // templateString: [public] String
    //
    templateString: template,
    modelBindingMap: {
      actualParentLink: ["actualParentLink"],
      allowedTypes: ["allowedTypes"],
      createAsLocalAsset: ["createAsLocalAsset"],
      requestedType: ["requestedType"],
      restrictedTypes: ["restrictedTypes"]
    },
    _setActualParentLinkAttr: function _setActualParentLinkAttr(
    /*String*/
    actualParentLink) {
      // summary:
      //      Set actual parent link
      // actualParentLink: [String]
      //
      // tags:
      //      private
      this.contentTypeList.set("parentLink", actualParentLink);
    },
    _setAllowedTypesAttr: function _setAllowedTypesAttr(
    /*Array*/
    allowedTypes) {
      // summary:
      //      Set the allowed types
      // allowedTypes: [Array]
      //
      // tags:
      //      private
      this.contentTypeList.set("allowedTypes", allowedTypes);
    },
    _setCreateAsLocalAssetAttr: function _setCreateAsLocalAssetAttr(
    /*Boolean*/
    createAsLocalAsset) {
      // summary:
      //      Reset breadcrumb in case createAsLocalAsset had updated its value
      // createAsLocalAsset: [Boolean]
      //      TRUE if a new content will be create as a local asset
      // tags:
      //      private
      this._set("createAsLocalAsset", createAsLocalAsset);

      this.contentTypeList.set("localAsset", createAsLocalAsset);
    },
    _setRequestedTypeAttr: function _setRequestedTypeAttr(
    /*String*/
    requestedType) {
      // summary:
      //      Set requested type attribute
      // requestedType: [String]
      //
      // tags:
      //      private
      this.contentTypeList.set("requestedType", requestedType);
    },
    _setRestrictedTypesAttr: function _setRestrictedTypesAttr(
    /*Array*/
    restrictedTypes) {
      // summary:
      //      Set the restricted types
      // restrictedTypes: [Array]
      //
      // tags:
      //      private
      this.contentTypeList.set("restrictedTypes", restrictedTypes);
    },
    _updateViewForBlockDataAndLocalAsset: function _updateViewForBlockDataAndLocalAsset(content) {
      // summary:
      //      Call update view with default values
      // tags:
      //      private
      this.updateView({
        parent: content,
        createAsLocalAsset: true,
        requestedType: "episerver.core.blockdata"
      });
    },
    postMixInProperties: function postMixInProperties() {
      // summary:
      //      Post properties mixin handler.
      //      Set up model and resource for template binding.
      // tags:
      //      protected
      this.inherited(arguments);
      this.model = new this.modelType();
    },
    postCreate: function postCreate() {
      // summary:
      //      Post widget creation handler.
      // tags:
      //      protected
      this.inherited(arguments); // only get current content if the current context is the content data
      // otherwise we will get the "Not a content data" error at the client when we switch to other context such as the comparing view of  the language manager

      when(this.getCurrentContext(), lang.hitch(this, function (ctx) {
        if (!this._isContentContext(ctx)) {
          return;
        }

        when(this.getCurrentContent(), lang.hitch(this, function (currentContent) {
          this._updateViewForBlockDataAndLocalAsset(currentContent);
        }));
      }));
    },
    contentContextChanged: function contentContextChanged(ctx, callerData) {
      // summary:
      //      Called when the currently loaded content changes. I.e. a new content data object is loaded into the preview area.
      // tags:
      //      protected
      // when context changed, we need to refresh the form element gadget
      // the data was reset when we switch to other context so we need to update them as soon as we switch back
      when(this.getCurrentContent(), lang.hitch(this, function (currentContent) {
        this._updateViewForBlockDataAndLocalAsset(currentContent);

        this.contentTypeList.refresh();
      }));

      this._toggleComponentWrapper(ctx);
    },
    layout: function layout() {
      // summary:
      //      Layout the widget.
      //      Set the widget's size to the top layout container.
      // tags:
      //      protected
      if (this._started) {
        this.layoutContainer.resize(this._containerContentBox || this._contentBox);
      }
    },
    updateView: function updateView(
    /*Object*/
    data) {
      // summary:
      //
      // data: [Object]
      //
      // tags:
      //      public
      // content can only be created when it has parent and requestedType (when creating via New Page, Block buttons)
      // or content can be created when it has contentData and languageBranch (when creating via Translate notification)
      // if incoming data doesn't have parent and requestedType then no need to update the view & model.
      if (data && (data.parent && data.requestedType || data.contentData && data.languageBranch)) {
        when(this.model.update(data), lang.hitch(this, this.layout), function (err) {
          // eslint-disable-next-line no-console
          console.log(err);
        });
      }

      when(this.getCurrentContext(), lang.hitch(this, function (currentContext) {
        this._toggleComponentWrapper(currentContext);
      }));
    },
    _toggleComponentWrapper: function _toggleComponentWrapper(
    /*Object*/
    context) {
      // summary:
      //      Toggle the display of the component wrapper widget
      // context: [Object]
      //      Current context object
      // tags:
      //      private
      var componentWrapper = this._getComponentWrapper();

      if (componentWrapper) {
        componentWrapper.set("open", TypeDescriptorManager.isBaseTypeIdentifier(context.dataType, ModuleSettings.formContainerContentType));

        componentWrapper._header.toggleButton.set("checked", !componentWrapper.open);
      }
    },
    _getComponentWrapper: function _getComponentWrapper() {
      // summary:
      //      Gets component wrapper widget
      // returns: [Object]
      //      An instance of _ComponentWrapper class
      // tags:
      //      private
      var parent = this.getParent();

      while (parent && !(parent instanceof _ComponentWrapper)) {
        parent = parent.getParent();
      }

      return parent;
    }
  });
});