define("epi-forms/WithPlaceHolderFieldFactory", ["dojo/_base/declare", "dojo/Stateful", "dojo/dom-construct", "dojo/dom-class", "dojo/on", "dojo/aspect", // dijit
"dijit/Destroyable", // epi
// eslint-disable-next-line @episerver/cms/no-internal-episerver-apis
"epi/shell/form/formFieldRegistry", // epi-forms
"epi-forms/contentediting/editors/_PlaceHolderMixin", "epi-forms/widget/PlaceHolderDropDownButton"], function (declare, Stateful, domConstruct, domClass, on, aspect, // dijit
Destroyable, // epi
formFieldRegistry, // epi-forms
_PlaceHolderMixin, PlaceHolderDropDownButton) {
  /// summary:
  //      Create and attach form place-holder dropdown button to a editor
  return declare([Stateful, _PlaceHolderMixin, Destroyable], {
    _onPlaceHolderItemSelected: function _onPlaceHolderItemSelected(
    /*Object*/
    item) {
      this._setTokenKeyFor(item, ["_setTokenKeyForTinyMCE", "_setTokenKeyForTextBox"]);
    },
    placeHolderPropertiesFactory: function placeHolderPropertiesFactory(widget, parent) {
      var defaultFactory = formFieldRegistry.get(formFieldRegistry.type.field, "");
      var wrapper = defaultFactory(widget, parent);

      if (!widget.params.supportPlaceHolder || widget.params.readOnly) {
        return wrapper;
      }

      var placeHolderDropDownButton = new PlaceHolderDropDownButton({
        readOnly: widget.readOnly,
        modelTypeName: widget.extendedWidgetModelType
      });
      var dropDownWrapper = domConstruct.create("div");
      domConstruct.place(placeHolderDropDownButton.domNode, dropDownWrapper);
      domClass.add(dropDownWrapper, "epi-forms-paragraphTextCommands ui-helper-clearfix");
      domClass.add(placeHolderDropDownButton.domNode, "epi-floatRight");
      domConstruct.place(dropDownWrapper, widget.domNode, "first");
      aspect.after(placeHolderDropDownButton, "onItemSelected", function (item) {
        this._setLastFocusedTarget(widget);

        this._onPlaceHolderItemSelected(item);
      }.bind(this), true);
      on(widget, "focus", function () {
        this._setLastFocusedTarget(widget);
      }.bind(this));
      return wrapper;
    },
    _setLastFocusedTarget: function _setLastFocusedTarget(widget) {
      var isTinyMCE = widget.baseClass.indexOf("epiTinyMCEEditor") !== -1;
      this.set("lastFocusedTarget", isTinyMCE ? widget.editor : widget.id);
    },
    createFactory: function createFactory() {
      return {
        type: formFieldRegistry.type.field,
        hint: "epiforms-placeholder-field",
        factory: this.placeHolderPropertiesFactory.bind(this)
      };
    }
  });
});