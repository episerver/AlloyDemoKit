define("epi-forms/_UtilityMixin", [// dojo
"dojo/_base/declare", "dojo/_base/lang", "dojo/Deferred"], function ( // dojo
declare, lang, Deferred) {
  // module:
  //      epi-forms/_UtilityMixin
  // summary:
  //      Shared functions for entire application
  // tags:
  //      protected
  return declare([], {
    getInstanceFromType: function getInstanceFromType(
    /*String*/
    type,
    /*Object*/
    typeParams) {
      // summary:
      //      Get an instance of object from its type string.
      // type: [String]
      //      Object type.
      // typeParams: [Object]
      //      Initialize params used to create this instance.
      // returns: [Object]
      //      An instance of 'dojo/Deferred'
      // tags:
      //      public
      var deferred = new Deferred();

      if (!type) {
        deferred.resolve(null);
        return deferred;
      }

      require([type], lang.hitch(this, function (typeClass) {
        !typeParams && (typeParams = {});
        deferred.resolve(new typeClass(typeParams));
      }));

      return deferred;
    }
  });
});