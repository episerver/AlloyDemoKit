define([
    // dojo 
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/on",
    "dojo/dom-class",
    "dojo/when",

    // epi-addons 
    "epi-forms/contentediting/editors/ChoiceWithEditor"
],
    function (
        // dojo 
        array,
        declare,
        lang,
        on,
        domClass,
        when,
        // epi-addons 
        ChoiceWithEditor
    ) {

        // module: 
        //      epi-forms/contentediting/editors/ChoiceWithNumberSpinnerEditor
        // summary: 
        //      RadioButton|CheckBox selector with a type of the NumberSpinner widget. 
        // tags: 
        //      protected 

        return declare([ChoiceWithEditor], {
            // ======================================================================= 
            // Public, overrided stubs 
            // ======================================================================= 

            postMixInProperties: function () {

                this.inherited(arguments);

                !this.itemParams && (this.itemParams = {});

                lang.mixin(this.itemParams, {
                    extendedWidgetOptions: this.extendedWidgetOptions,
                    shortErrorMessage: this.shortErrorMessage,
                    customizationMinValue: this.customizationMinValue,
                    customizationMaxValue: this.customizationMaxValue,
                    name: this.groupName
                });
            },

            _buildItemParams: function (/*Object*/item) {
                // tags:
                //      override

                var itemParams = this.inherited(arguments);

                lang.mixin(itemParams, {
                    parent: this
                });

                return itemParams;
            },

            // ======================================================================= 
            // Protected stubs 
            // ======================================================================= 
            _setValueAttr: function (/*String*/value) {
                // summary: 
                //      Calculates the period string 
                // value: [String] 
                //       
                // tags: 
                //      protected, extensions 

                this.inherited(arguments);

                if (!value) {
                    return;
                }

                // enable textbox for the first loading in case customization
                var isExtended = this._isIncludedExtendedWidget(this.extendedWidgetOptions, this.value);
                // this code makes sure item widgets loaded before editor initialization
                this._toggleOnChangeActive(false);
                when(this.get("itemWidgets")).then(function (widgets) {
                    if (!widgets) {
                        return;
                    }
                    array.forEach(widgets, function (widget) {
                        if (!widget) {
                          return;
                        }

                        var isEnabled = this.selectorType === "multiple" ? widget._extendedWidget && widget._choiceControl.get("checked") : widget._extendedWidget && isExtended;
                        if (widget._extendedWidget) {
                            widget.set("extendedWidgetValue", { value: value });
                            widget._extendedWidget.set("disabled", !isEnabled);
                            widget._calculateSelectorValue();
                        }

                        var itemWidgetValue = value.split(this._recordFieldSeparator)[0];
                        if (widget.get("selectorValue").indexOf(itemWidgetValue) === 0) {
                            widget._selector.set("checked", true);
                        }

                    });
                }.bind(this));

                this._toggleOnChangeActive(true);
            },

            _setupItemWidget: function (itemWidget) {

                // summary:
                //    Override base method to add a class keeping widget label text inline
                //    Attach click event to radio button to disable/enable textbox accordingly
                // tags
                //      override
                this.inherited(arguments);

                var labelDom = itemWidget.selectorLabel;

                if (labelDom) {
                    domClass.add(labelDom, 'epi-forms-itemWidget-retentionperiodLabel');
                }
                on(itemWidget, "_itemWidgetControlClick", lang.hitch(this, function () {
                    this._toggleItemWidgetTextBox(itemWidget);
                }));
            },
            onBlur: function(){
                // summary:
                //    Override base method to do nothing
                //    This change fix an issue due to onBlur event triggered will clear textbox data and revert option to custom option
                // tags
                //      override
            },
            // ======================================================================= 
            // Private stubs 
            // ======================================================================= 
            _toggleItemWidgetTextBox: function (widget) {
                // summary:
                //      Disable/Enable retention textbox according to radio button value
                // tags:
                //      private

                if (!widget) {
                    return;
                }

                // in case multiple selection, go throuth the item widgets, enable textbox of checked selections
                var self = this;
                array.forEach(this._itemWidgets, function (item) {
                    if (!item) {
                        return;
                    }
                    var isEnabled = self.selectorType === "multiple" ? item._choiceControl.get("checked") : widget._extendedWidget !== undefined;
                    if (item._extendedWidget) {
                        item._extendedWidget.set('disabled', !isEnabled);
                        isEnabled && item._extendedWidget.focus();
                        item._calculateSelectorValue();
                    }
                });
            },

            _isIncludedExtendedWidget: function (extendedWidgetOptions, value) {
                // summary:
                //      - To check whether value is the exteded widget
                //      - The extendedWidgetOptions contains a list of options so we need to check if value start with one of it's item value
                // tags:
                //      private

                if (!value) {
                  return;
                }

                var check = false;
                array.forEach(extendedWidgetOptions, function (item) {
                    if (value.indexOf(item) === 0) {
                        check = true;
                    }
                });
                return check;
            }
        });
    });