require({cache:{
'url:epi-languagemanager/widget/templates/CreateLanguageBranchSelector.html':"﻿<div class=\"epi-menu--inverted\">\r\n    <div class=\"epi-dijitTooltipContainer\">\r\n        <div class=\"epi-invertedTooltip\">\r\n            <div class=\"epi-tooltipDialogTop\">\r\n                <span data-dojo-attach-point=\"header\"></span>\r\n                <div class=\"dijitTooltipConnector\"></div>\r\n            </div>\r\n        </div>\r\n        <div class=\"epi-tooltipDialogContent--max-height\">\r\n            <table class=\"dijitReset dijitMenu epi-tooltipDialogMenu epi-menuInverted epi-mediumMenuItem\" style=\"width: 100%\" cellspacing=\"0\">\r\n                <tbody data-dojo-attach-point=\"containerNode\"></tbody>\r\n            </table>\r\n        </div>\r\n    </div>\r\n</div>"}});
﻿define("epi-languagemanager/widget/CreateLanguageBranchSelector", [
// Dojo
    "dojo/_base/declare",
    "dojo/_base/array",
    "dojo/_base/lang",
    "dojo/when",

// Dojox
    "dojox/html/entities",

// Dijit
    "dijit/registry",
    "dijit/MenuItem",
    "dijit/_TemplatedMixin",

// EPi CMS
    "epi-cms/widget/SelectorMenuBase",

// Resouces
    "dojo/text!./templates/CreateLanguageBranchSelector.html"

], function (
// Dojo
    declare,
    array,
    lang,
    when,

// Dojox
    htmlEntities,

// Dijit
    registry,
    MenuItem,
    _TemplatedMixin,

// EPi CMS
    SelectorMenuBase,

// Resouces
    template
) {
    // module:
    //      "epi-languagemanager/widget/CreateLanguageBranchSelector"
    // summary:
    //      Used for selecting create language branch options for a page

    return declare([SelectorMenuBase, _TemplatedMixin], {

        // templateString: [protected] String
        //      Html template for the slector
        templateString: template,

        itemClass: MenuItem,

        _setHeadingTextAttr: function (text) {
            this._set("headingText", text);
            this.header.innerHTML = text;
        },

        _setItemsAttr: function (items) {
            this._set("items", items);
            this._setup();
        },

        _setup: function () {

            if(!this.items) {
                return;
            }

            //Destroy the old menu items
            this._removeMenuItems();

            array.forEach(this.items, function(itemData) {

                var menuItem = new this.itemClass({
                    label: htmlEntities.encode(itemData.label),
                    value: itemData.value,
                    onClick: lang.hitch(this, function (evt) {
                        var target = evt.srcElement || evt.target;
                        if (registry.getEnclosingWidget(target) instanceof this.itemClass) {
                            this.onItemSelected(menuItem.value);
                        }
                    })
                });

                if (itemData.disabled === 'disabled') {
                    menuItem.set('disabled', 'disabled');
                }

                this.addChild(menuItem);
            }, this);
        },

        onItemSelected: function (item) {
            // summary:
            //   Raised when a item is selected, it will fire the view setting change.
            //
            // tags:
            //    event
        },

        _removeMenuItems: function () {
            var items = this.getChildren();
            items.forEach(function (item) {
                this.removeChild(item);
                item.destroy();
            }, this);
        }

    });
});