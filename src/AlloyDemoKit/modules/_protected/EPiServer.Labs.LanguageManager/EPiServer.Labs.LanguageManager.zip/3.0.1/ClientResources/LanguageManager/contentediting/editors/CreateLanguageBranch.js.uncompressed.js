﻿define("epi-languagemanager/contentediting/editors/CreateLanguageBranch", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/topic",
// epi
    "epi/Url",
    "epi-cms/contentediting/CreateContent",
    "epi-cms/contentediting/viewmodel/CreateLanguageBranchViewModel"
],

function (
// dojo
    declare,
    lang,
    topic,
// epi
    Url,
    CreateContent,
    CreateLanguageBranchViewModel
) {

    return declare([CreateContent], {
        modelType: CreateLanguageBranchViewModel,

        _setCreateMode: function () {
            // summary:
            //      Set create new content state for current mode
            // tags:
            //      protected extension

            lang.mixin(this._contextService.currentContext, {
                currentMode: "translate"
            });
        },

        _changeContext: function (contentLink) {
            // summary:
            //    Redirect the newly created content to editmode with language context.
            //
            // contentLink:
            //    The content link.

            var currentItemLanguage = this.model.languageBranch;
            var uri = "#context=epi.cms.contentdata:///" + contentLink,
                currentUrl = new Url(window.location.href),
                currentUrlPath = currentUrl.scheme + "://" + currentUrl.authority + currentUrl.path,
                reloadUrl = currentUrlPath + "?language=" + currentItemLanguage + uri;

            window.location.assign(reloadUrl);
        },
    });

});