﻿define("epi-languagemanager/LanguageManagerModule", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/topic",
    "dojo/when",
// epi
    "epi/_Module",
    "epi/dependency",
    "epi/routes",

// epi-cms
    "epi-cms/project/viewmodels/_ProjectViewModel",

// language manager
    "epi-languagemanager/ModuleSettings",
    "epi-languagemanager/component/command/DownloadTranslationPackage",
    "epi-languagemanager/component/command/UploadTranslationPackages",

    "epi-languagemanager/component/viewmodel/UploadTranslationPackagesViewModel"
],
function (
// dojo
    declare,
    lang,
    aspect,
    topic,
    when,

// epi
    _Module,
    dependency,
    routes,

// epi-cms
    _ProjectViewModel,

// language manager
    ModuleSettings,
    DownloadTranslationPackage,
    UploadTranslationPackages,

    UploadTranslationPackagesViewModel
) {

    return declare([_Module], {

        // _settings: [private] Object
        //      Information which sent by LanguageManager module (in module.config file). We can read helpPath, moduleDependencies, routes, ... from here
        _settings: null,

        constructor: function (settings) {
            this._settings = settings;
        },

        initialize: function () {
            // summary:
            //      Initialize module
            //
            // description:
            //      Dependencies registered by this module are: 'LanguageManage application'

            this.inherited(arguments);

            declare.safeMixin(ModuleSettings, this._settings);

            // Initialize stores
            var registry = this.resolveDependency("epi.storeregistry"),
                route = this._getRestPath("language");

            registry.add("epi-languagemanager.settings", this._settings);
            registry.create("epi-languagemanager.language", route, { idProperty: "id" });
            // We need to create projectItemStore ourself to inject X-EPiContentLanguage as header param later
            registry.create("epi-languagemanager.project.item", this._getCMSRestPath("project-item"));

            this._togglePinnablePanes();
            this._injectCommandsToProjectView();
        },

        _getCMSRestPath: function (name) {
            return routes.getRestPath({ moduleArea: "cms", storeName: name });
        },

        _getRestPath: function (name) {
            // summary:
            //      Get the rest path to a specified store.
            // prameters:
            //      name: The name of the store to get.
            // tags:
            //      private

            return routes.getRestPath({ moduleArea: "EPiServer.Labs.LanguageManager", storeName: name });
        },

        _togglePinnablePanes: function () {
            // summary:
            //      Restore states (before language manager compare mode enabled) of the pinnable panes (tools, navigation).
            // tags:
            //      private

            topic.subscribe("/epi/shell/action/viewchanged", lang.hitch(this, function (type, args, data) {
                if (type !== "epi-languagemanager/component/CompareEditing") {
                    // Get saved pinnable states of the tools and navigation panes and then restore them.
                    var profile = dependency.resolve("epi.shell.Profile");
                    when(profile.get("addons-language-manager-settings"), function (settings) {
                        if (!settings) {
                            return;
                        }

                        topic.publish("/epi/layout/pinnable/navigation/toggle", settings.navigationPinned);
                        topic.publish("/epi/layout/pinnable/tools/toggle", settings.toolsPinned);
                    });
                }
            }));
        },

        _injectCommandsToProjectView: function () {
            // summary:
            //      HACK: inject menu items [Download Translation Package] and [Upload Translation Package] into Project view
            // tags:
            //      private

            var exportingUrl = this._settings.exportingUrl;

            var orgMethod = _ProjectViewModel.prototype.postscript;

            lang.mixin(_ProjectViewModel.prototype, {
                postscript: function () {

                    orgMethod.call(this);

                    var commands = this.get("commands");
                    commands.push(
                        new DownloadTranslationPackage({
                            category: "publishmenu",
                            model: this,
                            sortOrder: 400,
                            exportingUrl: exportingUrl
                        }),
                        new UploadTranslationPackages({
                            category: "publishmenu",
                            model: new UploadTranslationPackagesViewModel(),
                            sortOrder: 500
                        })
                    );
                }
            });
        }
    });

});