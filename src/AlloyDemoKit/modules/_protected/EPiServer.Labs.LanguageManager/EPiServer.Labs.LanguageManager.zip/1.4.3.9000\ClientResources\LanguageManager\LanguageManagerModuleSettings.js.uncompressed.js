﻿define("epi-languagemanager/LanguageManagerModuleSettings", [],
function () {

    // module:
    //      epi-languagemanager/LanguageManagerModuleSettings
    // summary:
    //      Module settings for Language Manager.
    // tags:
    //      public

    return {


    };

});