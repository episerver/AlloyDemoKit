//>>built
define("epi-languagemanager/LanguageManagerModuleSettings",[],function(){return {};});