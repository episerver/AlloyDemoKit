﻿define("epi-languagemanager/component/command/_ExtensionContextMixin", [
// Dojo base
    "dojo/_base/declare",

// EPi CMS
    "epi-cms/ApplicationSettings",
    "epi-cms/core/ContentReference"

], function (
// Dojo base
    declare,

// Epi CMS
    ApplicationSettings,
    ContentReference

    ) {


    return declare(null, {

        isWastebasket: function(contentData) {
            // summary:
            //		Check the current context is Wasterbasket page or not.
            // contentData: [Object]
            //      The content data model
            // tags:
            //		protected

            return contentData && new ContentReference(contentData.contentLink).id == ApplicationSettings.wastebasketPage;
        },

        isRoot: function (contentData) {
            // summary:
            //		Check the current context is Root page or not.
            // contentData: [Object]
            //      The content data model
            // tags:
            //		protected

            return contentData && new ContentReference(contentData.contentLink).id == ApplicationSettings.rootPage;
        }
    });
});
