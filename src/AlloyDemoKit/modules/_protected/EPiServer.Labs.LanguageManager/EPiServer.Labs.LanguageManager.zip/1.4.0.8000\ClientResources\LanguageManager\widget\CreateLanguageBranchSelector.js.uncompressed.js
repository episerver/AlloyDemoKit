require({cache:{
'url:epi-languagemanager/widget/templates/CreateLanguageBranchSelector.html':"﻿<div class=\"epi-CreateLanguageBranchSelector\">\r\n    <div class=\"epi-tooltipDialogTop\">\r\n        <span data-dojo-attach-point=\"header\"></span>\r\n        <div data-dojo-attach-point=\"lastPublishedIcon\" class=\"dijitTooltipConnector\"></div>\r\n    </div>\r\n    <div class=\"epi-dropdownMenuContainer\">\r\n        <div data-dojo-type=\"dijit/Menu\" data-dojo-attach-point=\"menuNode\" contextMenuForWindow=\"false\" class=\"epi-DropDownMenu\">\r\n            <!--need a div to hold space to make the menu which contains buttons display correctly in IE9-->\r\n            <div style=\"font-size:0px;\">&nbsp;</div>\r\n        </div>\r\n    </div>\r\n</div>"}});
﻿define("epi-languagemanager/widget/CreateLanguageBranchSelector", [
// Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",

// Dojox
    "dojox/html/entities",

// Dijit
    "dijit/_FocusMixin",
    "dijit/form/Button",
    "dijit/Menu", // used in template
    "dijit/registry",

// EPi CMS
    "epi-cms/widget/_ItemSelectorBase",

// Resouces
    "dojo/text!./templates/CreateLanguageBranchSelector.html"

], function (
// Dojo
    declare,
    lang,

// Dojox
    htmlEntities,

// Dijit
    _FocusMixin,
    Button,
    Menu,
    registry,

// EPi CMS
    _ItemSelectorBase,

// Resouces
    template
) {

    // module:
    //      "epi-languagemanager/widget/CreateLanguageBranchSelector"
    // summary:
    //      Used for selecting create language branch options for a page

    return declare([_ItemSelectorBase, _FocusMixin], {

        // templateString: [protected] String
        //      Html template for the slector
        templateString: template,

        itemClass: Button,

        itemSettings: {
            _setSelected: function () { }
        },

        postscript: function () {
            this.inherited(arguments);
        },

        postCreate: function () {
            this.inherited(arguments);
        },

        _createMenuItem: function (/*Object*/item) {
            // summary:
            //    Create a menu item.
            //
            // item:
            //    The item to create menu item.
            //
            // tags:
            //    protected override
            
            var menuItem = new this.itemClass(lang.mixin(this.itemSettings, {
                label: htmlEntities.encode(item.label),
                value: item.value,
                onClick: lang.hitch(this, function (evt) {
                    if (registry.getEnclosingWidget(evt.currentTarget) instanceof this.itemClass) {
                        this._onItemSelected(menuItem);
                    }
                })
            }));

            if (item.disabled === 'disabled') {
                menuItem.set('disabled', 'disabled');
            }

            return menuItem;
        },

        _setHeaderAttr: function (value) {
            this.header.innerHTML = value;
        }
    });
});