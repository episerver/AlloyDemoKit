﻿define("epi-languagemanager/component/command/OpenLanguageSettings", [
    "dojo/_base/declare",
    "epi-cms/contentediting/ContentActionSupport",
    "epi-cms/contentediting/command/_LegacyDialogCommandBase",

// Language mangager
    "epi-languagemanager/component/command/_ExtensionContextMixin",

// Resource
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],

function (
    declare,
    ContentActionSupport,
    _LegacyDialogCommandBase,

// Language mangager
    _ExtensionContextMixin,

    res) {

    // TODO: listen close dialog event to refresh the gadget.

    return declare([_LegacyDialogCommandBase, _ExtensionContextMixin], {

        // label: [public] String
        //		The action text of the command to be used in visual elements.
        label: res.languagesettings,
        title: res.languagesettings,

        // category: [readonly] String
        //		A category which provides a hint about how the command could be displayed.
        category: "context",
        

        dialogPath: "Edit/LanguageSettings.aspx",
        raiseCloseEvent: true,

        postscript: function () {
            this.inherited(arguments);
        },
        
        _onModelChange: function () {
            // summary:
            //		Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //		protected

            var item = this.model.currentItemData;
            if (!item || !this.model.hasAnyLanguageAvailable) {
                this.set("canExecute", false);

                return;
            }

            var languageSettings = this.model.contentData.capabilities.languageSettings,
                // Do nothing (command disabled) if the content is Wastebasket or Root or has been deleted
                disabled = this.isWastebasket(this.model.contentData) || this.isRoot(this.model.contentData) || this.model.contentData.isDeleted;

            this.set("canExecute",
                item.canActivate
                && languageSettings
                && !disabled
            );
        }
    });
});
