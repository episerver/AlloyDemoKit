//>>built
define("epi-languagemanager/nls/packaged_da",{"dojox/form/nls/Uploader":{"label":"Vælg filer...","_localized":{}}});