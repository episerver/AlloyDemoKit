//>>built
define("epi-languagemanager/nls/packaged_tr",{"dojox/form/nls/Uploader":{"label":"Dosyaları Seç...","_localized":{}}});