//>>built
define("epi-languagemanager/nls/packaged_de",{"dojox/form/nls/Uploader":{"label":"Dateien auswählen...","_localized":{}}});