define('epi-languagemanager/nls/packaged_zh-tw',{
'dojox/form/nls/Uploader':{"label":"選取檔案...","_localized":{}}
});