define('epi-languagemanager/nls/packaged_nb',{
'dojox/form/nls/Uploader':{"label":"Velg filer...","_localized":{}}
});