//>>built
define("epi-languagemanager/nls/packaged_pt-br",{"dojox/form/nls/Uploader":{"label":"Selecione Arquivos...","_localized":{}}});