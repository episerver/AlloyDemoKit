define('epi-languagemanager/nls/packaged_nl-nl',{
'dojox/form/nls/Uploader':{"label":"Bestanden selecteren...","_localized":{}}
});