define('epi-languagemanager/nls/packaged_cs',{
'dojox/form/nls/Uploader':{"label":"Vybrat soubory...","_localized":{}}
});