﻿/* Collects all dependencies to be excluded when bundling */
define("epi-languagemanager/ExcludedDeps", [

    "dojo/store/Observable",
    "dojox/widget/Standby",
    "dgrid/OnDemandGrid",
    "dgrid/List",
    "dgrid/Selection",

    "epi/_Module",
    "epi/shell/Bootstrapper",
    "epi/shell/dgrid/util/misc",
    "epi/shell/command/_WidgetCommandProviderMixin",
    "epi/shell/widget/ContextMenu",

    "epi-cms/contentediting/ContentViewModel",
    "epi-cms/contentediting/EditToolbar",
    "epi-cms/contentediting/FormEditing",
    "epi-cms/contentediting/NotificationBar",
    "epi-cms/contentediting/command/_LegacyDialogCommandBase",
    "epi-cms/component/command/DeleteLanguageBranch"
], 1);