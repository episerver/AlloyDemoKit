define('epi-languagemanager/nls/packaged_ru',{
'dojox/form/nls/Uploader':{"label":"Выберите файлы...","_localized":{}}
});