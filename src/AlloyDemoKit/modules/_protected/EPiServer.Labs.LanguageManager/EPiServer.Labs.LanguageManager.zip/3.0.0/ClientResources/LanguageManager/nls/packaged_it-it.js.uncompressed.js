define('epi-languagemanager/nls/packaged_it-it',{
'dojox/form/nls/Uploader':{"label":"Seleziona file...","_localized":{}}
});