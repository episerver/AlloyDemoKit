//>>built
define("epi-languagemanager/nls/packaged_ko-kr",{"dojox/form/nls/Uploader":{"label":"파일 선택...","_localized":{}}});