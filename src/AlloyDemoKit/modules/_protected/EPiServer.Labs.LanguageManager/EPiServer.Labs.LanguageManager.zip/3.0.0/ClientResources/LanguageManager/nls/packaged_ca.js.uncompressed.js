define('epi-languagemanager/nls/packaged_ca',{
'dojox/form/nls/Uploader':{"label":"Selecciona fitxers...","_localized":{}}
});