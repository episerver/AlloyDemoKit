define('epi-languagemanager/nls/packaged_zh-cn',{
'dojox/form/nls/Uploader':{"label":"选择文件...","_localized":{}}
});