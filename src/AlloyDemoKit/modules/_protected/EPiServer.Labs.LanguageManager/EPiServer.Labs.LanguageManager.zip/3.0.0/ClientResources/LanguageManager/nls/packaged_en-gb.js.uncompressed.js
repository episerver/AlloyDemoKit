define('epi-languagemanager/nls/packaged_en-gb',{
'dojox/form/nls/Uploader':{"label":"Select Files...","_localized":{}}
});