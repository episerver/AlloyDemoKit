define('epi-languagemanager/nls/packaged_sv',{
'dojox/form/nls/Uploader':{"label":"Välj filer...","_localized":{}}
});