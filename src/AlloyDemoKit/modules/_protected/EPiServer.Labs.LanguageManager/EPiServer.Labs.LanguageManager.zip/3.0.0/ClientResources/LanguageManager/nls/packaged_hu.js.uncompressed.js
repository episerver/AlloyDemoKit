define('epi-languagemanager/nls/packaged_hu',{
'dojox/form/nls/Uploader':{"label":"Fájlok kiválasztása...","_localized":{}}
});