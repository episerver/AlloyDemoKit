//>>built
define("epi-languagemanager/nls/packaged_ja-jp",{"dojox/form/nls/Uploader":{"label":"ファイルの選択...","_localized":{}}});