//>>built
define("epi-languagemanager/nls/packaged_en-us",{"dojox/form/nls/Uploader":{"label":"Select Files...","_localized":{}}});