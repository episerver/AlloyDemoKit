define('epi-languagemanager/nls/packaged_ROOT',{
'dojox/form/nls/Uploader':{"label":"Select Files...","_localized":{"ar":1,"ca":1,"cs":1,"da":1,"de":1,"el":1,"es":1,"fi":1,"fr":1,"he":1,"hr":1,"hu":1,"it":1,"ja":1,"kk":1,"ko":1,"nb":1,"nl":1,"pl":1,"pt":1,"pt-pt":1,"ro":1,"ru":1,"sk":1,"sl":1,"sv":1,"th":1,"tr":1,"zh":1,"zh-tw":1}}
});