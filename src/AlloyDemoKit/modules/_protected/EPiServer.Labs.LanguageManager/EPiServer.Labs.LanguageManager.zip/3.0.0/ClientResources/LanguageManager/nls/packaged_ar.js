//>>built
define("epi-languagemanager/nls/packaged_ar",{"dojox/form/nls/Uploader":{"label":"تحديد ملفات...","_localized":{}}});