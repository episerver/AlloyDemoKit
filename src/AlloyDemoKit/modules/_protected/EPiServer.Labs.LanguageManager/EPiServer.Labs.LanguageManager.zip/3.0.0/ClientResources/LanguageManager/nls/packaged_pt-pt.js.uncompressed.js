define('epi-languagemanager/nls/packaged_pt-pt',{
'dojox/form/nls/Uploader':{"label":"Seleccionar ficheiros...","_localized":{}}
});