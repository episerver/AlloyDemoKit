define('epi-languagemanager/nls/packaged_es-es',{
'dojox/form/nls/Uploader':{"label":"Seleccionar archivos...","_localized":{}}
});