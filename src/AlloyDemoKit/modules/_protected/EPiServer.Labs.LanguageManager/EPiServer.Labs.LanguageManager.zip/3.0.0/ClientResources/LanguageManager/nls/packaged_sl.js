//>>built
define("epi-languagemanager/nls/packaged_sl",{"dojox/form/nls/Uploader":{"label":"Izberi datoteke ...","_localized":{}}});