define('epi-languagemanager/nls/packaged_sk',{
'dojox/form/nls/Uploader':{"label":"Vybrať súbory...","_localized":{}}
});