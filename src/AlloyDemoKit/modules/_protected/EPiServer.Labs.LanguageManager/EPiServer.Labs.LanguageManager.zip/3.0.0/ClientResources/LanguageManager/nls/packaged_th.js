//>>built
define("epi-languagemanager/nls/packaged_th",{"dojox/form/nls/Uploader":{"label":"เลือกไฟล์...","_localized":{}}});