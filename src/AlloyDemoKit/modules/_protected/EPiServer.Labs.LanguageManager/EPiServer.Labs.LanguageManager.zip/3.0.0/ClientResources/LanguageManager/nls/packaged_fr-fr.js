//>>built
define("epi-languagemanager/nls/packaged_fr-fr",{"dojox/form/nls/Uploader":{"label":"Sélectionner les fichiers...","_localized":{}}});