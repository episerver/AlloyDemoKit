define('epi-languagemanager/nls/packaged_he-il',{
'dojox/form/nls/Uploader':{"label":"בחירת קבצים...‏","_localized":{}}
});