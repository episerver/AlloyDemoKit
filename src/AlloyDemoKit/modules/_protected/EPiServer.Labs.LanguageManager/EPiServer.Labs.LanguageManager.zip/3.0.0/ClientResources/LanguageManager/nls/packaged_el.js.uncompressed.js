define('epi-languagemanager/nls/packaged_el',{
'dojox/form/nls/Uploader':{"label":"Επιλογή αρχείων...","_localized":{}}
});