//>>built
define("epi-languagemanager/nls/packaged_pl",{"dojox/form/nls/Uploader":{"label":"Wybierz pliki...","_localized":{}}});