//>>built
define("epi-languagemanager/nls/packaged_fi-fi",{"dojox/form/nls/Uploader":{"label":"Valitse tiedostot...","_localized":{}}});