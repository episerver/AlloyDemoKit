﻿define("epi-languagemanager/LanguageManagerModule", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/topic",
    "dojo/when",
// epi
    "epi/_Module",
    "epi/dependency",
    "epi/routes"
],
function (
// dojo
    declare,
    lang,
    topic,
    when,
// epi
    _Module,
    dependency,
    routes
) {

    return declare([_Module], {

        // _settings: [private] Object
        //      Information which sent by LanguageManager module (in module.config file). We can read helpPath, moduleDependencies, routes, ... from here
        _settings: null,

        constructor: function (settings) {
            this._settings = settings;
        },

        initialize: function () {
            // summary:
            //      Initialize module
            //
            // description:
            //      Dependencies registered by this module are: 'LanguageManage application'

            this.inherited(arguments);

            // Initialize stores
            var registry = this.resolveDependency("epi.storeregistry"),
                route = this._getRestPath("language");

            registry.create("epi-languagemanager.language", route, { idProperty: "id" });

            this._togglePinnablePanes();
        },

        _getRestPath: function (name) {
            // summary:
            //      Get the rest path to a specified store.
            // prameters:
            //      name: The name of the store to get.
            // tags:
            //      private

            return routes.getRestPath({ moduleArea: "EPiServer.Labs.LanguageManager", storeName: name });
        },

        _togglePinnablePanes: function () {
            // summary:
            //      Restore states (before language manager compare mode enabled) of the pinnable panes (tools, navigation).
            // tags:
            //      private

            topic.subscribe("/epi/shell/action/viewchanged", lang.hitch(this, function (type, args, data) {
                if (type !== "epi-languagemanager/component/CompareEditing") {
                    // Get saved pinnable states of the tools and navigation panes and then restore them.
                    var profile = dependency.resolve("epi.shell.Profile");
                    when(profile.get("addons-language-manager-settings"), function (settings) {
                        if (!settings) {
                            return;
                        }

                        topic.publish("/epi/layout/pinnable/navigation/toggle", settings.navigationPinned);
                        topic.publish("/epi/layout/pinnable/tools/toggle", settings.toolsPinned);
                    });
                }
            }));
        }

    });

});