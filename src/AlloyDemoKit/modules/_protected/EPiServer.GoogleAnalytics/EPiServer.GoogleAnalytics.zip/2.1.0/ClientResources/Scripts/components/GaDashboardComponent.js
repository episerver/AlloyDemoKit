﻿define([
    // Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",

    // GA
    "epi-googleanalytics/components/_GaComponentBase",

    // Resources
    "epi/i18n!epi/cms/nls/episerver.googleanalytics"
],
    function (
        // Dojo
        declare,
        lang,

        // GA
        _GaComponentBase,

        // Resources
        res
    ) {

        return declare([_GaComponentBase], {

            _initComponent: function (event, gadgetInstance) {
                // summary:
                //    Init dashboard component.
                //
                // tags:
                //    overide.

                this.inherited(arguments);
                epi.googleAnalytics.initDashboardGadget(event, gadgetInstance);
            }
        });
    });