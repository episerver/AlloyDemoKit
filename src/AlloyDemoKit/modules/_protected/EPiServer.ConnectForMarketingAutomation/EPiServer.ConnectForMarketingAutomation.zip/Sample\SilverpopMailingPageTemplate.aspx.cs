using EPiServer.Framework.DataAnnotations;
using EPiServer.Templates.Alloy.Models.Pages;

namespace EPiServer.Templates.Alloy.Views.Pages
{
    [TemplateDescriptor(Path = "~/Views/Pages/SilverpopMailingPageTemplate.aspx")]
    public partial class SilverpopMailingPageTemplate : TemplatePage<SilverpopMailingPage>
    {
    }
}