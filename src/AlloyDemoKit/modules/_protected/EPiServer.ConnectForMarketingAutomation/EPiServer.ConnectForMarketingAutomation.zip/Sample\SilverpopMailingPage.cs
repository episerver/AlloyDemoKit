﻿using EPiServer.Core;
using EPiServer.DataAbstraction;
using EPiServer.DataAnnotations;
using EPiServer.MarketingAutomationIntegration.Core;
using EPiServer.MarketingAutomationIntegration.Silverpop.Enums;
using EPiServer.MarketingAutomationIntegration.Silverpop.Implementation;
using EPiServer.MarketingAutomationIntegration.Silverpop.UI.PageTypes;
using System.ComponentModel.DataAnnotations;

namespace EPiServer.Templates.Alloy.Models.Pages
{
    [ContentType(GroupName = "Connect For Marketing Automation")]
    [ImageUrlAttribute("~/Static/gfx/SilverpopMailingPage_Preview.png")]
    public class SilverpopMailingPage : SilverpopMailingPageBase
    {
        [BackingType(typeof(PropertyString))]
        [Display(GroupName = EPiServer.MarketingAutomationIntegration.Constants.MAIPageTypeTabs, Order = 40)]
        public virtual string MyCustomProperty { get; set; }
    }
}
