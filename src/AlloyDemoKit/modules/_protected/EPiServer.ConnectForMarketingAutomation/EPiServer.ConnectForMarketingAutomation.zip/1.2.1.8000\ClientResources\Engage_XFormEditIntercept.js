//////// THIS FILE OF MAI CORE WILL BE INJECTED INTO EPISERVER'S XFORM EDIT DIALOG ///////

function byId(elementId) {
    return document.getElementById(elementId);
}

function engageEnsureInit(e) {
    var submitAction = byId(__submitActionClientID);
    var __textname = byId('__textname');
    var __textareaname = byId('__textareaname');
    var __selectname = byId('__selectname');
    var __selectareaname = byId('__selectareaname');
    var __multiplename = byId('__multiplename');
    var __selectmultiplename = byId('__selectmultiplename');

    if ($(__selectname).length > 0) {
        if (__selectname.options.length == 0) engageAddFields(__selectname);
    }

    if ($(__selectareaname).length > 0) {
        if (__selectareaname.options.length == 0) engageAddFields(__selectareaname);
    }

    if ($(__selectmultiplename).length > 0) {
        if (__selectmultiplename.options.length == 0) engageAddFields(__selectmultiplename);
    }
}

function engagePopulate(e) {
    /// engagePopulate, called onclick of the XForm control LeftPanel

    var submitAction = byId(__submitActionClientID);
    var __textname = byId('__textname');
    var __textareaname = byId('__textareaname');
    var __selectname = byId('__selectname');
    var __selectareaname = byId('__selectareaname');
    var __multiplename = byId('__multiplename');
    var __selectmultiplename = byId('__selectmultiplename');

    fieldProperties(e);
    if ($(submitAction).length > 0) {
        engageSelectValue(byId('SelectEngageForm'), byId('FormCustomUrl'));
        submitAction.selectedIndex = 3;
        formActionChange(submitAction);
    }
    engageEnsureInit();
    if ($(__selectname).length > 0) {
        engageSelectValue(__selectname, __textname);
    }
    if ($(__selectareaname).length > 0) {
        engageSelectValue(__selectareaname, __textareaname);
    }
    if ($(__selectmultiplename).length > 0) {
        engageSelectValue(__selectmultiplename, __multiplename);
    }
}

function engageSelectValue(ddl, textbox) {
    $(ddl).val(textbox.value);
    if (ddl.selectedIndex < 0 || $(textbox).val() != $(ddl).val()) {
        ddl.selectedIndex = 0; // we need to double-check the match because val() will try and match text in the select as well as values!
    }
    engageDisplayFieldName(ddl, textbox);
}

function engageSetFieldName(ddl, textbox) {
    if (ddl.options.length > 0 && ddl.selectedIndex > -1) {
        engageTextFieldName(ddl, textbox);
        engageDisplayFieldName(ddl, textbox);
    }
}

function engageTextFieldName(ddl, textbox) {
    $(textbox).val($(ddl).val());
}

function engageDisplayFieldName(ddl, textbox) {
    if (ddl.options[ddl.selectedIndex].value == "") {
        $(textbox).css('display', '');
    }
    else {
        $(textbox).css('display', 'none');
    }
}

function engageOverrideStartDrag(e) {
    // engage Override Start Drag to capture the field drop event

    fieldStartDrag.call(this, e);
    document.body.onmouseup = engageOverrideFieldDrop;
}

function engageOverrideFieldDrop(evt) {
    // Override FieldDrop event to process Silverpop business on creating XForm fields

    var submitAction = byId(__submitActionClientID);
    var __textname = byId('__textname');
    var __textareaname = byId('__textareaname');
    var __selectname = byId('__selectname');
    var __selectareaname = byId('__selectareaname');
    var __multiplename = byId('__multiplename');
    var __selectmultiplename = byId('__selectmultiplename');

    fieldDrop(evt);
    
    ResetElements([__textname, __textareaname, __selectname, __selectareaname, __multiplename, __selectmultiplename]);

    // Have to set timeout to wait for DOM construction of the new form element ready,
    // otherwise we cannot set field name value for the first time in case we click on a toolbutton to insert (DnD works well without setTimeout)
    setTimeout(function () {
        if ($(submitAction).length > 0) {
            submitAction.selectedIndex = 3;
            formActionChange(submitAction);
            byId('SelectEngageForm').selectedIndex = 0;
            engageTextFieldName(byId('SelectEngageForm'), byId('FormCustomUrl'));
        }

        if ($(__selectname).length > 0) {
            engageSetFieldName(__selectname, __textname);
        }
        if ($(__selectareaname).length > 0) {
            engageSetFieldName(__selectareaname, __textareaname);
        }
        if ($(__selectmultiplename).length > 0) {
            engageSetFieldName(__selectmultiplename, __multiplename);
        }
    }, 0);

    /// incase editor just click on the the toolbutton in the toolbar to add the field to XForm row, we cannot handle the drop event. 
    /// We simulate the click on that target row.
    if (evt.target.id === __XformToolboxButtonSubmitClientID) {
        // delaying click to the selected row, so the right panel will be rendered correctly with Silverpop UI elements
        setTimeout(function () {
            // find the current selected row in the left panel (with background color = silver)
            var currentSelectedRow = $.find('tr td[valign=top]', byId(__XformControlClientID)).filter(function (element, index, allArray) {
                return $(element).css('backgroundColor').toLowerCase() === 'silver';
            });

            if (currentSelectedRow.length > 0)
                $(currentSelectedRow).trigger('click');
        }, 100);
    }
}

function ResetElements(/*Array*/ elements) {
    // Reset display state and value of array elements

    $(elements).each(function (index) {
        var $this = $(this);
        $this.css("display", "");
        $this.val("");
    });
}