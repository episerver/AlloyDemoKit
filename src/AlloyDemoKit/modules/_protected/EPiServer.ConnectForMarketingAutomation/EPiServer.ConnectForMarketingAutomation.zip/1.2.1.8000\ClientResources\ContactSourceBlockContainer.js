﻿define([
    "dojo/_base/declare",
    "dojo/_base/lang",

    "epi/shell/layout/SimpleContainer"
],
function (
    declare,
    lang,

    SimpleContainer
) {

    return declare([SimpleContainer], {
        listTypeSourceDropdown: null,
        contactSourceDropdown: null,

        addChild: function (child) {
            // Summar: Add a widget to the container

            this.inherited(arguments);

            if (child.name.indexOf("listTypeSource") >= 0) {
                // If it's the listTypeSource drop down list
                this.listTypeSourceDropdown = child;

                // Connect to change event to update the contactSource drop down list
                this.own(this.listTypeSourceDropdown.on("change", lang.hitch(this, this._updateContactSourceDropdown)));
            } else if (child.name.indexOf("contactSource") >= 0) {
                // If it's the contactSource drop down list
                this.contactSourceDropdown = child;

                // Update the contactSource drop down
                this._updateContactSourceDropdown(this.listTypeSourceDropdown.value);
            }
        },

        _updateContactSourceDropdown: function (listTypeSource) {
            // Summary: Update the contactSource drop down list according to the selected listTypeSource

            // Clear the current value
            this.contactSourceDropdown.set("value", null);

            // Set the filter
            this.contactSourceDropdown.set("filter", function (contactSource) {
                // Oops, the contactSource code is prefixed with listTypeSource code, for the simplicity
                return contactSource.value.indexOf(listTypeSource) === 0;
            });
        }
    });
});