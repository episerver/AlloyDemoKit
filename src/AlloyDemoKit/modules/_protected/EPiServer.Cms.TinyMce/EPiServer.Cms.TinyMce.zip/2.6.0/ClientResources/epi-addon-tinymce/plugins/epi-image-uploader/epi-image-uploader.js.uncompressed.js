define("epi-addon-tinymce/plugins/epi-image-uploader/epi-image-uploader", [
    "dojo/_base/lang",
    "dojo/when",
    "dojo/on",
    "dojo/_base/window",
    "dojo/dom-construct",
    "dojo/topic",
    "epi-addon-tinymce/tinymce-loader",
    "epi/dependency",
    "epi/shell/_ContextMixin",
    "epi-cms/widget/viewmodel/MultipleFileUploadViewModel",
    "epi-cms/widget/MultipleFileUpload",
    "epi/i18n!epi/cms/nls/episerver.cms.widget.uploadmultiplefiles"
], function (
    lang,
    when,
    on,
    win,
    domConstruct,
    topic,
    tinymce,
    dependency,
    _ContextMixin,
    MultipleFileUploadViewModel,
    MultipleFileUpload,
    resources
) {

    tinymce.PluginManager.add("epi-image-uploader", function (editor) {
        var context = new _ContextMixin();
        var registry = dependency.resolve("epi.storeregistry");
        var store = registry.get("epi.cms.contentdata");
        var imgTemplate = "img[src='{0}']";

        function destroyTemporaryImageObject(blobInfo) {
            var img = editor.dom.select(lang.replace(imgTemplate, [blobInfo.blobUri()]));
            if (img.length === 1) {
                domConstruct.destroy(img[0]);
                editor.fire("Change");
            }
        }

        editor.settings.images_upload_handler = function (blobInfo, success, failure) {
            var uploader = new MultipleFileUpload({
                model: new MultipleFileUploadViewModel(),
                createAsLocalAsset: true
            });

            var uploadCompleteHandle = uploader.on("uploadComplete", function (files) {
                uploadCompleteHandle.remove();

                var file = files[0];
                if (file.statusMessage) {
                    destroyTemporaryImageObject(blobInfo);
                    failure(file.statusMessage);
                    uploader.destroyRecursive();
                } else {
                    when(store.get(file.contentLink)).then(function (content) {
                        topic.publish("/epi/cms/contentdata/updated", {
                            contentLink: content.contentLink
                        });

                        // set ALT attribute
                        var img = editor.dom.select(lang.replace(imgTemplate, [blobInfo.blobUri()]));
                        if (img.length === 1) {
                            img[0].alt = content.name;
                        }
                        success(content.previewUrl);
                        editor.fire("Change");
                    }).otherwise(function () {
                        destroyTemporaryImageObject(blobInfo);
                        failure(resources.uploadform.errormessage);
                    }).always(function () {
                        uploader.destroyRecursive();
                    });
                }
            });

            when(context.getCurrentContext()).then(function (content) {
                uploader.set("uploadDirectory", content.id);
                uploader.upload([tinymce.Env.ie ? blobInfo.blob() : new File([blobInfo.blob()], blobInfo.filename())]);
            });
        };

        editor.on("dragover", function (e) {
            editor.fire("FileDragged");
            e.stopPropagation();
        });

        var dragOverHandle = on(win.doc, "dragover", function () {
            editor.fire("FileDragging");
        });

        var dragLeaveHandle = on(win.doc, "dragleave", function () {
            editor.fire("FileStoppedDragging");
        });

        editor.on("remove", function () {
            dragOverHandle.remove();
            dragLeaveHandle.remove();
        });

        return {
            getMetadata: function () {
                return {
                    name: "Image Uploader (epi)",
                    url: "https://www.episerver.com"
                };
            }
        };
    });
});
