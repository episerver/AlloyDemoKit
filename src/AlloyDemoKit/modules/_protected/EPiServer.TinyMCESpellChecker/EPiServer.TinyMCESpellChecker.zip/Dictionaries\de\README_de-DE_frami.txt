Bei dem W�rterbuch xxx_frami handelt es sich um ein Addon. Es enth�lt
alle W�rter des Basisw�rterbuchs, zus�tzlich jedoch etliche, die entweder
im Basisw�rterbuch noch fehlen oder die nicht unbedingt zum Kernwortschatz
des Deutschen geh�ren. Die zus�tzlichen Aufnahmen sind ungepr�ft.
Dieses W�rterbuch basiert auf dem igerman98 Ispell-W�rterbuch, zu finden
unter http://www.j3e.de/ispell/igerman98/ .

Das W�rterbuch und alle enthaltenen Wortlisten sind lizenziert unter der
GNU GPL, Version 2.
Fehlermeldungen oder Erg�nzungsw�nsche k�nnen gemailt werden an:
Franz Michael Baumann <frami.baumann@web.de>

Autor des Grundw�rterbuchs:
Bjoern Jacke <bjoern@j3e.de>

Autor der Erweiterung
Franz Michael Baumann <frami.baumann@web.de>