﻿/// <reference path="jquery-1.7.1-vsdoc.js" />
/// <reference path="knockout-2.0.0.debug.js" />

//////////////////////////
// GLOBAL res object, for localized string of SocialReach
var res = null;
require(["epi/i18n!epi-cms/nls/socialreach"],
function (resources) {
    res = resources;
});

//////////////////////////
// CLASS DEF /////////////
//////////////////////////
var Social = {
    Providers: ko.observableArray([]),

    /* Replicate of PermissionEnum on ServerSide */
    AccessRight:
        {
            Unspecified: 0,
            Read: 1,
            Post: 2,
            Administer: 4,
            ListAllForSetting: 8
        },
    ChannelMessageStatus:
        {
            Error: -1,
            Queued: 0,
            Success: 1,
            Cancelled: 2
        },
    getQueryString: function (name) {
        name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
        var regexS = "[\\?&]" + name + "=([^&#]*)";
        var regex = new RegExp(regexS);
        var results = regex.exec(window.location.search);
        if (results == null) {
            return "";
        }
        else {
            return decodeURIComponent(results[1].replace(/\+/g, " "));
        }
    }
};

var Provider = {
    Get: function (providerName) {
        var provider = eval(providerName);  // get a object of provider (E.g.: Twitter object, from Providers/Scripts/Twitter.js
        provider.ProviderName = providerName;

        /* get the Template for clientside rendering */
        provider.Template = function (template) {
            var templateName = providerName + '_' + template + 'Template';  // E.g.: Twitter_EditTemplate
            if (!document.getElementById(templateName)) // try to get the template from DOM
            {
                // first time access to the template? load the Template file from server
                $.ajax({
                    url: g_ModuleResourcePath + 'Providers/' + providerName + '/' + templateName + ".aspx",
                    async: false,
                    success: function (html) {
                        $('body').append('<script type="text/html" id="' + templateName + '">' + html + '</script>');   // cache to DOM
                    }
                });
            }

            return templateName;
        }

        provider.EditTemplate = function () {
            return provider.Template('Edit');
        }
        provider.StatTemplate = function () {
            return provider.Template('Stat');
        }

        return provider;
    }
};

ko.bindingHandlers.formattedDateText = {
    update: function (element, valueAccessor, allBindingsAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
           date = new Date(value);
        if (!date) {
            return;
        }

        ko.bindingHandlers.text.update(element, function () { return moment(date).format("D MMM HH:mm"); });
    }
};

ko.bindingHandlers.arrayToString = {
    update: function (element, valueAccessor, allBindingsAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor());

        var result = '';

        ko.utils.arrayForEach(value, function (item) {
            result += item.Name() + ', ';
        });

        ko.bindingHandlers.text.update(element, function () { return result.slice(0, -2); });
    }
};


$(document).ready(function () {
    $('html.epi-scrollableArea').removeClass('epi-scrollableArea');
});