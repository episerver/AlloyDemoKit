﻿var Twitter;

if (!Twitter) {

    Social.Providers.push({ Name: 'Twitter' });

    Twitter =
    {
        GetDefaultProviderData: function ()
        {
            return {
                UserName: null,
                AccessToken: null,
                AccessTokenSecret: null
            };
        },
        InitChannelContext: function (socialChannel)
        {
            return {};
        },
        SetChannelContext: function (socialChannel)
        {
        },

        Validate: function (socialMessage, socialChannelMessage)
        {
            var valid = { IsValid: true, Message: null };

            var msg = socialChannelMessage.Message();

            if (!msg || msg.length == 0)
                msg = socialMessage.Message();


            var twitterLimit = 140;

            if (socialMessage.Url())
                twitterLimit -= this.TwitterShortUrlLength;

            if (socialMessage.ImageUrl())
                twitterLimit -= this.TwitterMediaUrlLength;

            if (msg && msg.length > twitterLimit)
            {
                valid.IsValid = false;
                valid.Message = res.client.twittermaxchar + ' (' + twitterLimit + ')';
            }

            return valid;
        },
        SelectedSocialChannel: {},


        ReceiveData: function (screenName, accessToken, accessTokenSecret)
        {
            this.SelectedSocialChannel.Channel.AccountDisplayName(screenName);

            this.SelectedSocialChannel.Channel.ProviderData.UserName(screenName);
            this.SelectedSocialChannel.Channel.ProviderData.AccessToken(accessToken);
            this.SelectedSocialChannel.Channel.ProviderData.AccessTokenSecret(accessTokenSecret);
        },

        LoadDetailedStatistics: function (socialChannelMessage, socialMessage) {
            var stats = {
                Retweets: ko.observable('-')
            };

            if (socialChannelMessage.Status == Social.ChannelMessageStatus.Success)
            {
                $.ajax({
                    url: g_ModuleResourcePath + "Providers/TwitterProxy/GetRetweetCount",
                    data: "accessToken=" + socialChannelMessage.Channel.ProviderData.AccessToken + "&statusId=" + socialChannelMessage.PostID,
                    dataType: "json",
                    cache: false,
                    type: "GET",
                    async: true,
                    success: function (data)
                    {
                        if (data == '0')
                            stats.Retweets(0);
                        else
                            stats.Retweets(data);
                    }
                });
            }

            return stats;
        },
        GetMessageUrl: function (socialChannelMessage) {
            return "https://twitter.com/statuses/" + socialChannelMessage.PostID;
        },

        /* Shorten Url of Twitter is 20 chars, and a space for seperating */
        TwitterShortUrlLength: 21,
        /* Media Url (after uploading image to Twitter) is 25 chars and a space for seperating */
        TwitterMediaUrlLength: 26,

        CheckLength: function (socialMessage, count, warning)
        {
            var allowedLength = 140;

            if (socialMessage.Url())
                allowedLength -= this.TwitterShortUrlLength;

            if (socialMessage.ImageUrl())
                allowedLength -= this.TwitterMediaUrlLength;

            warning.InWarning(count > allowedLength);
            warning.Info(count + '. ' + res.client.twittermaxchar + ' (' + allowedLength + ')');
        }
    };
}

$(".edit-twitteraccount").live("click", function (e) {
    e.preventDefault();

    Twitter.SelectedSocialChannel = ko.dataFor(this);
    window.open(g_ModuleResourcePath + 'Providers/Twitter/TwitterLogin.aspx?redirect=1', 'mywindow', 'resizable,width=800,height=700');
    return false;
});
