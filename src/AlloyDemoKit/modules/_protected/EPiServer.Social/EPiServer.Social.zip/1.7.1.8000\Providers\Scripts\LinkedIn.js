﻿var LinkedIn;

if (!LinkedIn) {

    Social.Providers.push({ Name: 'LinkedIn' });

    LinkedIn =
    {
        GetDefaultProviderData: function () {
            return {
                UserName: null,
                AccessToken: null,
                AccessTokenSecret: null,
                PostTo: null
            };
        },
        InitChannelContext: function (socialChannel) {
            return {};
        },
        SetChannelContext: function (socialChannel) {
        },
        Validate: function (socialMessage, socialChannelMessage) {
            return { IsValid: true, Message: null };
        },
        SelectedSocialChannel: {},
        ReceiveData: function (screenName, accessToken, accessTokenSecret) {
            if (!screenName) {
                screenName = "LinkedIn";
            }

            this.SelectedSocialChannel.Channel.AccountDisplayName(screenName);

            this.SelectedSocialChannel.Channel.ProviderData.UserName(screenName);
            this.SelectedSocialChannel.Channel.ProviderData.AccessToken(accessToken);
            this.SelectedSocialChannel.Channel.ProviderData.AccessTokenSecret(accessTokenSecret);

            this.SetChannelContext(this.SelectedSocialChannel);
        },
        LoadDetailedStatistics: function (socialChannelMessage, socialMessage) {

            var stats = {
                Likes: ko.observable('-'),
                Comments: ko.observable('-')
            };

            if (socialChannelMessage.Status == Social.ChannelMessageStatus.Success) {
                $.ajax({
                    url: g_ModuleResourcePath + "Providers/LinkedInProxy/GetShare",
                    data: "accessToken=" + socialChannelMessage.Channel.ProviderData.AccessToken + "&shareId=" + socialChannelMessage.PostID,
                    dataType: "json",
                    cache: false,
                    type: "GET",
                    async: true,
                    success: function (data) {
                        if (data) {
                            // in case server API return -1, we don't update stats, because it is API error, and zero is not correct value.
                            if(data.Comments >= 0) stats.Comments(data.Comments);
                            if (data.Likes >= 0) stats.Likes(data.Likes);
                        }
                    }
                });
            }
            return stats;
        },
        GetMessageUrl: function (socialChannelMessage) {
            return "http://www.linkedin.com";
        },
        CheckLength: function (socialMessage, count, warning) {
            warning.InWarning(count > 700);
            if (count > 700) {
                warning.Info(res.client.linkedinmaxchar + ' (' + count + ')');
            }
        }

    };
}

$(".edit-linkedinaccount").live("click", function (e) {
    e.preventDefault();

    LinkedIn.SelectedSocialChannel = ko.dataFor(this);
    window.open(g_ModuleResourcePath + 'Providers/LinkedIn/LinkedInLogin.aspx?redirect=1', 'mywindow', 'resizable,width=800,height=700');
    return false;
});
