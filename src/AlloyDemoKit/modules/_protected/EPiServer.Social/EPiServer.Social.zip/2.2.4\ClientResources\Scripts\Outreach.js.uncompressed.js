﻿function _TryToDoFuncRepeatly(func, contextForThis, interval, maxLoopCount, defer) {
    /// <summary>
    /// Util function.
    /// try to exec <param>func</param>. func should return true if its executing is successful
    /// contextForThis: context for func's "this" object
    /// interval: between a loop
    /// maxLoopCount: max count to try executing func
    /// defer: on executing func successfully, this defer will be resolved.
    /// </summary>

    var flagToStop = false;
    var count = 0;

    var loopHandler = setInterval(function () {
        count++;

        if (flagToStop || count > maxLoopCount) {
            clearInterval(loopHandler);
            if (defer)
                defer.reject();
            return;
        }

        var ret = func.apply(contextForThis);
        if (ret) {
            clearInterval(loopHandler);
            flagToStop = true;
            if (defer)
                defer.resolve();
        }

    }, interval);
};


function SocialMessageClass() {
    var self = this;

    self.CurrentLanguageId = ko.observable(null);
    self.Id = ko.observable('00000000-0000-0000-0000-000000000000');
    self.Started = ko.observable(null);
    self.Name = ko.observable(null);
    self.Url = ko.observable(null);
    self.ImageUrl = ko.observable(null);
    self.Campaign = ko.observable(null);
    self.Message = ko.observable(null);
    self.Schedule = ko.observable(g_EPiServer.noScheduleDate);
    self.ChannelMessages = ko.observableArray([]);
}

var viewModel = {

    initialized: ko.observable(false).extend({ throttle: 100 }),
    initSocialMessage: null,
    socialMessage: new SocialMessageClass(),

    isSchedule: ko.observable(false).extend({ throttle: 100 }),
    isEditMode: ko.observable(false),
    createSocialMessage: function (socialMessage) {
        if (!viewModel.postRequest(socialMessage, "Outreach/Create")) {
            return;
        }
    },

    saveSocialMessage: function (socialMessage) {
        if (!viewModel.postRequest(socialMessage, "Outreach/Save")) {
            return;
        }
    },

    resendSocialMessage: function (socialMessage) {
        if (!viewModel.postRequest(socialMessage, "ResendMessage/Resend")) {
            return;
        }
    },

    postRequest: function (socialMessage, action) {
        // disable buttons on screen
        $(".epi-cmsButton-text").attr("disabled", "disabled");

        // validate social message
        if (!viewModel.isValid(socialMessage)) {
            // enable buttons
            $(".epi-cmsButton-text").removeAttr("disabled");
            return false;
        }

        $.post(g_ModulePath + action, { jsonObject: ko.toJSON(socialMessage) }, function (returnedData) {
            if (returnedData.Success) {
                window.location.href = g_ModulePath + "Overview/?sent=1";
                $('#socialmessage-current-language-id, #socialmessage-name, #socialmessage-message, #socialmessage-url-display, #socialmessage-url, #socialmessage-imageurl, #socialmessage-campaign').val('');
            }
            else {
                $('#error-message').text(returnedData.Message).show();
            }
            // enable buttons
            $(".epi-cmsButton-text").removeAttr("disabled");
        });

        return true;
    },

    pagereferenceClick: function (data, e) {
        e.preventDefault();

        var url = g_ProtectedRootPath + 'CMS/edit/pagebrowser.aspx';
        var valueId = 'socialmessage-url';
        var infoId = 'socialmessage-url-display';

        // url, id, disableCurrentPageOption, displayWarning, info, value, language, callbackMethod, callbackArguments, requireUrlForSelectedPage
        EPi.CreatePageBrowserDialog(url, 1, false, false, infoId, valueId, null, 3, null, true);
    },
    initSocialChannel: function (elements, socialChannelMessage) {
        if (socialChannelMessage === undefined) {
            return;
        }

        $('.logo', elements).attr('src', g_ModuleResourcePath + 'Providers/' + socialChannelMessage.Channel.ProviderName.toLowerCase() + '/logo.png');

        $('textarea', elements).trackLength(function (count) {

            if (socialChannelMessage.Enabled() && socialChannelMessage.Message() && socialChannelMessage.ProviderObj.CheckLength) {
                socialChannelMessage.ProviderObj.CheckLength(viewModel.socialMessage, count, socialChannelMessage.Warning);
            }
        });

        if (!viewModel.isSchedule()) {
            return;
        }
        var dateTimeSelector = dijit.byId("socialmessage-datetimeselector");
        var date = new Date(viewModel.socialMessage.Schedule());
        dateTimeSelector.set("value", date);
    },

    deleteMessage: function (socialMessage) {
        // summary:
        //      Delete a social message
        // parameters:
        //      socialMessage: The message will be deleted.  
        // tags:
        //      public

        var data = "id=" + socialMessage.Id();
        $.post(g_ModulePath + "Overview/Remove", data, function () {
            window.location.href = g_ModulePath + "Overview/?sent=1";
            $('#socialmessage-current-language-id, #socialmessage-name, #socialmessage-message, #socialmessage-url-display, #socialmessage-url, #socialmessage-imageurl, #socialmessage-campaign').val('');
        });
    },

    runMessageLengthCheck: function () {

        $(viewModel.socialMessage.ChannelMessages()).each(function () {

            var count = this.Message() ? this.Message().length : viewModel.socialMessage.Message() ? viewModel.socialMessage.Message().length : 0;

            if (this.Enabled() && this.ProviderObj.CheckLength) {
                this.ProviderObj.CheckLength(viewModel.socialMessage, count, this.Warning);
            }
        });
    },
    isValid: function (socialMessage) {
        // at least one channel must be selected
        var selectedChannel = 0;
        $(socialMessage.ChannelMessages()).each(function () {
            if (this.Enabled()) {
                selectedChannel++;
            }
        });
        if (selectedChannel == 0) {
            alert(res.client.channelmustbeselected);
            return false;
        }

        // check null or empty for message name
        if (socialMessage.Name() == null || $.trim(socialMessage.Name()) == '') {
            alert(res.client.messagenamemustnotbeempty);
            return false;
        }

        // check null or empty for message detail
        var isMessageValid = true;
        // if social message is empty and there are no message was defined in any channel message
        if (socialMessage.Message() == null || $.trim(socialMessage.Message()) == '') {
            // check if the selected channel's message is empty or not
            $(socialMessage.ChannelMessages()).each(function () {
                // a selected social chanel message with blank content
                if (this.Enabled() && (this.Message() == null || $.trim(this.Message()) == '')) {
                    isMessageValid = false;
                    return;
                }
            });

        }
        else {
            // if social message is not empty but there is a custom message which is blank
            $(socialMessage.ChannelMessages()).each(function () {
                // a selected social chanel message with custom message but the content is blank
                if (this.Enabled() && this.CustomMessage() && (this.Message() == null || $.trim(this.Message()) == '')) {
                    isMessageValid = false;
                    return;
                }
            });
        }
        if (!isMessageValid) {
            alert(res.client.cannotsendemptymessage);
            return false;
        }

        var providerInErrors = 0;
        // validate message based on selected channels (channels which are enabled)
        $(socialMessage.ChannelMessages()).each(function () {
            if (this.Enabled()) {
                var valid = this.ProviderObj.Validate(socialMessage, this);

                if (!valid.IsValid) {
                    alert('"' + this.Channel.Name + '": ' + valid.Message);
                    providerInErrors++;
                }
            }
        });

        if (providerInErrors > 0) {
            return false;
        }

        return true;
    },

    clearSchedule: function () {
        viewModel.isSchedule(false);
        viewModel.socialMessage.Schedule(g_EPiServer.noScheduleDate);
        var dateTimeSelector = dijit.byId("socialmessage-datetimeselector");
        dateTimeSelector.set("value", null);
    }
};

ko.applyBindings(viewModel);

$(document).ready(function () {
    var $outreach = $('.outreach');

    // Get the SocialMessage from serverside's Model
    viewModel.initSocialMessage = g_DefaultMessage;

    // fills re-send message detail to social message form for viewing
    if (viewModel.initSocialMessage) {
        // if social message ID is not null then set isEditMode flag to true
        if (viewModel.initSocialMessage.id != '00000000-0000-0000-0000-000000000000') {
            viewModel.isEditMode(true);
        }

        viewModel.socialMessage.CurrentLanguageId(viewModel.initSocialMessage.currentLanguageId);
        viewModel.socialMessage.Id(viewModel.initSocialMessage.id);
        viewModel.socialMessage.Started(viewModel.initSocialMessage.started);
        viewModel.socialMessage.Name(viewModel.initSocialMessage.name);
        viewModel.socialMessage.Message(viewModel.initSocialMessage.message);
        viewModel.socialMessage.Url(viewModel.initSocialMessage.url);
        viewModel.socialMessage.ImageUrl(viewModel.initSocialMessage.imageUrl);
        viewModel.socialMessage.Campaign(viewModel.initSocialMessage.campaign);

        // FIX: GMT problem. Use ScheduleGMTString
        var GMTDateOfSchedule = new Date(viewModel.initSocialMessage.scheduleGMTString);
        viewModel.socialMessage.Schedule(GMTDateOfSchedule);
    }

    $.ajax({
        url: g_ModulePath + "Settings/GetAllSocialChannels",
        data: "permission=" + Social.AccessRight.Post,
        dataType: "json",
        cache: false,
        type: "POST",
        async: true,
        success: function (data) {

            var defaultEnabled = viewModel.initSocialMessage.channelMessages.length == 0;

            $(data).each(function () {

                var socialChannelMessage = {
                    Id: ko.observable('00000000-0000-0000-0000-000000000000'),
                    Enabled: ko.observable(defaultEnabled),
                    Message: ko.observable(null),
                    CustomMessage: ko.observable(false),
                    Channel: this,
                    Status: Social.ChannelMessageStatus.Queued,
                    Warning: {
                        InWarning: ko.observable(false),
                        Info: ko.observable(null)
                    },
                    ProviderObj: Provider.Get(this.ProviderName)
                };

                if (viewModel.initSocialMessage) {

                    // enable channel messages which are used to re-send the social message
                    $(viewModel.initSocialMessage.channelMessages).each(function () {

                        if (this.channel.id == socialChannelMessage.Channel.Id) {
                            socialChannelMessage.Enabled(this.enabled);
                            socialChannelMessage.Id(this.id);

                            if (this.message && $.trim(this.message) != null) {
                                socialChannelMessage.Message(this.message);
                                socialChannelMessage.CustomMessage(true);
                            }
                        }
                    });
                }

                viewModel.socialMessage.ChannelMessages.push(socialChannelMessage);
            });

            // when do resend message, all messages which are not error will be remove from the channel list
            // to detect if a social message is being resent or not we should check the HasError flag
            if (viewModel.initSocialMessage.hasError) {
                // remove channels which are not enabled
                var i = 0;
                while (i < viewModel.socialMessage.ChannelMessages().length) {
                    if (!viewModel.socialMessage.ChannelMessages()[i].Enabled()) {
                        viewModel.socialMessage.ChannelMessages().splice(i, 1);
                        continue;
                    }
                    ++i;
                }
            }

            // in case a init social message is a scheduled message
            // then isSchedule flag in view model should be set to true
            if (viewModel.initSocialMessage.isScheduled) {
                viewModel.isSchedule(true);
            }

            viewModel.initialized(true);

            if (viewModel.initSocialMessage)
                viewModel.runMessageLengthCheck();
        }
    });

    $('#socialmessage-message').trackLength(function (count) {
        $(viewModel.socialMessage.ChannelMessages()).each(function () {

            if (this.Enabled() && !this.Message() && this.ProviderObj.CheckLength) {
                this.ProviderObj.CheckLength(viewModel.socialMessage, count, this.Warning);
            }
        });
    });

    $('#socialmessage-url, #socialmessage-imageurl').on("change", viewModel.runMessageLengthCheck);

    $('.toggle-message').live('click', function (e) {
        e.preventDefault();

        var socialChannelMessage = ko.dataFor(this);

        var $parentContainer = $(this).parents('.channel');

        if (!socialChannelMessage.CustomMessage()) {
            socialChannelMessage.CustomMessage(true);
            socialChannelMessage.Message(viewModel.socialMessage.Message());

            var length = socialChannelMessage.Message() ? socialChannelMessage.Message().length : 0;

            if (socialChannelMessage.ProviderObj.CheckLength)
                socialChannelMessage.ProviderObj.CheckLength(viewModel.socialMessage, length, socialChannelMessage.Warning)

            $parentContainer.find('textarea').focus();
        }
        else {
            socialChannelMessage.CustomMessage(false);
            socialChannelMessage.Message(null);

            var length = viewModel.socialMessage.Message() ? viewModel.socialMessage.Message().length : 0;

            if (socialChannelMessage.ProviderObj.CheckLength)
                socialChannelMessage.ProviderObj.CheckLength(viewModel.socialMessage, length, socialChannelMessage.Warning)
        }
    });

    $('.channel-enabled').live('click', function (e) {
        viewModel.runMessageLengthCheck();
    });

    $(".message-delete").live("click", function (e) {
        /**
        Delete the scheduled SocialMessage
        */
        e.preventDefault();

        if (confirm(res.client.deleteconfirmation)) {
            viewModel.deleteMessage(ko.dataFor(this));
        }
    });

    $outreach.on('scheduleChanged', function (evt, scheduleDateTime) {
        // summary:
        //      Handle event when user change schedule for social message.
        // prameters:
        //      evt: contains event information.
        //      scheduleDateTime: value of schedule field which has been set by user.
        // tags:
        //      event

        if (!scheduleDateTime) {
            return;
        }

        viewModel.socialMessage.Schedule(scheduleDateTime);
        viewModel.isSchedule(true);
    });
});






//===========================using falcon 7.5 dialogs instead of legacy ones========================
require([
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/Deferred",
    "dojo/parser",
    "dojo/promise/all",
    "dojo/aspect",
    "dojo/query",
    "dojo/when",
    "dojo/on",
    "dojo/NodeList-manipulate",
    "dojo/dom-style",

    "dijit/_HasDropDown",

    // EPi Framework
    "epi/dependency",
    "epi/ModuleManager",
    "epi/routes",
    "epi/shell/MessageService",
    "epi/shell/Profile",
    "epi/shell/store/Registry",
    "epi/shell/TypeDescriptorManager",
    "epi/shell/widget/DateTimeSelectorDropDown",
    "epi/shell/widget/dialog/Dialog",
    "epi/shell/MetadataManager",
    
    // EPi CMS
    "epi-cms/core/PermanentLinkHelper",
    "epi-cms/store/CustomQueryEngine",
    "epi-cms/widget/ContentSelectorDialog",
    "epi-cms/widget/UrlSelector",
    "epi-cms/widget/LinkEditor",
    "epi-cms/form/EmailValidationTextBox",
    "epi-cms/contentediting/ContentHierarchyService",
    "epi/Url",
    "epi-cms/ContentRepositoryDescriptorService",

    // Social Reach
    "epi-socialreach/widget/UrlContentSelector",
    "epi-socialreach/widget/viewmodel/ContextualContentForestStoreModel",

    "epi/i18n!epi-cms/nls/socialreach.outreach"
],
   function (
       // Dojo
       array,
       declare,
       lang,

       Deferred,
       parser,
       promiseAll,
       aspect,
       query,
       when,
       on,
       NodeListManipulate,
       domStyle,

       // Dijit
       _HasDropDown,

       // EPi Framework
       dependency,
       ModuleManager,
       routes,
       MessageService,
       Profile,
       StoreRegistry,
       TypeDescriptorManager,
       DateTimeSelectorDropDown,
       Dialog,
       MetadataManager,

       // EPi CMS
       PermanentLinkHelper,
       CustomQueryEngine,
       ContentSelectorDialog,
       UrlSelector,
       LinkEditor,
       EmailValidationTextBox,
       ContentHierarchyService,
       Url,
       ContentRepositoryDescriptorService,

       // Social Reach
       UrlContentSelector,
       ContextualContentForestStoreModel,

       res
    ) {

       // determine whether this script is running in ResendMessage view or not
       var isResendMessageView = /\/ResendMessage/.test(window.location.href);

       // apply patch from episerver for _HasDropDown
       lang.mixin(_HasDropDown.prototype, {
           _onBlur: function () {
               // summary:
               //       Called magically when focus has shifted away from this widget and it's dropdown

               // Don't focus on button if the user has explicitly focused on something else (happens
               // when user clicks another control causing the current popup to close)..
               // But if focus is inside of the drop down then reset focus to me, because IE doesn't like
               // it when you display:none a node with focus.
               var focusMe = focus.curNode && this.dropDown && dom.isDescendant(focus.curNode, this.dropDown.domNode);

               /* THE FIX GOES HERE */
               /* --------------------------------------------------------------------------------------------- */

               // Fire the public onBlur event before calling closeDropDown in which it may try to grab focus and fire onFocus event.
               // That leads to the situation that the next onFocus event happens before the last onBlur event.
               this.inherited(arguments);
               this.closeDropDown(focusMe);

               /* --------------------------------------------------------------------------------------------- */
               /* END FIX */
           }
       });
       _HasDropDown.prototype._onBlur.nom = "_onBlur";



       //////////////////////////////////////////
       // Framework ShellModule initialize
       //////////////////////////////////////////

       // Register dependency
       var registry = new StoreRegistry();
       dependency.register("epi.storeregistry", registry);
       dependency.register("epi.shell.Profile", new Profile());
       dependency.register("epi.shell.MessageService", MessageService);
       dependency.register("epi.ModuleManager", new ModuleManager());
       dependency.register("epi.shell.MetadataManager", new MetadataManager());       

       // Init Shell stores
       var contextStoreUrl = routes.getRestPath({ moduleArea: "shell", storeName: "context" });
       // Create context store
       registry.create("epi.shell.context", contextStoreUrl, { idProperty: "uri" });
       registry.create("epi.shell.metadata", routes.getRestPath({ moduleArea: "shell", storeName: "metadata" }), { idProperty: "modelType" });
       registry.create("epi.shell.uidescriptor", routes.getRestPath({ moduleArea: "shell", storeName: "uidescriptor" }));

       TypeDescriptorManager.initialize();

       /////////////////////////////////////////
       // CMSModule initialize
       /////////////////////////////////////////

       // Register dependency
       dependency.register("epi.cms.contentRepositoryDescriptors", new ContentRepositoryDescriptorService());

       var _getRestPath = function (name) {
           return routes.getRestPath({ moduleArea: "cms", storeName: name });
       };
       // Init CMS stores
       registry.create("epi.cms.content.light", _getRestPath("contentstructure"), { idProperty: "contentLink", queryEngine: CustomQueryEngine });
       registry.create("epi.cms.contentdata", _getRestPath("contentdata"), { idProperty: "contentLink" });
       // Create language store
       registry.create("epi.cms.language", _getRestPath("language"), { idProperty: "languageId" });

       dependency.register("epi.cms.ContentHierarchyService", new ContentHierarchyService());

       // util functions
       function addQueryParam(url, paramName, paramValue) {
           // add query param to the url
           if (!url || !paramName) {
               return url;
           }

           var uBuilder = new Url(url);
           uBuilder.query[paramName] = paramValue;
           return uBuilder.toString();
       }

       function combinePath(/*String*/baseUri, /*String*/relativePath) {
           // combine the base URI and relative path to a full path
           if (!baseUri || !relativePath) {
               return baseUri;
           }
           var uBuilder = new Url(baseUri);
           uBuilder.path = relativePath;
           return uBuilder.toString();
       }

       function _getCurrentEpsLanguageOfMessageUrl() {
           /// util, get the epsLanguage in input#socialmessage-url

           return $contentLanguageId.val();
       }

       function _getEpsLanguage(/*String*/url) {
           // summary:
           //      Gets the "epslanguage" query string value from the given url string
           // url: [String]
           //      The given url string that want to get epslanguage from
           // tags:
           //      private

           if (url) {
               return new Url(url).query.epslanguage;
           }
       }

       var $contentLanguageId = $("#socialmessage-current-language-id");
       function _setCurrentLanguageId(/*String*/languageId) {
           // summary:
           //       Sets current language branch code
           // languageId: [String]
           //       The current language branch code
           // tags:
           //       private

           $contentLanguageId.val(languageId);
       }

       /////////////////////////////////////////
       // Initialize Image Content Selector
       /////////////////////////////////////////

       var roots = g_EPiServer.globalAssetsRootID === g_EPiServer.siteAssetsRootID ? [g_EPiServer.globalAssetsRootID] : [g_EPiServer.globalAssetsRootID, g_EPiServer.siteAssetsRootID],
           allowedTypes = ["episerver.core.icontentimage", "episerver.core.contentfolder"];

       // epi-socialreach/widget/viewmodel/ContextualContentForestStoreModel
       var mediaModel = new ContextualContentForestStoreModel({
           roots: roots,
           typeIdentifiers: allowedTypes,
           currentContextId: g_EPiServer.siteAssetsRootID,
           pseudoContextualContent: g_EPiServer.contentAssetsRootID
       });

       var imageSelector = new UrlContentSelector({
           roots: roots,
           allowedTypes: ["episerver.core.icontentimage"],
           allowedDndTypes: ["episerver.core.icontentimage", "episerver.core.contentfolder"],
           model: mediaModel,
           typesToDisplay: allowedTypes,
           isAllowedType: function (content) {
               return content && content.contentTypeName.toLowerCase() === "image";
           }
       });

       var $inputImageUrl = $("#socialmessage-imageurl");   // this hidden input contains value of imageUrl
       // on change, we set the new value to input#socialmessage-imageurl
       imageSelector.own(
           imageSelector.connect(imageSelector, "onChange", function (value) {
               if (value) {
                   $inputImageUrl.val(g_EPiServer.siteUrl.replace(/(\s+)?.$/, '') + value);
               } else {
                   $inputImageUrl.val('');
               }
               // trigger change event to force knockout update view model
               $inputImageUrl.trigger("change");
           })
       );
       imageSelector.placeAt("socialmessage-imageSelector");

       // we need to wait for knockout bind model data to the DOM,
       // also cannot listen afterRender event because this script may run after the event trigger
       _TryToDoFuncRepeatly(function () {
           imageSelector.set("value", $inputImageUrl.val());
       },
           this, 100, 5, null);


       /////////////////////////////////////////
       // Initialize UrlContentSelector
       /////////////////////////////////////////

       var urlSelector = new UrlSelector({
           metadata: {
               additionalValues: {
                   modelType: "EPiServer.Cms.Shell.UI.ObjectEditing.InternalMetadata.LinkModel"
               }
           }
       });

       // epi-socialreach/widget/viewmodel/ContextualContentForestStoreModel
       var contentModel = new ContextualContentForestStoreModel({
           roots: [g_EPiServer.rootPageID],
           typeIdentifiers: ["episerver.core.pagedata"],
           currentContextId: g_EPiServer.rootPageID,
           pseudoContextualContent: g_EPiServer.contentAssetsRootID
       });

       aspect.after(contentModel, "_createQuery", function (query) {
           return lang.mixin(query, {
               "allLanguages": true,
               "epslanguage": _getCurrentEpsLanguageOfMessageUrl()
           });
       });

       // send the language in order to get page name in selected language
       urlSelector.own(
            aspect.before(urlSelector.linkHelper, "getContent", function (value, options) {
                return [value, lang.mixin(options, { "language": _getCurrentEpsLanguageOfMessageUrl() })]
            })
        )
       _setupUrlSelector(urlSelector);

       var $inputUrl = $("#socialmessage-url");   // this hidden input contains value of messageUrl
       // set url to empty if user click on clear button of urlSelector
       on(urlSelector.clearButton, "click", function () {
           $inputUrl.val('');
           $inputUrl.trigger("change");
       });
       urlSelector.own(
           urlSelector.connect(urlSelector, "onChange", function (value) {
               var espLanguageOnUrl = _getEpsLanguage(value);
               if (value) {
                   // is relative link? --> internal link
                   if (value.indexOf('/') == 0) {

                       // save the url-including-epslanguage to socialmessage-url
                       when(PermanentLinkHelper.getContent(value, { "allLanguages": true }), lang.hitch(this, function (content) {
                           // add siteUrl to its beginning
                           var relativePath = content && content.permanentLink ? content.permanentLink.substring(content.permanentLink.indexOf("/")) : value;
                           var urlToStore = combinePath(g_EPiServer.siteUrl, relativePath);

                           // Ensure that the selected content is localizable or not (ex.: in this case, it is page, not media)
                           var contentLanguageId = content && content.currentLanguageBranch ? content.currentLanguageBranch.languageId : null;
                           if (contentLanguageId) {
                               var epsLanguage = espLanguageOnUrl || contentLanguageId;
                               urlToStore = addQueryParam(urlToStore, "epslanguage", epsLanguage);
                           }

                           // ASYNC, we need to setVal and trigger here
                           $inputUrl.val(urlToStore);
                           // trigger change event to force knockout update view model
                           $inputUrl.trigger("change");
                       }));
                   }
                   else {
                       // external link, store it as is
                       $inputUrl.val(value);
                       // trigger change event to force knockout update view model
                       $inputUrl.trigger("change");
                   }
               }

           })   // connect()
        );  // own()

       urlSelector.placeAt("socialmessage-linkSelector");

       // we need to wait for knockout bind model data to the DOM,
       // also cannot listen afterRender event because this script may run after the event trigger
       _TryToDoFuncRepeatly(function () {

           var urlString = $inputUrl.val().toString();
           if (!urlString) {
               // Give url selector widget a blank value in order to set its default state (empty content link reference) have a good display
               urlSelector.set("value", "");

               return;
           }

           urlSelector.set("value", urlString);
           // parse epslanguage from urlString
           var epsLanguage = (new Url(urlString)).query.epslanguage;
           if (epsLanguage) {
               _setCurrentLanguageId(epsLanguage);

           }

       }, this, 100, 5, null);

       function _setupUrlSelector(/*Object*/urlSelector) {
           // summary:
           //       Setup for the UrlSelector widget
           //       It is the main entry to switchs between legacy and the latest widget
           // remarks:
           //       For compability between CMS versions: 7.5 and later,
           //       we should switch between "showDialog()" (legacy) and "_onDialogShow()" method
           //       in order to ensure that UrlSelector widget working properly
           // urlSelector: [Object]
           //       An instance of the "epi-cms/widget/UrlSelector" class

           typeof urlSelector.showDialog === "function"
                ? _setupLegacyUrlSelector(urlSelector, "showDialog")
                : _setupLastestUrlSelector(urlSelector, "_onDialogShow");
       }

       function _setupLastestUrlSelector(/*Object*/urlSelector, /*String*/aspectMethodName) {
           // summary:
           //       Setup for the UrlSelector widget with the latest version of the CMS
           // urlSelector: [Object]
           //       An instance of the "epi-cms/widget/UrlSelector" class
           // aspectMethodName: [String]
           //       The main entry (function name used in the aspect clause) to applies modification

           aspect.before(urlSelector, aspectMethodName, function () {
               this.dialog.set("title", this._getTitle());

               _onDialogContentFieldCreated(this.dialogContent);

               this.own(
                   aspect.before(this.dialogContent, "_handleActions", _filterOutDeleteAction) // Filter out "Delete" button
               );
           });
       }

       function _setupLegacyUrlSelector(/*Object*/urlSelector, /*String*/aspectMethodName) {
           // summary:
           //       Setup for the UrlSelector widget with the legacy version of the CMS (7.5)
           // urlSelector: [Object]
           //       An instance of the "epi-cms/widget/UrlSelector" class
           // aspectMethodName: [String]
           //       The main entry (function name used in the aspect clause) to applies modification

           aspect.around(urlSelector, aspectMethodName, function (originalShowDialog) {
               return function () {
                   this.dialogContent = new this.dialogContentClass(lang.mixin({ value: this.value }, this.dialogContentParams));

                   _onDialogContentFieldCreated(this.dialogContent);

                   var dialog = new Dialog({
                       title: this._getTitle(),
                       dialogClass: this.dialogClass,
                       content: this.dialogContent,
                       destroyOnHide: this.destroyOnHide,
                       defaultActionsVisible: this.defaultActionsVisible
                   });

                   this.own(
                        this.dialogContent,
                        aspect.after(dialog, "onExecute", lang.hitch(this, this.onDialogExecute), true),
                        aspect.after(dialog, "onCancel", lang.hitch(this, this.onDialogCancel), true),
                        aspect.after(dialog, "onHide", lang.hitch(this, this.onDialogHideComplete), true),
                        aspect.before(this.dialogContent, "_handleActions", _filterOutDeleteAction), // Filter out "Delete" button
                        dialog.watch("open", lang.hitch(this, function (name, oldValue, newValue) {
                            if (!newValue) { return; }

                            this.onDialogOpen();
                        }))
                   );

                   dialog.show();
               }
           });
       }

       function _onDialogContentFieldCreated(/*Object*/dialogContent) {
           // summary:
           //       Hide all fields that have name is "href"
           // dialogContent: [Object]
           //       An instance of the "epi-cms/widget/LinkEditor" class

           aspect.after(dialogContent, "onFieldCreated", function (fieldName, widget) {
               if (fieldName === "href") {
                   if (widget.wrappers instanceof Array) {
                       _decorateContentSelectorDialog(widget.wrappers);

                       return;
                   }

                   if (typeof widget.onSelectorsCreated === "function") {
                       aspect.after(widget, "onSelectorsCreated", function (widget) {
                           _decorateContentSelectorDialog(widget.wrappers);
                       }, true);
                   }
               }
           }, true);
       }

       function _decorateContentSelectorDialog(/*Array*/wrapperList) {
           // summary:
           //       Decorates the content selector dialog widget in order to use its features normally in the addons environment
           // wrapperList: [Array]
           //       Collection of wrapper object
           // tags:
           //       private

           array.forEach(wrapperList, function (wrapper) {
               // hide email option
               if (wrapper.inputWidget.isInstanceOf(EmailValidationTextBox) === true) {
                   domStyle.set(wrapper.domNode, { display: "none" });
               }

               // hide Marketing content
               var settings = wrapper.settings || {};
               if (settings.allowedTypes instanceof Array && array.indexOf(settings.allowedTypes, "episerver.commerce.marketing.promotiondata") > -1) {
                   domStyle.set(wrapper.domNode, { display: "none" });
               }

               // Patch _getDialog method
               if (wrapper.inputWidget && wrapper.inputWidget._getDialog) {
                   wrapper.inputWidget._getDialog = function () {
                       if (this.dialog && this.dialog.domNode) {
                           return this.dialog;
                       }

                       contentModel.roots = wrapper.settings.roots;
                       this.contentSelectorDialog = new ContentSelectorDialog({
                           canSelectOwnerContent: this.canSelectOwnerContent,
                           showButtons: false,
                           roots: contentModel.roots,
                           allowedTypes: wrapper.settings.allowedTypes,
                           model: contentModel
                       });

                       // TECHNOTE:
                       //       We don't want user select a root or container page node in the content selector tree.
                       //       So that, each time user try to select this kind of page, the selected tree node will be clear.
                       //       The valid condition to verifies the selected content is root or container page is its "publicUrl" property.
                       //       Root or container page don't have value for "publicUrl".
                       aspect.after(this.contentSelectorDialog, "_onTreeNodeClick", lang.hitch(this.contentSelectorDialog, function (content) {
                           if (content && !content.publicUrl) {
                               this.tree.lastFocused.setSelected(false);

                               this.set('value', null);
                               this.onChange(this.get('value'));
                           }
                       }), true);

                       this.dialog = new Dialog({
                           title: wrapper.name,
                           dialogClass: "epi-dialog-portrait",
                           content: this.contentSelectorDialog,
                           destroyOnHide: true
                       });

                       this.connect(this.contentSelectorDialog, "onChange", "_setDialogButtonState");
                       this.connect(this.dialog, 'onExecute', '_onDialogExecute');
                       this.connect(this.dialog, 'onHide', '_onDialogHide');

                       return this.dialog;
                   }
               }
           });
       }

       function _filterOutDeleteAction() {
           // summary:
           //       Filter out delete action from the given action collection
           // TECHNOTE: we don't want Delete button, remove it from actions array, after _handleActions()

           var deleteAction = array.filter(this._actions, function (action) {
               if (action.hasOwnProperty("name") && typeof action.name === "string") {
                   return action.name.toLowerCase() === "delete";
               };

               return false;
           });

           if (deleteAction instanceof Array && deleteAction.length > 0) {
               this.removeActions(deleteAction);
           }
       }

       /// disable changing url and image in case of using Resend View
       imageSelector.set("readOnly", isResendMessageView);
       urlSelector.set("readOnly", isResendMessageView);

       parser.parse();

       /////////////////////////////////////////
       // datetimeselector for picking Schedule moment
       /////////////////////////////////////////
       var dateTimeSelector = dijit.byId("socialmessage-datetimeselector");
       if (dateTimeSelector) {
           aspect.after(dateTimeSelector, "closeDropDown", function (focus) {
               $('.outreach').trigger('scheduleChanged', dateTimeSelector.get("value"));
           });
       }
   });