﻿(function ($) {

    $.fn.trackLength = function (handler) {
        var self = this;
        function calculate(obj) {
            var count = $(obj).val().length;
            handler(count);
        };

        this.each(function () {
            calculate(this);
            $(this).keyup(function () { calculate(this) });
            $(this).change(function () { calculate(this) });
        });
    };

})(jQuery);