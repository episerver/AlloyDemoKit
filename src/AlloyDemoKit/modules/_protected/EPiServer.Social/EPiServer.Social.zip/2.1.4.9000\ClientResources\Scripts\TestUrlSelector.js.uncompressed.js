﻿//function _TryToDoFuncRepeatly(func, contextForThis, interval, maxLoopCount, defer) {
//    /// <summary>
//    /// Util function.
//    /// try to exec <param>func</param>. func should return true if its executing is successful
//    /// contextForThis: context for func's "this" object
//    /// interval: between a loop
//    /// maxLoopCount: max count to try executing func
//    /// defer: on executing func successfully, this defer will be resolved.
//    /// </summary>

//    var flagToStop = false;
//    var count = 0;

//    var loopHandler = setInterval(function () {
//        count++;

//        if (flagToStop || count > maxLoopCount) {
//            clearInterval(loopHandler);
//            if (defer)
//                defer.reject();
//            return;
//        }

//        var ret = func.apply(contextForThis);
//        if (ret) {
//            clearInterval(loopHandler);
//            flagToStop = true;
//            if (defer)
//                defer.resolve();
//        }

//    }, interval);
//};


function LinkDumpClass() {
    var self = this;

    self.Url = null;
    self.PermanentLinkUrl = null;
}

var viewModel = {

    linkInstance: new LinkDumpClass()

};

$(document).ready(function () {
    var $outreach = $('.outreach');

    // Get object from serverside's Model
    viewModel.initLinkDump = g_DefaultDump;

    if (viewModel.initLinkDump) {

        viewModel.linkInstance.Url = viewModel.initLinkDump.url;
        viewModel.linkInstance.PermanentLinkUrl = viewModel.initLinkDump.permanentLinkUrl;
    }
});



require([
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/Deferred",
    "dojo/parser",
    "dojo/promise/all",
    "dojo/aspect",
    "dojo/query",
    "dojo/when",
    "dojo/on",
    "dojo/NodeList-manipulate",
    "dojo/dom-style",

    "dijit/_HasDropDown",

    // EPi Framework
    "epi/dependency",
    "epi/ModuleManager",
    "epi/routes",
    "epi/shell/MessageService",
    "epi/shell/Profile",
    "epi/shell/store/Registry",
    "epi/shell/TypeDescriptorManager",
    "epi/shell/widget/dialog/Dialog",
    "epi/shell/MetadataManager",

    // EPi CMS
    "epi/Url",
    "epi-cms/core/PermanentLinkHelper",
    "epi-cms/store/CustomQueryEngine",
    "epi-cms/widget/UrlSelector",
    "epi-cms/widget/LinkEditor",
    "epi-cms/widget/ContentSelectorDialog",
    "epi-cms/form/EmailValidationTextBox",
    "epi-cms/widget/ContextualContentForestStoreModel"
],
   function (
       // Dojo
       array,
       declare,
       lang,

       Deferred,
       parser,
       promiseAll,
       aspect,
       query,
       when,
       on,
       NodeListManipulate,
       domStyle,

       // Dijit
       _HasDropDown,

       // EPi Framework
       dependency,
       ModuleManager,
       routes,
       MessageService,
       Profile,
       StoreRegistry,
       TypeDescriptorManager,
       Dialog,
       MetadataManager,

       // EPi CMS
       Url,
       PermanentLinkHelper,
       CustomQueryEngine,
       UrlSelector,
       LinkEditor,
       ContentSelectorDialog,
       EmailValidationTextBox,
       ContextualContentForestStoreModel
    ) {


           // apply patch from episerver for _HasDropDown
           lang.mixin(_HasDropDown.prototype, {
               _onBlur: function () {
                   // summary:
                   //       Called magically when focus has shifted away from this widget and it's dropdown

                   // Don't focus on button if the user has explicitly focused on something else (happens
                   // when user clicks another control causing the current popup to close)..
                   // But if focus is inside of the drop down then reset focus to me, because IE doesn't like
                   // it when you display:none a node with focus.
                   var focusMe = focus.curNode && this.dropDown && dom.isDescendant(focus.curNode, this.dropDown.domNode);

                   /* THE FIX GOES HERE */
                   /* --------------------------------------------------------------------------------------------- */

                   // Fire the public onBlur event before calling closeDropDown in which it may try to grab focus and fire onFocus event.
                   // That leads to the situation that the next onFocus event happens before the last onBlur event.
                   this.inherited(arguments);
                   this.closeDropDown(focusMe);

                   /* --------------------------------------------------------------------------------------------- */
                   /* END FIX */
               }
           });
       _HasDropDown.prototype._onBlur.nom = "_onBlur";



       //////////////////////////////////////////
       // Framework ShellModule initialize
       //////////////////////////////////////////

       // Register dependency
       var registry = new StoreRegistry();
       dependency.register("epi.storeregistry", registry);
       dependency.register("epi.shell.Profile", new Profile());
       dependency.register("epi.shell.MessageService", MessageService);
       dependency.register("epi.ModuleManager", new ModuleManager());
       dependency.register("epi.shell.MetadataManager", new MetadataManager());

       // Init Shell stores
       var contextStoreUrl = routes.getRestPath({ moduleArea: "shell", storeName: "context" });
       // Create context store
       registry.create("epi.shell.context", contextStoreUrl, { idProperty: "uri" });
       registry.create("epi.shell.metadata", routes.getRestPath({ moduleArea: "shell", storeName: "metadata" }));
       registry.create("epi.shell.uidescriptor", routes.getRestPath({ moduleArea: "shell", storeName: "uidescriptor" }));

       TypeDescriptorManager.initialize();

       /////////////////////////////////////////
       // CMSModule initialize
       /////////////////////////////////////////

       // Register dependency
       dependency.register("epi.cms.contentRepositoryDescriptors", {});

       var _getRestPath = function (name) {
           return routes.getRestPath({ moduleArea: "cms", storeName: name });
       };

       // Init CMS stores
       registry.create("epi.cms.content.light", _getRestPath("contentstructure"), { idProperty: "contentLink", queryEngine: CustomQueryEngine });
       registry.create("epi.cms.contentdata", _getRestPath("contentdata"), { idProperty: "contentLink" });
       // Create language store
       registry.create("epi.cms.language", _getRestPath("language"), { idProperty: "languageId" });


       ///////////////////////////////////////////
       //// Initialize UrlSelector
       ///////////////////////////////////////////

       var roots = g_EPiServer.globalAssetsRootID === g_EPiServer.siteAssetsRootID ? [g_EPiServer.globalAssetsRootID] : [g_EPiServer.globalAssetsRootID, g_EPiServer.siteAssetsRootID],
           allowedTypes = ["episerver.core.icontentimage", "episerver.core.contentfolder"];


       var urlSelector = new UrlSelector({
           metadata: {
               additionalValues: {
                   modelType: "EPiServer.Cms.Shell.UI.ObjectEditing.InternalMetadata.LinkModel"
               }
           }
       });

       // epi-socialreach/widget/viewmodel/ContextualContentForestStoreModel
       var contentModel = new ContextualContentForestStoreModel({
           roots: [g_EPiServer.rootPageID],
           typeIdentifiers: ["episerver.core.pagedata"],
           currentContextId: g_EPiServer.rootPageID,
           pseudoContextualContent: g_EPiServer.contentAssetsRootID
       });

       aspect.after(contentModel, "_createQuery", function (query) {
           return lang.mixin(query, {
               "allLanguages": true//,
               //"epslanguage": _getCurrentEpsLanguageOfMessageUrl()
           });
       });

       // send the language in order to get page name in selected language
       urlSelector.own(
            aspect.before(urlSelector.linkHelper, "getContent", function (value, options) {
                return [value, options]
                //return [value, lang.mixin(options, { "language": _getCurrentEpsLanguageOfMessageUrl() })]
            })
        )
       //_setupUrlSelector(urlSelector);
       _setupLastestUrlSelector(urlSelector, "_onDialogShow");

       var $inputUrl = $("#socialmessage-url");   // this hidden input contains value of messageUrl
       // set url to empty if user click on clear button of urlSelector
       on(urlSelector.clearButton, "click", function () {
           $inputUrl.val('');
           $inputUrl.trigger("change");
       });
       urlSelector.own(
           urlSelector.connect(urlSelector, "onChange", function (value) {
               var espLanguageOnUrl = _getEpsLanguage(value);
               if (value) {
                   // is relative link? --> internal link
                   if (value.indexOf('/') == 0) {

                       // save the url-including-epslanguage to socialmessage-url
                       when(PermanentLinkHelper.getContent(value, { "allLanguages": true }), lang.hitch(this, function (content) {
                           // add siteUrl to its beginning
                           var relativePath = content && content.permanentLink ? content.permanentLink.substring(content.permanentLink.indexOf("/")) : value;
                           var urlToStore = combinePath(g_EPiServer.siteUrl, relativePath);

                           // Ensure that the selected content is localizable or not (ex.: in this case, it is page, not media)
                           var contentLanguageId = content && content.currentLanguageBranch ? content.currentLanguageBranch.languageId : null;
                           if (contentLanguageId) {
                               var epsLanguage = espLanguageOnUrl || contentLanguageId;
                               urlToStore = addQueryParam(urlToStore, "epslanguage", epsLanguage);
                           }

                           // ASYNC, we need to setVal and trigger here
                           $inputUrl.val(urlToStore);
                           // trigger change event to force knockout update view model
                           $inputUrl.trigger("change");
                       }));
                   }
                   else {
                       // external link, store it as is
                       $inputUrl.val(value);
                       // trigger change event to force knockout update view model
                       $inputUrl.trigger("change");
                   }
               }

           })   // connect()
        );  // own()

       urlSelector.placeAt("socialmessage-linkSelector");


       function _setupLastestUrlSelector(/*Object*/urlSelector, /*String*/aspectMethodName) {
           // summary:
           //       Setup for the UrlSelector widget with the latest version of the CMS
           // urlSelector: [Object]
           //       An instance of the "epi-cms/widget/UrlSelector" class
           // aspectMethodName: [String]
           //       The main entry (function name used in the aspect clause) to applies modification

           aspect.before(urlSelector, aspectMethodName, function () {
               this.dialog.set("title", this._getTitle());

               _onDialogContentFieldCreated(this.dialogContent);

               this.own(
                   aspect.before(this.dialogContent, "_handleActions", _filterOutDeleteAction) // Filter out "Delete" button
               );
           });
       }

       function _onDialogContentFieldCreated(/*Object*/dialogContent) {
           // summary:
           //       Hide all fields that have name is "href"
           // dialogContent: [Object]
           //       An instance of the "epi-cms/widget/LinkEditor" class

           aspect.after(dialogContent, "onFieldCreated", function (fieldName, widget) {
               if (fieldName === "href") {
                   if (widget.wrappers instanceof Array) {
                       _decorateContentSelectorDialog(widget.wrappers);

                       return;
                   }

                   if (typeof widget.onSelectorsCreated === "function") {
                       aspect.after(widget, "onSelectorsCreated", function (widget) {
                           _decorateContentSelectorDialog(widget.wrappers);
                       }, true);
                   }
               }
           }, true);
       }

       function _decorateContentSelectorDialog(/*Array*/wrapperList) {
           // summary:
           //       Decorates the content selector dialog widget in order to use its features normally in the addons environment
           // wrapperList: [Array]
           //       Collection of wrapper object
           // tags:
           //       private

           array.forEach(wrapperList, function (wrapper) {
               // hide email option
               if (wrapper.inputWidget.isInstanceOf(EmailValidationTextBox) === true) {
                   domStyle.set(wrapper.domNode, { display: "none" });
               }

               // Patch _getDialog method
               if (wrapper.inputWidget && wrapper.inputWidget._getDialog) {
                   wrapper.inputWidget._getDialog = function () {
                       if (this.dialog && this.dialog.domNode) {
                           return this.dialog;
                       }

                       contentModel.roots = wrapper.settings.roots;
                       this.contentSelectorDialog = new ContentSelectorDialog({
                           canSelectOwnerContent: this.canSelectOwnerContent,
                           showButtons: false,
                           roots: contentModel.roots,
                           allowedTypes: wrapper.settings.allowedTypes,
                           model: contentModel
                       });

                       // TECHNOTE:
                       //       We don't want user select a root or container page node in the content selector tree.
                       //       So that, each time user try to select this kind of page, the selected tree node will be clear.
                       //       The valid condition to verifies the selected content is root or container page is its "publicUrl" property.
                       //       Root or container page don't have value for "publicUrl".
                       aspect.after(this.contentSelectorDialog, "_onTreeNodeClick", lang.hitch(this.contentSelectorDialog, function (content) {
                           if (content && !content.publicUrl) {
                               this.tree.lastFocused.setSelected(false);

                               this.set('value', null);
                               this.onChange(this.get('value'));
                           }
                       }), true);

                       this.dialog = new Dialog({
                           title: wrapper.name,
                           dialogClass: "epi-dialog-portrait",
                           content: this.contentSelectorDialog,
                           destroyOnHide: true
                       });

                       this.connect(this.contentSelectorDialog, "onChange", "_setDialogButtonState");
                       this.connect(this.dialog, 'onExecute', '_onDialogExecute');
                       this.connect(this.dialog, 'onHide', '_onDialogHide');

                       return this.dialog;
                   }
               }
           });
       }

       function _filterOutDeleteAction() {
           // summary:
           //       Filter out delete action from the given action collection
           // TECHNOTE: we don't want Delete button, remove it from actions array, after _handleActions()

           var deleteAction = array.filter(this._actions, function (action) {
               if (action.hasOwnProperty("name") && typeof action.name === "string") {
                   return action.name.toLowerCase() === "delete";
               };

               return false;
           });

           if (deleteAction instanceof Array && deleteAction.length > 0) {
               this.removeActions(deleteAction);
           }
       }

       // util functions
       function addQueryParam(url, paramName, paramValue) {
           // add query param to the url
           if (!url || !paramName) {
               return url;
           }

           var uBuilder = new Url(url);
           uBuilder.query[paramName] = paramValue;
           return uBuilder.toString();
       }

       function combinePath(/*String*/baseUri, /*String*/relativePath) {
           // combine the base URI and relative path to a full path
           if (!baseUri || !relativePath) {
               return baseUri;
           }
           var uBuilder = new Url(baseUri);
           uBuilder.path = relativePath;
           return uBuilder.toString();
       }

       var $contentLanguageId = $("#socialmessage-current-language-id");
       function _getCurrentEpsLanguageOfMessageUrl() {
           /// util, get the epsLanguage in input#socialmessage-url

           return $contentLanguageId.val();
       }

       function _getEpsLanguage(/*String*/url) {
           // summary:
           //      Gets the "epslanguage" query string value from the given url string
           // url: [String]
           //      The given url string that want to get epslanguage from
           // tags:
           //      private

           if (url) {
               return new Url(url).query.epslanguage;
           }
       }

       //function _setCurrentLanguageId(/*String*/languageId) {
       //    // summary:
       //    //       Sets current language branch code
       //    // languageId: [String]
       //    //       The current language branch code
       //    // tags:
       //    //       private

       //    $contentLanguageId.val(languageId);
       //}

       //// we need to wait for knockout bind model data to the DOM,
       //// also cannot listen afterRender event because this script may run after the event trigger
       //_TryToDoFuncRepeatly(function () {

       //    var urlString = $inputUrl.val().toString();
       //    if (!urlString) {
       //        // Give url selector widget a blank value in order to set its default state (empty content link reference) have a good display
       //        urlSelector.set("value", "");

       //        return;
       //    }

       //    urlSelector.set("value", urlString);
       //    // parse epslanguage from urlString
       //    var epsLanguage = (new Url(urlString)).query.epslanguage;
       //    if (epsLanguage) {
       //        _setCurrentLanguageId(epsLanguage);

       //    }

       //}, this, 100, 5, null);

       parser.parse();
   });