﻿define([
// Dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/promise/all",
    "dojo/when",

//CMS
    "epi-cms/widget/ContextualContentForestStoreModel"
],

function (
// Dojo
    array,
    declare,
    lang,

    all,
    when,

//CMS
    ContextualContentForestStoreModel

    ) {

    // summary:
    //      Inherit from epi-cms/widget/ContextualContentForestStoreModel,
    //      overide some methods to make it does not depend on CMS context.
    return declare([ContextualContentForestStoreModel], {

        _getRootItems: function () {

            var rootLoads = array.map(this.roots, lang.hitch(this, function (item) {
                return this.store.get(item);
            }));

            return when(all(rootLoads), function (rootItems) {
                // When loads are done, filter the ones that resolve null
                return array.filter(rootItems, Boolean);
            });
        },

        _afterStoreGet: function (/*Object*/promise) {
            return promise;
        },

        getCurrentContent: function () {
            return {};
        },

        _getPseudoContextualContent: function () {
            return this.pseudoContextualContent;
        }
    });
});