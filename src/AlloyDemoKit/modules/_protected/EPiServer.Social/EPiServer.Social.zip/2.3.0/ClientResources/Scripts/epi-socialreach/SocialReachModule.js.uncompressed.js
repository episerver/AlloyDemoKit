﻿define([
    "epi/_Module",
    "epi/dependency",
    "epi/routes",
    "epi/shell/HashWrapper"

], function (
    _Module,
    dependency,
    routes,
    HashWrapper

) {

    return dojo.declare([_Module], {

        // _settings: [private] Object
        //      Object store settings which sent by SocialReach component.
        _settings: null,

        constructor: function (settings) {
            this._settings = settings;
        },

        initialize: function () {
            // summary:
            //		Initialize module
            //
            // description:
            //      Dependencies registered by this module are: 'SocialReach application'

            this.inherited(arguments);

            // Initialize stores
            var registry = this.resolveDependency("epi.storeregistry");

            var route = this._getRestPath("message");

            registry.create("epi-socialreach.message", route, { idProperty: "id" });
        },

        _getRestPath: function (name) {
            // summary:
            //      Get the rest path to a specified store.
            // prameters:
            //      name: The name of the store to get.
            // tags:
            //      private

            return routes.getRestPath({ moduleArea: "EPiServer.Social", storeName: name });
        }

    });
});
