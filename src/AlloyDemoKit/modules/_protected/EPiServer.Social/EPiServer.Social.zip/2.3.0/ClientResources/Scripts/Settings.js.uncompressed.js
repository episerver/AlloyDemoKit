﻿/// <reference path="jquery-1.7.1-vsdoc.js" />
/// <reference path="jquery-ui-1.8.16.js" />
/// <reference path="knockout-2.0.0.debug.js" />

var viewModel = {

    initialized: ko.observable(false).extend({ throttle: 100 }),
    selectedAccount: null,
    socialChannels: ko.observableArray([]),
    selectedProvider: ko.observable(),

    newSocialChannel: function () {

        if (!viewModel.selectedProvider())
            return;

        var providerName = viewModel.selectedProvider().Name;
        var provider = Provider.Get(providerName);

        var socialChannel = {
            EditMode: ko.observable(true),
            Channel: {
                Name: ko.observable(res.client.newchannel),
                CampaignSource: ko.observable("episocial"),
                CampaignMedium: ko.observable(providerName.toLowerCase()),
                ProviderName: ko.observable(providerName),
                AccessRights: ko.observableArray([
                    { Name: "Administrators", Access: ko.observable(Social.AccessRight.Read | Social.AccessRight.Post) },
                    { Name: "WebAdmins", Access: ko.observable(Social.AccessRight.Read | Social.AccessRight.Post) },
                    { Name: "WebEditors", Access: ko.observable(Social.AccessRight.Read | Social.AccessRight.Post) }
                ]),
                AccountDisplayName: ko.observable(),
                ProviderData: ko.mapping.fromJS(provider.GetDefaultProviderData())
            },
            ChannelContext: ko.mapping.fromJS(provider.InitChannelContext())
        };

        viewModel.socialChannels.unshift(socialChannel);
        viewModel.selectedProvider(null);
    },
    editSocialChannel: function (socialChannel) {
        var providerName = ko.utils.unwrapObservable(socialChannel.Channel.ProviderName);
        Provider.Get(providerName).SetChannelContext(socialChannel);

        socialChannel.EditMode(true);
    },
    saveSocialChannel: function (socialChannel) {
        $.post(g_ModulePath + "Settings/SaveSocialChannel", "jsonObject=" + ko.mapping.toJSON(socialChannel.Channel), function (data) {
            var jsonObject = ko.mapping.fromJS(data);

            if (jsonObject.HasAdminAccessRight() == true) {
                socialChannel.Channel = jsonObject.Channel;
            } else {
                // if the admin access right for current user has been removed,
                // remove the channel
                viewModel.socialChannels.remove(socialChannel);
            }
            
            socialChannel.EditMode(null);
        });
    },
    cancelSocialChannelEdit: function (socialChannel) {
        var socialChannelId = ko.utils.unwrapObservable(socialChannel.Channel.Id);
        if (socialChannelId) {
            $.post(g_ModulePath + "Settings/GetSocialChannel", "socialChannelId=" + socialChannelId, function (data) {
                socialChannel.Channel = ko.mapping.fromJS(data);
                socialChannel.EditMode(null);
            });
        }
        else {
            viewModel.socialChannels.remove(socialChannel);
        }
    },
    deleteSocialChannel: function (socialChannel) {
        var itemId = ko.utils.unwrapObservable(socialChannel.Channel.Id);

        if (itemId) {
            if (confirm(res.client.deleteconfirmation)) {
                // TODO: handle AccessDenied or ArgumentNotFound exception here
                $.post(g_ModulePath + "Settings/Delete", "jsonObject=" + itemId, function (data) {
                    viewModel.socialChannels.remove(socialChannel);
                });
            }
        }
    },
    selectUser: function (socialChannel) {

        OpenDialogUserAndGroupBrowser(0, '', g_ProtectedRootPath + 'CMS/edit', true, function (returnValue, args) {
            if (returnValue) {
                $(returnValue).each(function () {

                    var arrayReturnObjects = this.split("|");
                    socialChannel.Channel.AccessRights.push({ Name: arrayReturnObjects[0], Access: ko.observable(0) });
                });
            }
        },
        null,
        null);
    },
    initSocialChannel: function (elements, data) {
        if (data === undefined) {
            return;
        }

        if (data.EditMode()) {
            $('.toggle-details', elements).click();
        }

        $('.logo', elements).attr('src', g_ModuleResourcePath + 'Providers/' + data.Channel.ProviderName().toLowerCase() + '/logo.png');

    },
    initProviderTemplate: function (elements, data) {
    },
    hideDetails: function ($link) {
        var $channel = $link.parents('.channel');

        $channel.find('dl').hide();
        $channel.find('.buttons').hide();
        $channel.find('.see-account-details').text(res.client.seeaccountdetails).removeClass('active');
        $channel.find('.extra-account-details').hide();

        $link.text(res.client.seedetails);
    },
    showDetails: function ($link) {
        var $channel = $link.parents('.channel');

        $channel.find('dl').show();
        $channel.find('.buttons').show();

        $link.text(res.client.hidedetails);
    }
};

$('.see-account-details').live('click', function (e) {
    e.preventDefault();

    var $link = $(this);
    var $details = $link.next();

    $details.toggle();
    $link.toggleClass('active');

    if ($details.is(':visible')) {
        $link.text(res.client.hideaccountdetails);
    }
    else {
        $link.text(res.client.seeaccountdetails);
    }
});


$(".channel-edit").live("click", function (e) {
    e.preventDefault();

    var socialChannel = ko.dataFor(this);
    viewModel.editSocialChannel(socialChannel);
});

$(".channel-save").live("click", function (e) {
    e.preventDefault();

    $('.clsAutoReplaceSpecialCharacters').each(function (index, element) {
        // replace special characters so knockout binding work correctly
        var $e = $(element);
        var newValueWithoutSpecial = $e.val().replace(/[\/\\&]/ig, '');
        $e.val(newValueWithoutSpecial);
        $e.trigger("change");   // trigger change so knockout can recognize it
    });

    var socialChannel = ko.dataFor(this);
    viewModel.saveSocialChannel(socialChannel);
});

$(".new-channel-cancel").live("click", function (e) {
    e.preventDefault();

    var socialChannel = ko.dataFor(this);
    viewModel.cancelSocialChannelEdit(socialChannel);
});

$(".channel-cancel").live("click", function (e) {
    e.preventDefault();

    var socialChannel = ko.dataFor(this);
    viewModel.cancelSocialChannelEdit(socialChannel);
});

$(".channel-delete").live("click", function (e) {
    e.preventDefault();

    var socialChannel = ko.dataFor(this);
    viewModel.deleteSocialChannel(socialChannel);
});

$(".accessright-delete").live("click", function (e) {
    e.preventDefault();

    var accessRight = ko.dataFor(this);
    ko.contextFor(this).$parent.Channel.AccessRights.remove(accessRight);
});

$('.toggle-details').live('click', function (e) {
    e.preventDefault();

    var $link = $(this);
    var $linkParent = $link.parent();
    $linkParent.toggleClass('active');

    if ($linkParent.hasClass('active')) {
        viewModel.showDetails($link);
    }
    else {
        viewModel.hideDetails($link);
    }
});


ko.bindingHandlers.checkedFlag = {

    init: function (element, valueAccessor, allBindingsAccessor, viewModel) {

        var value = valueAccessor(), allBindings = allBindingsAccessor();
        var valueUnwrapped = ko.utils.unwrapObservable(value);
        var flag = allBindings.flag || 1;

        $(element).attr('checked', (flag == (valueUnwrapped & flag)));
        $(element).change(function () {

            var observable = valueAccessor();
            var value = ko.utils.unwrapObservable(observable);
            if ($(element).attr('checked')) {
                value |= flag;
            }
            else {
                value &= ~flag;
            }

            observable(value);
        });
    },
    update: function (element, valueAccessor, allBindingsAccessor, viewModel) {

        var value = valueAccessor(), allBindings = allBindingsAccessor();
        var valueUnwrapped = ko.utils.unwrapObservable(value);
        var flag = allBindings.flag || 1;

        $(element).attr('checked', (flag == (valueUnwrapped & flag)));
    }
};

ko.applyBindings(viewModel);


$(document).ready(function ()
{
    $.ajax({
        url: g_ModulePath + "Settings/GetAllSocialChannels",
        data: "permission=" + Social.AccessRight.ListAllForSetting,
        cache: false,
        type: "POST",
        async: false,
        success: function (data)
        {
            $(data).each(function ()
            {

                var providerName = this.ProviderName;
                var socialChannel = {
                    EditMode: ko.observable(null),
                    Channel: ko.mapping.fromJS(this),
                    ChannelContext: ko.mapping.fromJS(eval(providerName + '.InitChannelContext()'))
                };

                viewModel.socialChannels.push(socialChannel);
            });

            viewModel.initialized(true);
        }
    });
});
