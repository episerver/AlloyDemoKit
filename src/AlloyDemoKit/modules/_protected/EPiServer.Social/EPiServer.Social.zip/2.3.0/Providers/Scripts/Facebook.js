﻿var Facebook;

if (!Facebook) {

    Social.Providers.push({ Name: 'Facebook' });

    window.fbAsyncInit = function() {
        FB.init({
            status: false,
            cookie: true,
            xfbml: true,
            version: 'v2.8'
        });
    };

    // bring in FB.api
    // TECHNOTE: We want to count number of reactions for a post. all.js is old sdk and not support ractions api. Reactions API is supported since sdk v2.6.
    (function(d){
        var js, id = 'facebook-jssdk', ref = d.getElementsByTagName('script')[0];
        if (d.getElementById(id)) {return;}
        js = d.createElement('script'); js.id = id; js.async = true;
        js.src = "//connect.facebook.net/en_US/sdk.js";
        ref.parentNode.insertBefore(js, ref);
    }(document));


    Facebook =
    {
        GetDefaultProviderData: function () {
            return {
                UserName: null,
                AccessToken: null,
                PostTo: null
            };
        },
        InitChannelContext: function () {
            return {
                PostOptions: [
                    { value: "0|", name: "Wall" }
                ]
            };
        },
        SetChannelContext: function (socialChannel) {

            var accessToken = ko.utils.unwrapObservable(socialChannel.Channel.ProviderData.AccessToken);
            var postTo = ko.utils.unwrapObservable(socialChannel.Channel.ProviderData.PostTo);

            socialChannel.ChannelContext.PostOptions.removeAll();
            socialChannel.ChannelContext.PostOptions.push({ value: "0|" + accessToken, name: 'Wall' });

            if (typeof (FB) != 'undefined' && accessToken) {

                FB.api('me/accounts/', 'GET', { access_token: accessToken }, function (data) {

                    $(data.data).each(function () {

                        if (this.category != 'Application') {
                            socialChannel.ChannelContext.PostOptions.push({ value: this.id + "|" + this.access_token, name: this.name });

                            // Renew postTo value based on the new access token that returned from FB each time.
                            // This helps to bind selected value for PostTo field correctly.
                            var postToId = postTo && postTo.split('|')[0];
                            if (this.id === postToId) {
                                postTo = postToId + "|" + this.access_token;
                            }
                        }
                    });

                    socialChannel.Channel.ProviderData.PostTo(postTo);
                });
            }
        },
        Validate: function (socialMessage, socialChannelMessage) {
            return { IsValid: true, Message: null };
        },
        SelectedSocialChannel: {},
        ReceiveData: function (screenName, accessToken) {

            this.SelectedSocialChannel.Channel.AccountDisplayName(screenName);
            this.SelectedSocialChannel.Channel.ProviderData.UserName(screenName);
            this.SelectedSocialChannel.Channel.ProviderData.AccessToken(accessToken);

            this.SetChannelContext(this.SelectedSocialChannel);
        },
        LoadDetailedStatistics: function (socialChannelMessage, socialMessage) {

            var stats = {
                Comments: ko.observable('-'),
                Likes: ko.observable('-')
            };
            
            // Check existance of FB before using.
            // When invoking this from widget, the FB.api might not be loaded fully. Fortunately, this will be invoked 
            // again from Statistics.js(calling viewModel.refresh), this time FB.api's already loaded so this works properly
            // TECHNOTE: We want to count number of reactions for a post. all.js is old sdk and not support ractions api. Reactions API is supported since sdk v2.6.
            // The way to access data of a post also change dramatically since we have to point to every edges of post.
            if (typeof (FB) != 'undefined' && socialChannelMessage.Status == Social.ChannelMessageStatus.Success && socialChannelMessage.PostID) {
                FB.api(socialChannelMessage.PostID + '/reactions', 'GET', { access_token: socialChannelMessage.Channel.ProviderData.AccessToken }, function (reactions) {
                    stats.Likes(reactions.data ? reactions.data.length : 0);
                });
                FB.api(socialChannelMessage.PostID + '/comments', 'GET', { access_token: socialChannelMessage.Channel.ProviderData.AccessToken }, function (comments) {
                    stats.Comments(comments.data ? comments.data.length : 0);
                });
            }
            return stats;
        },
        GetMessageUrl: function (socialChannelMessage) {
            // both work: http://www.facebook.com/ + {user_id}_{post_id} OR {user_id}/posts/{post_id}
            // where {user_id}_{post_id} is socialChannelMessage.PostID
            return "http://www.facebook.com/" + (socialChannelMessage.PostID ? socialChannelMessage.PostID : "");
        }
    };
}

$(".edit-facebookaccount").live("click", function (e) {

    e.preventDefault();

    Facebook.SelectedSocialChannel = ko.dataFor(this);

    var Request;

    $.ajax({ url: g_ModuleResourcePath + "Providers/FacebookProxy/GetAuthenticationUrl",
        type: "GET",
        async: false,
        dataType: "json",
        success: function (data) {
            Request = data;
        }
    });

    var windowObject = window.open(Request.AuthUrl, 'mywindow', 'resizable,width=1024,height=700');

    var id = window.setInterval(function () {

        if (!windowObject || windowObject.closed) {
            window.clearInterval(id);

            $.ajax({ url: g_ModuleResourcePath + "Providers/FacebookProxy/GetAccessToken",
                type: "POST",
                data: "cookie=" + Request.Cookie,
                async: false,
                dataType: "json",

                success: function (data) {

                    var tokenData = JSON.parse(data.TokenData),
                        account = tokenData && tokenData.UserName,
                        accessToken = tokenData && tokenData.AccessToken,
                        defaultSocialChannelAccountName = (data.MetaData && data.MetaData.DefaultSocialChannelAccountName) || "";

                    if (account === "undefined") {
                        account = defaultSocialChannelAccountName;
                    }

                    // TECHNOTE: even user click on Cancel button (on Facebook Authorize for App page), api.episerver.com still returns a valid json result.
                    // In that case, both Username and accessToken is "undefined" (string)
                    if (!data.Error && accessToken !== "undefined") {
                        Facebook.ReceiveData(account, accessToken);
                    }
                }
            });
        }

    }, 500);


    return false;
});