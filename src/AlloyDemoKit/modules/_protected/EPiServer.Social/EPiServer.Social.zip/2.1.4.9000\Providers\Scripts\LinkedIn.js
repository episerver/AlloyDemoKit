﻿var LinkedIn;

if (!LinkedIn) {

    Social.Providers.push({ Name: 'LinkedIn' });

    LinkedIn =
    {
        GetDefaultProviderData: function () {
            return {
                UserName: null,
                AccessToken: null,
                AccessTokenSecret: null,
                PostTo: null
            };
        },
        InitChannelContext: function (socialChannel) {
            return {};
        },
        SetChannelContext: function (socialChannel) {
        },
        Validate: function (socialMessage, socialChannelMessage) {
            return { IsValid: true, Message: null };
        },
        SelectedSocialChannel: {},
        ReceiveData: function (screenName, accessToken, accessTokenSecret) {
            if (!screenName) {
                screenName = "LinkedIn";
            }

            this.SelectedSocialChannel.Channel.AccountDisplayName(screenName);

            this.SelectedSocialChannel.Channel.ProviderData.UserName(screenName);
            this.SelectedSocialChannel.Channel.ProviderData.AccessToken(accessToken);
            this.SelectedSocialChannel.Channel.ProviderData.AccessTokenSecret(accessTokenSecret);

            this.SetChannelContext(this.SelectedSocialChannel);
        },
        LoadDetailedStatistics: function (socialChannelMessage, socialMessage) {
            // TECHNOTE: The REST API endpoint for getting network updates (/v1/people/~/network/updates/) 
            // is no longer available for general use. This is due to LinkedIn has changed the developer program rencently(2015 May).
            // https://developer.linkedin.com/blog/posts/2015/developer-program-changes
            // https://developer.linkedin.com/support/developer-program-transition
            // So there will be no need for sending request to that endpoint anymore since we cannot get anything back

        },
        GetMessageUrl: function (socialChannelMessage) {
            return "http://www.linkedin.com";
        },
        CheckLength: function (socialMessage, count, warning) {
            warning.InWarning(count > 700);
            if (count > 700) {
                warning.Info(res.client.linkedinmaxchar + ' (' + count + ')');
            }
        }

    };
}

$(".edit-linkedinaccount").live("click", function (e) {
    e.preventDefault();

    LinkedIn.SelectedSocialChannel = ko.dataFor(this);
    window.open(g_ModuleResourcePath + 'Providers/LinkedIn/LinkedInLogin.aspx?redirect=1', 'mywindow', 'resizable,width=800,height=700');
    return false;
});
