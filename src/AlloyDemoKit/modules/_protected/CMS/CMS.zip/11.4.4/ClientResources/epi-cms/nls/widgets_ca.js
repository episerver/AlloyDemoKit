//>>built
define("epi-cms/nls/widgets_ca",{"dgrid/extensions/nls/columnHider":{"popupTriggerLabel":"Show or hide columns","popupLabel":"Show or hide columns","_localized":{}}});