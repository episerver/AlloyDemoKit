//>>built
define("epi-cms/plugin-area/edit-view-filters",["epi/PluginArea"],function(_1){var _2=new _1("epi-cms/edit-view/filters[]");return _2;});