define("epi-cms/contentediting/MutationObserver", [
    "dojo/_base/declare",
    "dojo/Evented"
], function (
    declare,
    Evented
) {
    return declare([Evented], {
        // summary:
        //      Sets up mutation observers on data-epi-property-name attribute to react on changes in the DOM
        // tags:
        //      internal

        // _mutationObserverHandles: [private] Array
        //      Mutation observer handles
        _mutationObserverHandles: [],

        setup: function (doc) {
            // summary:
            //      Sets up observers to react on changes in the dom and publishes dom-updated event.
            //      Disconnects all the observers on teardown.
            // tags:
            //      public

            this.teardown();

            var epiPropertyNodes = this._getEpiPropertyNodes(doc);
            this._observeEpiPropertyNodes(epiPropertyNodes);

            var observer = new MutationObserver(function (mutations) {
                mutations.forEach(function (mutation) {
                    Array.prototype.slice.call(mutation.addedNodes).forEach(function (addedNode) {
                        var epiPropertyNodes = this._getEpiPropertyNodes(addedNode);
                        // If none of the child nodes is related with episerver we don't
                        // need to neither observe it nor emit a dom-updated event
                        if (epiPropertyNodes.length === 0) {
                            return;
                        }

                        this._publishEvent();
                        this._observeEpiPropertyNodes(epiPropertyNodes);
                    }, this);
                }, this);
            }.bind(this));
            observer.observe(doc, {
                childList: true,
                subtree: true
            });

            this._mutationObserverHandles.push(observer);
        },
        teardown: function () {
            this._mutationObserverHandles.forEach(function (observer) {
                observer.disconnect();
            });
            this._mutationObserverHandles = [];
        },
        _getEpiPropertyNodes: function (target) {
            // If it is not a node type or document type make an early exit
            // this filters #text and #comments nodes for example and much more
            // https://developer.mozilla.org/en-US/docs/Web/API/Node/nodeType
            if (target.nodeType !== Node.ELEMENT_NODE && target.nodeType !== Node.DOCUMENT_NODE) {
                return [];
            }

            if (target.attributes && target.attributes["data-epi-property-name"]) {
                return [target];
            } else {
                var result = target.querySelectorAll("[data-epi-property-name]");
                return Array.prototype.slice.call(result);
            }
        },
        _observeEpiPropertyNodes: function (nodes) {
            nodes.forEach(function (node) {
                var observer = new MutationObserver(this._publishEvent.bind(this));
                observer.observe(node, {
                    attributes: true,
                    attributeFilter: ["data-epi-property-name"]
                });
                this._mutationObserverHandles.push(observer);
            }, this);
        },
        _publishEvent: function () {
            this.emit("dom-updated");
        }
    });
});
