﻿define("epi-cms/content-approval/viewmodels/ReviewerViewModel", [
    "dojo/_base/declare",
    "dojo/Stateful"
], function (
    declare,
    Stateful
) {
    return declare([Stateful], {
        // summary:
        //      The view model for a reviewer.
        // tags:
        //      internal

        // displayName: [public] String
        //      The displayName for the reviewer.
        displayName: null,

        // userName: [public] String
        //      The userName for the reviewer.
        userName: null,

        // languages: [public] Array
        //      Languages that this reviewer can approve.
        languages: null,

        // canApprove: [public] Boolean
        //      Indicates if the reviewer can approve the selected language.
        canApprove: true,

        serialize: function () {
            // summary:
            //      Serialize reviewer
            // tags:
            //      public

            return {
                userName: this.userName,
                displayName: this.displayName,
                languages: this.languages
            };
        }

    });
});
